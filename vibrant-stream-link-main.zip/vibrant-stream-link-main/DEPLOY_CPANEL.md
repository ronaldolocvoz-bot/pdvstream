# Deploy em cPanel (PHP 8.0+)

## Passo a passo

1. No terminal do projeto, execute:
   ```bash
   npm run build
   ```

2. Acesse o **Gerenciador de Arquivos** do cPanel

3. Faça upload de **todo o conteúdo** da pasta `dist/` para `public_html/`
   - Inclua o arquivo `.htaccess` (pode estar oculto)
   - Inclua o arquivo `index.php` (fallback)

4. Pronto! Acesse seu domínio normalmente.

## Instalação em subpasta

Se quiser instalar em `public_html/sistema/`:

1. No arquivo `vite.config.ts`, altere:
   ```ts
   base: '/sistema/',
   ```

2. Rode `npm run build` novamente

3. Faça upload do conteúdo de `dist/` para `public_html/sistema/`

4. Edite o `.htaccess` dentro da subpasta e altere:
   ```apache
   RewriteBase /sistema/
   ```

## Requisitos

- PHP 8.0 ou superior
- Módulo `mod_rewrite` ativo no Apache
- Permissão para arquivos `.htaccess`

## Solução de problemas

- **Páginas retornam 404:** Verifique se o `.htaccess` está na raiz do diretório e se `mod_rewrite` está ativo.
- **Página em branco:** Verifique o console do navegador (F12) para erros de caminho.
- **Fallback PHP:** Se `.htaccess` não funcionar, o `index.php` assume o redirecionamento automaticamente.
