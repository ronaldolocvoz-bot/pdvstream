import { useState, useEffect, useRef } from 'react';
import { Bell, X, AlertTriangle, Clock, CheckCircle, Lock, Check, XCircle, Volume2, VolumeX } from 'lucide-react';
import type { Client, PasswordRecoveryRequest } from '@/lib/types';
import { formatCurrency, generatePassword } from '@/lib/format';
import { isNotificationSoundEnabled, setNotificationSoundEnabled, playNotificationSound } from '@/lib/notificationSound';

interface NotificationsPanelProps {
  clients: Client[];
  recoveryRequests?: PasswordRecoveryRequest[];
  onApproveRecovery?: (requestId: number) => void;
  onRejectRecovery?: (requestId: number) => void;
}

interface Notification {
  id: string;
  type: 'overdue' | 'pending' | 'recovery';
  title: string;
  message: string;
  icon: React.ReactNode;
  actions?: { requestId: number };
}

export function NotificationsPanel({ clients, recoveryRequests, onApproveRecovery, onRejectRecovery }: NotificationsPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(isNotificationSoundEnabled);
  const prevCountRef = useRef<number | null>(null);
  const today = new Date().toISOString().split('T')[0];

  const overdueClients = (clients || []).filter(c => c.status !== 'inactive' && c.paymentStatus !== 'paid' && c.dueDate < today);
  const pendingSoon = (clients || []).filter(c => {
    if (c.status === 'inactive' || c.paymentStatus === 'paid') return false;
    const diff = (new Date(c.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
    return diff >= 0 && diff <= 3;
  });

  const pendingRecoveries = (recoveryRequests || []).filter(r => r.status === 'pending');

  const notifications: Notification[] = [
    ...pendingRecoveries.map(r => ({
      id: `recovery-${r.id}`,
      type: 'recovery' as const,
      title: '🔑 Recuperação de Senha',
      message: `${r.clientName} (${r.clientPhone}) solicitou recuperação de senha`,
      icon: <Lock size={14} className="text-warning" />,
      actions: { requestId: r.id },
    })),
    ...overdueClients.map(c => ({
      id: `overdue-${c.id}`,
      type: 'overdue' as const,
      title: 'Pagamento Atrasado',
      message: `${c.name} — ${formatCurrency(c.amount)} venceu em ${new Date(c.dueDate).toLocaleDateString()}`,
      icon: <AlertTriangle size={14} className="text-destructive" />,
    })),
    ...pendingSoon.map(c => ({
      id: `pending-${c.id}`,
      type: 'pending' as const,
      title: 'Vence em breve',
      message: `${c.name} — ${formatCurrency(c.amount)} vence em ${new Date(c.dueDate).toLocaleDateString()}`,
      icon: <Clock size={14} className="text-warning" />,
    })),
  ];

  const count = notifications.length;

  // Play sound when new notifications arrive
  useEffect(() => {
    if (prevCountRef.current !== null && count > prevCountRef.current) {
      playNotificationSound();
    }
    prevCountRef.current = count;
  }, [count]);

  const handleApprove = (requestId: number) => {
    const request = pendingRecoveries.find(r => r.id === requestId);
    if (!request) return;
    const client = clients.find(c => c.id === request.clientId);
    if (!client) return;

    // Send temporary password instead of exposing real password
    const tempPassword = generatePassword();
    const message = `Olá *${client.name}*!\n\n🔐 *Recuperação de Senha*\nSua nova senha temporária é: *${tempPassword}*\n\nRecomendamos que altere sua senha após o primeiro acesso.\n\nSe você não solicitou esta recuperação, entre em contato conosco imediatamente.`;
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(message)}`, '_blank');

    onApproveRecovery?.(requestId);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative bg-secondary hover:bg-muted text-foreground border border-border p-2.5 rounded-xl transition-colors"
      >
        <Bell size={18} />
        {count > 0 && (
          <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-destructive text-destructive-foreground text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
            {count}
          </span>
        )}
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 top-12 w-80 md:w-96 bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden animate-fade-in">
            <div className="flex justify-between items-center p-4 border-b border-border">
              <h3 className="font-bold text-foreground text-sm flex items-center gap-2">
                <Bell size={16} className="text-primary" /> Notificações
              </h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const next = !soundEnabled;
                    setSoundEnabled(next);
                    setNotificationSoundEnabled(next);
                    if (next) playNotificationSound();
                  }}
                  className={`p-1.5 rounded-lg transition-colors ${soundEnabled ? 'text-success hover:bg-success/10' : 'text-muted-foreground hover:bg-secondary'}`}
                  title={soundEnabled ? 'Som ativado' : 'Som desativado'}
                >
                  {soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
                </button>
                <button onClick={() => setIsOpen(false)} className="text-muted-foreground hover:text-foreground">
                  <X size={16} />
                </button>
              </div>
            </div>
            <div className="max-h-80 overflow-y-auto custom-scrollbar">
              {notifications.length > 0 ? (
                notifications.map(n => (
                  <div key={n.id} className={`p-4 border-b border-border hover:bg-secondary/30 transition-colors ${n.type === 'overdue' ? 'bg-destructive/5' : n.type === 'recovery' ? 'bg-warning/5' : ''}`}>
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">{n.icon}</div>
                      <div className="flex-1">
                        <p className="text-xs font-bold text-foreground">{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{n.message}</p>
                        {n.type === 'recovery' && n.actions && (
                          <div className="flex gap-2 mt-2">
                            <button
                              onClick={() => handleApprove(n.actions!.requestId)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase px-3 py-1.5 rounded-lg bg-success/10 text-success border border-success/20 hover:bg-success/20 transition-colors"
                            >
                              <Check size={12} /> Aprovar e Enviar via WhatsApp
                            </button>
                            <button
                              onClick={() => onRejectRecovery?.(n.actions!.requestId)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 transition-colors"
                            >
                              <XCircle size={12} /> Rejeitar
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center">
                  <CheckCircle size={24} className="text-success mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Tudo em dia! Nenhuma notificação.</p>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
