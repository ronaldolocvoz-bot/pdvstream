import { useState, useEffect, useRef, useCallback } from 'react';
import { Radio, Wifi, Copy, CreditCard, Headphones, Tv, AlertTriangle, LifeBuoy, FileText, Plus, X, CheckCircle, CalendarClock, AlertCircle, MessageCircle, Printer, QrCode, Banknote, Building2, Download, FolderOpen, Archive, Sun, Moon, Minus, Palette, Settings, LogOut, LayoutDashboard, Receipt, HeadphonesIcon, Menu } from 'lucide-react';
import type { Client, Transaction, CompanySettings, Ticket, Plan, DownloadFolder, DownloadFile } from '@/lib/types';
import { formatCurrency, getReceiptHTML, createPixPayload } from '@/lib/format';
import { CompactStreamPlayer } from '@/components/CompactStreamPlayer';
import { ClientTicketChat } from '@/components/ClientTicketChat';

interface ClientPortalProps {
  client: Client;
  transactions: Transaction[];
  tickets: Ticket[];
  companySettings: CompanySettings;
  plans: Plan[];
  onLogout: () => void;
  setTickets: React.Dispatch<React.SetStateAction<Ticket[]>>;
  setSettings: React.Dispatch<React.SetStateAction<CompanySettings>>;
  downloadFolders: DownloadFolder[];
  downloadFiles: DownloadFile[];
}

export function ClientPortal({ client, transactions, tickets, companySettings, plans, onLogout, setTickets, setSettings, downloadFolders, downloadFiles }: ClientPortalProps) {
  const [view, setView] = useState<'dashboard' | 'invoices' | 'support' | 'downloads' | 'settings'>('dashboard');
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [ticketForm, setTicketForm] = useState({ subject: '', description: '' });
  const [chatTicket, setChatTicket] = useState<Ticket | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // === Inactivity auto-logout (10 min) ===
  const INACTIVITY_TIMEOUT = 10 * 60 * 1000; // 10 minutes
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const resetTimer = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      onLogout();
    }, INACTIVITY_TIMEOUT);
  }, [onLogout]);

  useEffect(() => {
    const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    const handler = () => resetTimer();
    events.forEach(e => window.addEventListener(e, handler));
    resetTimer();
    return () => {
      events.forEach(e => window.removeEventListener(e, handler));
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [resetTimer]);

  const isOverdue = client.paymentStatus !== 'paid' && client.dueDate < new Date().toISOString().split('T')[0];
  const isPending = client.paymentStatus !== 'paid';
  const plan = plans.find(p => p.id === client.planId);

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => alert("Copiado!"));
  };

  const clientTxs = transactions.filter(t => (t.clientName === client.name || t.clientId === client.id)).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const clientTickets = tickets.filter(t => t.clientId === client.id).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleAddTicket = () => {
    if (!ticketForm.subject) return;
    const newTicket: Ticket = {
      id: Date.now(), clientId: client.id, subject: ticketForm.subject,
      description: ticketForm.description, status: 'open',
      scheduledDate: '', scheduledTime: '', createdAt: new Date().toISOString(),
      history: [{ id: 1, type: 'system', text: `📋 Ticket aberto pelo cliente: ${ticketForm.subject}`, date: new Date().toISOString() }],
    };
    setTickets(prev => [newTicket, ...prev]);
    setShowNewTicket(false);
    setTicketForm({ subject: '', description: '' });
    setChatTicket(newTicket);
  };

  const handleUpdateTicket = (updated: Ticket) => {
    setTickets(prev => prev.map(t => t.id === updated.id ? updated : t));
    setChatTicket(updated);
  };

  const handlePrintReceipt = (tx: Transaction) => {
    const w = window.open('', '', 'width=900,height=800');
    if (w) { w.document.write(getReceiptHTML(client.name, client.phone, tx.amount, tx.date, companySettings, tx.id)); w.document.close(); }
  };

  const contactWhatsApp = () => {
    const msg = encodeURIComponent(`Olá! Sou o cliente ${client.name} e preciso de ajuda.`);
    window.open(`https://wa.me/${companySettings.supportPhone || companySettings.phone}?text=${msg}`, '_blank');
  };

  const pixPayload = companySettings.pixKey ? createPixPayload(companySettings.pixKey, companySettings.name, 'BRASIL', client.amount) : '';

  const statusConfig: Record<string, { icon: React.ReactNode; label: string; class: string }> = {
    open: { icon: <AlertCircle size={12} />, label: 'Aberto', class: 'bg-warning/10 text-warning border-warning/20' },
    accepted: { icon: <AlertCircle size={12} />, label: 'Aceito', class: 'bg-info/10 text-info border-info/20' },
    scheduled: { icon: <CalendarClock size={12} />, label: 'Agendado', class: 'bg-primary/10 text-primary border-primary/20' },
    in_progress: { icon: <AlertCircle size={12} />, label: 'Em Andamento', class: 'bg-accent/10 text-accent-foreground border-accent/20' },
    resolved: { icon: <CheckCircle size={12} />, label: 'Resolvido', class: 'bg-success/10 text-success border-success/20' },
  };

  const unreadClientMsgs = clientTickets.reduce((count, ticket) => {
    const unread = (ticket.history || []).filter(m =>
      (m.type === 'admin' || m.type === 'system') && (!ticket.lastClientReadAt || new Date(m.date) > new Date(ticket.lastClientReadAt))
    ).length;
    return count + unread;
  }, 0);

  const clientFolders = downloadFolders.filter(f => f.clientIds.includes(client.id));

  const navItems = [
    { id: 'dashboard' as const, label: 'Painel', icon: LayoutDashboard },
    { id: 'invoices' as const, label: 'Faturas', icon: Receipt },
    { id: 'downloads' as const, label: 'Downloads', icon: Download, hidden: clientFolders.length === 0 },
    { id: 'support' as const, label: 'Suporte', icon: HeadphonesIcon, badge: unreadClientMsgs },
    { id: 'settings' as const, label: 'Aparência', icon: Palette },
  ];

  const handleNavClick = (id: typeof view) => {
    setView(id);
    setMobileMenuOpen(false);
  };

  const sidebarContent = (
    <>
      {/* Logo / Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          {companySettings.logoUrl ? (
            <div className="w-10 h-10 rounded-xl bg-background border border-border flex items-center justify-center overflow-hidden flex-shrink-0">
              <img src={companySettings.logoUrl} className="w-full h-full object-cover" alt="" />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
              <Radio size={20} className="text-primary" />
            </div>
          )}
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-foreground truncate">{companySettings.name || 'StreamPRO'}</h1>
            <p className="text-[10px] text-muted-foreground truncate">{client.name}</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-1">
        {navItems.filter(n => !n.hidden).map(item => (
          <button
            key={item.id}
            onClick={() => handleNavClick(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors relative ${
              view === item.id
                ? 'bg-primary/10 text-primary border border-primary/20'
                : 'text-muted-foreground hover:bg-secondary hover:text-foreground border border-transparent'
            }`}
          >
            <item.icon size={18} className="flex-shrink-0" />
            <span>{item.label}</span>
            {item.badge && item.badge > 0 && (
              <span className="absolute right-2 top-1/2 -translate-y-1/2 bg-destructive text-destructive-foreground text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center animate-pulse">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-2 border-t border-border space-y-1">
        <button
          onClick={contactWhatsApp}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-success hover:bg-success/10 transition-colors border border-transparent"
        >
          <MessageCircle size={18} className="flex-shrink-0" />
          <span>WhatsApp</span>
        </button>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors border border-transparent"
        >
          <LogOut size={18} className="flex-shrink-0" />
          <span>Sair</span>
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Sidebar - desktop */}
      <aside className={`${sidebarExpanded ? 'w-64' : 'w-16'} bg-card border-r border-border hidden md:flex flex-col transition-all duration-300 flex-shrink-0 h-screen sticky top-0`}>
        {sidebarExpanded ? sidebarContent : (
          <>
            <div className="p-4 border-b border-border flex justify-center">
              {companySettings.logoUrl ? (
                <div className="w-10 h-10 rounded-xl bg-background border border-border flex items-center justify-center overflow-hidden">
                  <img src={companySettings.logoUrl} className="w-full h-full object-cover" alt="" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <Radio size={20} className="text-primary" />
                </div>
              )}
            </div>
            <nav className="flex-1 p-2 space-y-1">
              {navItems.filter(n => !n.hidden).map(item => (
                <button
                  key={item.id}
                  onClick={() => setView(item.id)}
                  className={`w-full flex items-center justify-center p-2.5 rounded-xl transition-colors relative ${
                    view === item.id
                      ? 'bg-primary/10 text-primary border border-primary/20'
                      : 'text-muted-foreground hover:bg-secondary hover:text-foreground border border-transparent'
                  }`}
                  title={item.label}
                >
                  <item.icon size={18} />
                  {item.badge && item.badge > 0 && (
                    <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-[9px] font-bold px-1 py-0.5 rounded-full min-w-[16px] text-center animate-pulse">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </nav>
            <div className="p-2 border-t border-border space-y-1">
              <button onClick={contactWhatsApp} className="w-full flex items-center justify-center p-2.5 rounded-xl text-success hover:bg-success/10 transition-colors" title="WhatsApp">
                <MessageCircle size={18} />
              </button>
              <button onClick={onLogout} className="w-full flex items-center justify-center p-2.5 rounded-xl text-destructive hover:bg-destructive/10 transition-colors" title="Sair">
                <LogOut size={18} />
              </button>
            </div>
          </>
        )}
        <button
          onClick={() => setSidebarExpanded(!sidebarExpanded)}
          className="p-2 border-t border-border text-muted-foreground hover:text-foreground transition-colors text-center text-xs"
        >
          {sidebarExpanded ? '◀' : '▶'}
        </button>
      </aside>

      {/* Sidebar - mobile */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-card border-r border-border flex flex-col transform transition-transform duration-300 md:hidden ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-end p-2">
          <button onClick={() => setMobileMenuOpen(false)} className="p-2 text-muted-foreground hover:text-foreground rounded-lg">
            <X size={20} />
          </button>
        </div>
        {sidebarContent}
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Mobile header */}
        <div className="md:hidden sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center gap-3">
          <button onClick={() => setMobileMenuOpen(true)} className="p-1.5 rounded-lg hover:bg-secondary text-foreground">
            <Menu size={22} />
          </button>
          <h1 className="text-sm font-bold text-foreground truncate">{companySettings.name || 'StreamPRO'}</h1>
        </div>
        <div key={view} className="max-w-4xl mx-auto p-4 md:p-6 space-y-6" style={{ animation: 'portalFadeSlideIn 0.35s cubic-bezier(0.4,0,0.2,1) both' }}>
        {/* ===== DASHBOARD ===== */}
        {view === 'dashboard' && (
          <>
            <div className="bg-card border border-border rounded-2xl p-6 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
                {client.logoUrl ? <img src={client.logoUrl} className="w-full h-full rounded-2xl object-cover" alt="" /> : <Headphones size={24} className="text-primary" />}
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-foreground">Olá, {client.name}</h2>
                <p className="text-sm text-muted-foreground">Bem-vindo à sua Central do Cliente.</p>
              </div>
              {isPending && (
                <button onClick={() => { setView('invoices'); setShowPayment(true); }} className="bg-warning/10 text-warning border border-warning/20 px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors hover:bg-warning/20">
                  <CreditCard size={14} /> Pagar Fatura
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-2xl p-6">
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-4"><Wifi size={18} className="text-success" /> Status do Serviço</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center"><span className="text-sm text-muted-foreground">Stream:</span><CompactStreamPlayer url={client.audioUrl || client.videoUrl} type={client.serviceType} /></div>
                  <div className="flex justify-between items-center"><span className="text-sm text-muted-foreground">Plano:</span><span className="text-sm font-bold text-foreground">{plan?.name || '—'}</span></div>
                  <div className="flex justify-between items-center"><span className="text-sm text-muted-foreground">Início:</span><span className="text-sm text-foreground">{client.startDate ? new Date(client.startDate).toLocaleDateString('pt-BR') : '—'}</span></div>
                </div>
              </div>

              <div className={`bg-card border rounded-2xl p-6 ${isOverdue ? 'border-destructive/30' : 'border-border'}`}>
                {isOverdue && <div className="bg-destructive/10 border border-destructive/20 text-destructive text-xs font-bold px-2 py-1 rounded-lg inline-flex items-center gap-1 mb-3"><AlertTriangle size={12} /> Vencida</div>}
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-4"><CreditCard size={18} className={isOverdue ? 'text-destructive' : 'text-warning'} /> {isOverdue ? 'Fatura em Atraso' : 'Próxima Fatura'}</h3>
                <div className="space-y-2">
                  <div className="flex justify-between"><span className="text-sm text-muted-foreground">Vencimento:</span><span className={`text-sm font-bold ${isOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(client.dueDate).toLocaleDateString('pt-BR')}</span></div>
                  <div className="flex justify-between"><span className="text-sm text-muted-foreground">Valor:</span><span className="text-sm font-bold text-foreground">{formatCurrency(client.amount)}</span></div>
                </div>
                {isPending && (
                  <button onClick={() => setShowPayment(true)} className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2">
                    <CreditCard size={16} /> Pagar Agora
                  </button>
                )}
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-bold text-foreground flex items-center gap-2 mb-4"><Radio size={18} className="text-primary" /> Dados de Transmissão</h3>
              <div className="space-y-4">
                {client.audioUrl && (
                  <div><label className={labelClass}>URL Servidor de Áudio</label>
                    <div className="flex gap-2"><input readOnly className="flex-1 bg-background border border-border rounded-lg p-2.5 text-foreground text-sm font-mono" value={client.audioUrl} /><button onClick={() => copyToClipboard(client.audioUrl)} className="p-2.5 bg-secondary border border-border hover:bg-muted text-foreground rounded-lg transition-colors"><Copy size={16} /></button></div>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4">
                  <div><label className={labelClass}>Porta</label><div className="flex gap-2"><input readOnly className="flex-1 bg-background border border-border rounded-lg p-2.5 text-foreground text-sm font-mono" value={client.port} /><button onClick={() => copyToClipboard(client.port)} className="p-2.5 bg-secondary border border-border hover:bg-muted text-foreground rounded-lg transition-colors"><Copy size={16} /></button></div></div>
                  <div><label className={labelClass}>Senha</label><div className="flex gap-2"><input readOnly className="flex-1 bg-background border border-border rounded-lg p-2.5 text-foreground text-sm font-mono" value={client.password} /><button onClick={() => copyToClipboard(client.password)} className="p-2.5 bg-secondary border border-border hover:bg-muted text-foreground rounded-lg transition-colors"><Copy size={16} /></button></div></div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* ===== INVOICES ===== */}
        {view === 'invoices' && (
          <div className="space-y-4">
            {/* Current Invoice */}
            <div className={`bg-card border rounded-2xl p-6 ${isOverdue ? 'border-destructive/30' : 'border-border'}`}>
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  {companySettings.logoUrl && <img src={companySettings.logoUrl} className="w-10 h-10 rounded-lg object-cover" alt="" />}
                  <div>
                    <h4 className="font-bold text-foreground">Fatura Atual</h4>
                    <p className="text-[10px] text-muted-foreground">{companySettings.name}</p>
                  </div>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${client.paymentStatus === 'paid' ? 'bg-success/10 text-success border-success/20' : isOverdue ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-warning/10 text-warning border-warning/20'}`}>
                  {client.paymentStatus === 'paid' ? 'Pago' : isOverdue ? 'Vencida' : 'A Vencer'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Valor</p><p className="text-lg font-bold text-foreground">{formatCurrency(client.amount)}</p></div>
                <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Vencimento</p><p className={`text-lg font-bold ${isOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(client.dueDate).toLocaleDateString('pt-BR')}</p></div>
                <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Plano</p><p className="text-lg font-bold text-foreground">{plan?.name || '—'}</p></div>
              </div>
              {isPending && (
                <button onClick={() => setShowPayment(true)} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 text-sm">
                  <CreditCard size={16} /> Pagar Esta Fatura
                </button>
              )}
            </div>

            {/* History */}
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-border"><h4 className="font-bold text-foreground text-sm">Histórico de Faturas</h4></div>
              <table className="w-full text-left text-sm">
                <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
                  <tr><th className="px-6 py-3">Data</th><th className="px-6 py-3">Descrição</th><th className="px-6 py-3">Valor</th><th className="px-6 py-3">Status</th><th className="px-6 py-3 text-right">Ações</th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {clientTxs.map(tx => {
                    const txOverdue = tx.status !== 'paid' && tx.status !== 'cancelled' && (tx.dueDate || tx.date) < new Date().toISOString().split('T')[0];
                    const statusLabel = tx.status === 'paid' ? 'Pago' : tx.status === 'cancelled' ? 'Cancelada' : txOverdue ? 'Vencida' : 'Pendente';
                    const statusClass = tx.status === 'paid' ? 'bg-success/10 text-success border-success/20' : tx.status === 'cancelled' ? 'bg-muted text-muted-foreground border-border' : txOverdue ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-warning/10 text-warning border-warning/20';
                    return (
                      <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                        <td className="px-6 py-3 text-muted-foreground">{new Date(tx.date).toLocaleDateString('pt-BR')}</td>
                        <td className="px-6 py-3 font-medium text-foreground">{tx.description}</td>
                        <td className={`px-6 py-3 font-mono font-bold ${tx.status === 'paid' ? 'text-success' : 'text-foreground'}`}>{formatCurrency(tx.amount)}</td>
                        <td className="px-6 py-3"><span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusClass}`}>{statusLabel}</span></td>
                        <td className="px-6 py-3 text-right flex items-center justify-end gap-1.5">
                          {tx.status === 'paid' && (
                            <button onClick={() => handlePrintReceipt(tx)} className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-2 py-1 rounded-lg text-[10px] font-bold transition-colors inline-flex items-center gap-1">
                              <Printer size={12} /> Recibo
                            </button>
                          )}
                          {tx.status !== 'paid' && tx.status !== 'cancelled' && (
                            <button onClick={() => setShowPayment(true)} className="bg-primary hover:bg-primary/90 text-primary-foreground px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors inline-flex items-center gap-1">
                              <CreditCard size={12} /> Pagar
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {clientTxs.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhuma fatura registrada.</div>}
            </div>
          </div>
        )}

        {/* ===== SUPPORT ===== */}
        {view === 'support' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-foreground">Meus Tickets de Suporte</h3>
              <div className="flex gap-2">
                <button onClick={contactWhatsApp} className="bg-success/10 hover:bg-success/20 text-success border border-success/20 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors">
                  <MessageCircle size={14} /> WhatsApp
                </button>
                <button onClick={() => setShowNewTicket(true)} className="bg-primary hover:bg-primary/80 text-primary-foreground px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors">
                  <Plus size={14} /> Novo Ticket
                </button>
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl overflow-hidden divide-y divide-border">
              {clientTickets.length > 0 ? clientTickets.map(ticket => {
                const sc = statusConfig[ticket.status];
                const msgCount = ticket.history?.length || 0;
                const ticketUnread = (ticket.history || []).filter(m =>
                  (m.type === 'admin' || m.type === 'system') && (!ticket.lastClientReadAt || new Date(m.date) > new Date(ticket.lastClientReadAt))
                ).length;
                return (
                  <div key={ticket.id} className={`p-5 hover:bg-secondary/30 transition-colors cursor-pointer group ${ticketUnread > 0 ? 'border-l-4 border-l-destructive' : ''}`} onClick={() => setChatTicket(ticket)}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${sc.class}`}>{sc.icon} {sc.label}</span>
                          <span className="text-[10px] text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString('pt-BR')}</span>
                          {msgCount > 0 && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-secondary text-muted-foreground">
                              <MessageCircle size={10} /> {msgCount}
                            </span>
                          )}
                          {ticketUnread > 0 && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-destructive text-destructive-foreground animate-pulse">
                              🔔 {ticketUnread} nova{ticketUnread > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-foreground group-hover:text-primary transition-colors">{ticket.subject}</h4>
                        {ticket.description && <p className="text-xs text-muted-foreground mt-1">{ticket.description}</p>}
                        {ticket.status === 'scheduled' && ticket.scheduledDate && (
                          <p className="text-xs text-primary mt-1 font-medium">📅 {new Date(ticket.scheduledDate).toLocaleDateString('pt-BR')} às {ticket.scheduledTime}</p>
                        )}
                      </div>
                      <button className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 flex-shrink-0">
                        <MessageCircle size={14} /> Chat
                      </button>
                    </div>
                  </div>
                );
              }) : <div className="p-12 text-center text-muted-foreground">Nenhum ticket registrado. Abra um novo caso precise de suporte!</div>}
            </div>

            {/* New Ticket Modal */}
            {showNewTicket && (
              <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-foreground flex items-center gap-2"><LifeBuoy size={18} className="text-primary" /> Novo Ticket</h3>
                    <button onClick={() => setShowNewTicket(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
                  </div>
                  <div><label className={labelClass}>Assunto</label><input className={inputClass} value={ticketForm.subject} onChange={e => setTicketForm({ ...ticketForm, subject: e.target.value })} placeholder="Ex: Problema no stream" /></div>
                  <div><label className={labelClass}>Descrição</label><textarea className={`${inputClass} h-20 resize-none`} value={ticketForm.description} onChange={e => setTicketForm({ ...ticketForm, description: e.target.value })} placeholder="Descreva o problema..." /></div>
                  <button onClick={handleAddTicket} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-xl font-bold transition-colors flex items-center justify-center gap-2">
                    <MessageCircle size={16} /> Enviar & Abrir Chat
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== DOWNLOADS ===== */}
        {view === 'downloads' && (() => {
          const clientFolders = downloadFolders.filter(f => f.clientIds.includes(client.id));
          const formatSize = (bytes: number) => {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
          };
          const handleDownload = (file: { data: string; name: string }) => {
            const a = document.createElement('a');
            a.href = file.data;
            a.download = file.name;
            a.click();
          };
          const getFileIcon = (type: string) => {
            if (type.includes('zip') || type.includes('rar') || type.includes('compressed')) return <Archive size={16} className="text-warning" />;
            if (type.includes('image')) return <FileText size={16} className="text-info" />;
            if (type.includes('pdf')) return <FileText size={16} className="text-destructive" />;
            return <FileText size={16} className="text-muted-foreground" />;
          };
          return (
            <div className="space-y-4">
              <h3 className="font-bold text-foreground flex items-center gap-2"><Download size={18} /> Meus Downloads</h3>
              {clientFolders.length === 0 ? (
                <div className="bg-card border border-border rounded-2xl p-12 text-center">
                  <Download size={32} className="mx-auto text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">Nenhum arquivo disponível no momento.</p>
                </div>
              ) : (
                clientFolders.map(folder => {
                  const folderFiles = downloadFiles.filter(f => f.folderId === folder.id);
                  return (
                    <div key={folder.id} className="bg-card border border-border rounded-2xl overflow-hidden">
                      <div className="p-4 border-b border-border flex items-center gap-3">
                        <FolderOpen size={20} className="text-warning" />
                        <div>
                          <p className="text-sm font-bold text-foreground">{folder.name}</p>
                          <p className="text-[10px] text-muted-foreground">{folderFiles.length} arquivo{folderFiles.length !== 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      {folderFiles.length === 0 ? (
                        <p className="p-4 text-sm text-muted-foreground text-center">Pasta vazia</p>
                      ) : (
                        <div className="divide-y divide-border">
                          {folderFiles.map(file => (
                            <div key={file.id} className="p-3 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                              {getFileIcon(file.type)}
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
                                <p className="text-[10px] text-muted-foreground">{formatSize(file.size)} • {new Date(file.createdAt).toLocaleDateString()}</p>
                              </div>
                              <button
                                onClick={() => handleDownload(file)}
                                className="flex items-center gap-1.5 bg-primary/10 text-primary px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-primary/20 transition-colors"
                              >
                                <Download size={12} /> Baixar
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          );
        })()}

        {/* ===== SETTINGS / APPEARANCE ===== */}
        {view === 'settings' && (
          <div className="space-y-4">
            <h3 className="font-bold text-foreground flex items-center gap-2"><Palette size={18} /> Aparência</h3>
            <div className="bg-card border border-border rounded-2xl p-6 space-y-6">
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block font-medium">Tema</label>
                <div className="flex gap-3">
                  <button onClick={() => setSettings(prev => ({ ...prev, theme: 'dark' }))}
                    className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold border transition-all ${companySettings.theme === 'dark' ? 'bg-primary/10 text-primary border-primary/30 shadow-sm' : 'bg-secondary text-muted-foreground border-border hover:text-foreground'}`}>
                    <Moon size={18} /> Escuro
                  </button>
                  <button onClick={() => setSettings(prev => ({ ...prev, theme: 'light' }))}
                    className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold border transition-all ${companySettings.theme === 'light' ? 'bg-primary/10 text-primary border-primary/30 shadow-sm' : 'bg-secondary text-muted-foreground border-border hover:text-foreground'}`}>
                    <Sun size={18} /> Claro
                  </button>
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block font-medium">Tamanho da Fonte</label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setSettings(prev => ({ ...prev, fontSize: Math.max(1, prev.fontSize - 1) }))}
                    disabled={companySettings.fontSize <= 1}
                    className="w-12 h-12 rounded-xl border border-border bg-secondary text-foreground flex items-center justify-center hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Minus size={20} />
                  </button>
                  <div className="flex-1 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {[1, 2, 3, 4, 5].map(level => (
                        <div
                          key={level}
                          className={`h-2 flex-1 rounded-full transition-colors ${level <= companySettings.fontSize ? 'bg-primary' : 'bg-border'}`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      {companySettings.fontSize === 1 ? 'Muito Pequena' : companySettings.fontSize === 2 ? 'Pequena' : companySettings.fontSize === 3 ? 'Média' : companySettings.fontSize === 4 ? 'Grande' : 'Muito Grande'}
                    </p>
                  </div>
                  <button
                    onClick={() => setSettings(prev => ({ ...prev, fontSize: Math.min(5, prev.fontSize + 1) }))}
                    disabled={companySettings.fontSize >= 5}
                    className="w-12 h-12 rounded-xl border border-border bg-secondary text-foreground flex items-center justify-center hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
      </main>

      {/* ===== PAYMENT MODAL ===== */}
      {showPayment && isPending && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-start sm:items-center justify-center p-2 animate-fade-in overflow-y-auto">
          <div className="bg-card border border-border rounded-xl w-full max-w-[95vw] sm:max-w-lg p-3 sm:p-4 space-y-2 sm:space-y-3 my-2 sm:my-0">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-foreground flex items-center gap-2 text-sm"><CreditCard size={16} className="text-primary" /> Pagar Fatura</h3>
              <button onClick={() => setShowPayment(false)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>

            {/* Invoice Summary - Compact */}
            <div className="bg-secondary/30 border border-border rounded-lg p-2.5">
              <div className="flex items-center gap-2 mb-2">
                {companySettings.logoUrl && <img src={companySettings.logoUrl} className="w-8 h-8 rounded-md object-cover" alt="" />}
                <div>
                  <p className="text-xs font-bold text-foreground">{companySettings.name}</p>
                  <p className="text-[9px] text-muted-foreground">CNPJ: {companySettings.document || '—'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                <div><span className="text-muted-foreground">Cliente:</span><p className="font-bold text-foreground truncate">{client.name}</p></div>
                <div><span className="text-muted-foreground">Vencimento:</span><p className={`font-bold ${isOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(client.dueDate).toLocaleDateString('pt-BR')}</p></div>
                <div><span className="text-muted-foreground">Plano:</span><p className="font-bold text-foreground truncate">{plan?.name || '—'}</p></div>
                <div><span className="text-muted-foreground">Valor:</span><p className="font-bold text-foreground text-sm">{formatCurrency(client.amount)}</p></div>
              </div>
              {isOverdue && <p className="text-[10px] text-destructive font-bold mt-1.5">⚠️ Fatura vencida!</p>}
            </div>

            {/* Payment Methods - 2 columns */}
            <div className="space-y-2">
              <h4 className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Formas de Pagamento</h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* PIX Key */}
                {companySettings.pixKey && (
                  <div className="bg-background border border-border rounded-lg p-2">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <QrCode size={14} className="text-primary" />
                      <h5 className="font-bold text-foreground text-[10px]">PIX</h5>
                      <span className="bg-success/10 text-success text-[8px] font-bold px-1 py-0.5 rounded-full border border-success/20">Recomendado</span>
                    </div>
                    <div className="space-y-1.5">
                      <div>
                        <label className="text-[8px] text-muted-foreground uppercase block mb-0.5">Chave PIX</label>
                        <div className="flex gap-1">
                          <input readOnly className="flex-1 bg-secondary/50 border border-border rounded p-1 text-foreground text-[10px] font-mono truncate" value={companySettings.pixKey} />
                          <button onClick={() => copyToClipboard(companySettings.pixKey)} className="px-1.5 bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 rounded text-[9px] font-bold transition-colors shrink-0">Copiar</button>
                        </div>
                      </div>
                      {pixPayload && (
                        <div>
                          <label className="text-[8px] text-muted-foreground uppercase block mb-0.5">Copia e Cola</label>
                          <div className="flex gap-1">
                            <input readOnly className="flex-1 bg-secondary/50 border border-border rounded p-1 text-foreground text-[8px] font-mono truncate" value={pixPayload} />
                            <button onClick={() => copyToClipboard(pixPayload)} className="px-1.5 bg-success/10 text-success border border-success/20 hover:bg-success/20 rounded text-[9px] font-bold transition-colors shrink-0">Copiar</button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* QR Code */}
                {companySettings.pixQrCodeUrl && (
                  <div className="flex flex-col items-center justify-center bg-background border border-border rounded-lg p-2">
                    <label className="text-[8px] text-muted-foreground uppercase block mb-1 font-bold">QR Code PIX</label>
                    <img src={companySettings.pixQrCodeUrl} alt="QR Code PIX" className="w-36 h-36 rounded border border-border object-contain bg-white p-1" />
                  </div>
                )}

                {/* Bank Transfer */}
                {companySettings.bankInfo && (
                  <div className="bg-background border border-border rounded-lg p-2">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Building2 size={14} className="text-primary" />
                      <h5 className="font-bold text-foreground text-[10px]">Transferência</h5>
                    </div>
                    <p className="text-[10px] text-foreground whitespace-pre-line leading-tight">{companySettings.bankInfo}</p>
                  </div>
                )}

                {/* Other Methods */}
                {companySettings.paymentMethods && (
                  <div className="bg-background border border-border rounded-lg p-2">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Banknote size={14} className="text-primary" />
                      <h5 className="font-bold text-foreground text-[10px]">Outras Formas</h5>
                    </div>
                    <p className="text-[10px] text-foreground whitespace-pre-line leading-tight">{companySettings.paymentMethods}</p>
                  </div>
                )}
              </div>
            </div>

            <a 
              href={`https://wa.me/${companySettings.phone?.replace(/\D/g, '')}?text=${encodeURIComponent(`Olá! Sou ${client.name}, acabei de efetuar o pagamento da fatura de ${formatCurrency(client.amount)} com vencimento ${new Date(client.dueDate).toLocaleDateString('pt-BR')}. Aguardo confirmação.`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-success hover:bg-success/80 text-success-foreground py-2 rounded-lg font-bold transition-colors flex items-center justify-center gap-2 text-xs"
            >
              <MessageCircle size={14} /> Confirmar via WhatsApp
            </a>
            <p className="text-[9px] text-muted-foreground text-center">Envie o comprovante via WhatsApp para confirmação.</p>
          </div>
        </div>
      )}

      {/* Chat Modal */}
      {chatTicket && (
        <ClientTicketChat
          ticket={chatTicket}
          clientName={client.name}
          clientPhone={client.phone}
          companySettings={companySettings}
          onClose={() => setChatTicket(null)}
          onUpdateTicket={handleUpdateTicket}
        />
      )}
    </div>
  );
}
