import React, { useState } from 'react';
import {
  BarChart3, Users, FileText, CreditCard, Settings, ChevronRight, Radio, Menu, LifeBuoy, Server,
  Download, ChevronDown, Palette, Building, Key, MessageCircle, Save,
} from 'lucide-react';
import type { ViewType } from '@/lib/types';

export type SettingsSection = 'appearance' | 'company' | 'payment' | 'access' | 'backup' | 'templates';

interface SidebarProps {
  activeView: ViewType;
  onNavigate: (view: ViewType) => void;
  companyName: string;
  logoUrl?: string;
  unreadSupportCount?: number;
  settingsSection?: SettingsSection;
  onSettingsSection?: (section: SettingsSection) => void;
}

const navItems: { id: ViewType; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <BarChart3 size={20} /> },
  { id: 'clients', label: 'Clientes', icon: <Users size={20} /> },
  { id: 'invoices', label: 'Faturas', icon: <FileText size={20} /> },
  { id: 'plans', label: 'Planos', icon: <CreditCard size={20} /> },
  { id: 'servers', label: 'Servidores', icon: <Server size={20} /> },
  { id: 'downloads', label: 'Downloads', icon: <Download size={20} /> },
  { id: 'support', label: 'Suporte', icon: <LifeBuoy size={20} /> },
];

const settingsSubItems: { id: SettingsSection; label: string; icon: React.ReactNode }[] = [
  { id: 'appearance', label: 'Aparência', icon: <Palette size={16} /> },
  { id: 'company', label: 'Dados da Empresa', icon: <Building size={16} /> },
  { id: 'payment', label: 'Pagamento', icon: <CreditCard size={16} /> },
  { id: 'access', label: 'Acesso Admin', icon: <Key size={16} /> },
  { id: 'backup', label: 'Backup & Restauração', icon: <Save size={16} /> },
  { id: 'templates', label: 'Templates', icon: <MessageCircle size={16} /> },
];

export function AppSidebar({ activeView, onNavigate, companyName, logoUrl, unreadSupportCount = 0, settingsSection = 'appearance', onSettingsSection }: SidebarProps) {
  const [expanded, setExpanded] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(activeView === 'settings');

  const handleSettingsClick = () => {
    if (activeView === 'settings') {
      setSettingsOpen(!settingsOpen);
    } else {
      setSettingsOpen(true);
      onNavigate('settings');
    }
  };

  const handleSubClick = (section: SettingsSection) => {
    onNavigate('settings');
    onSettingsSection?.(section);
  };

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col z-50 transition-all duration-300 ${
        expanded ? 'w-64' : 'w-[72px]'
      }`}
    >
      {/* Header */}
      <div className="p-4 flex items-center gap-3 border-b border-sidebar-border min-h-[64px]">
        <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
          {logoUrl ? (
            <img src={logoUrl} className="w-full h-full object-cover" alt="" />
          ) : (
            <Radio size={18} className="text-primary" />
          )}
        </div>
        {expanded && (
          <div className="overflow-hidden">
            <h1 className="text-sm font-bold text-sidebar-accent-foreground truncate">StreamPRO</h1>
            <p className="text-[10px] text-sidebar-foreground truncate">{companyName}</p>
          </div>
        )}
        <button
          onClick={() => setExpanded(!expanded)}
          className="ml-auto text-sidebar-foreground hover:text-sidebar-accent-foreground transition-colors p-1"
        >
          <Menu size={18} />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = activeView === item.id;
          const showBadge = item.id === 'support' && unreadSupportCount > 0;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative ${
                isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent'
              }`}
            >
              <span className="flex-shrink-0 relative">
                {item.icon}
                {showBadge && !expanded && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-destructive text-destructive-foreground text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                    {unreadSupportCount > 9 ? '9+' : unreadSupportCount}
                  </span>
                )}
              </span>
              {expanded && (
                <>
                  <span>{item.label}</span>
                  {showBadge && (
                    <span className="ml-auto bg-destructive text-destructive-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center animate-pulse">
                      {unreadSupportCount > 99 ? '99+' : unreadSupportCount}
                    </span>
                  )}
                </>
              )}
              {isActive && expanded && !showBadge && <ChevronRight size={14} className="ml-auto opacity-60" />}
              {!expanded && (
                <div className="absolute left-full ml-2 px-2 py-1 bg-card border border-border rounded-md text-xs text-foreground whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
                  {item.label}
                  {showBadge && <span className="ml-1 text-destructive font-bold">({unreadSupportCount})</span>}
                </div>
              )}
            </button>
          );
        })}

        {/* Settings with sub-menu */}
        <div>
          <button
            onClick={handleSettingsClick}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative ${
              activeView === 'settings'
                ? 'bg-primary/10 text-primary'
                : 'text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent'
            }`}
          >
            <span className="flex-shrink-0">
              <Settings size={20} />
            </span>
            {expanded && (
              <>
                <span>Configurações</span>
                <ChevronDown
                  size={14}
                  className={`ml-auto opacity-60 transition-transform duration-200 ${settingsOpen ? 'rotate-180' : ''}`}
                />
              </>
            )}
            {!expanded && (
              <div className="absolute left-full ml-2 px-2 py-1 bg-card border border-border rounded-md text-xs text-foreground whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
                Configurações
              </div>
            )}
          </button>

          {/* Sub-items */}
          {settingsOpen && expanded && (
            <div className="mt-1 ml-5 pl-3 border-l-2 border-border space-y-0.5">
              {settingsSubItems.map((sub) => {
                const isSubActive = activeView === 'settings' && settingsSection === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => handleSubClick(sub.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                      isSubActive
                        ? 'bg-primary/10 text-primary'
                        : 'text-sidebar-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent'
                    }`}
                  >
                    <span className="flex-shrink-0">{sub.icon}</span>
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </nav>

      {/* Footer */}
      {expanded && (
        <div className="p-4 border-t border-sidebar-border">
          <p className="text-[10px] text-sidebar-foreground text-center uppercase tracking-widest">
            StreamPRO v5.0
          </p>
        </div>
      )}
    </aside>
  );
}
