import { useState } from 'react';
import { Server, Plus, X, Save, Edit, Trash2, Wifi, WifiOff, AlertTriangle, MapPin } from 'lucide-react';
import type { Server as ServerType } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface ServersViewProps {
  servers: ServerType[];
  setServers: React.Dispatch<React.SetStateAction<ServerType[]>>;
}

const typeLabels: Record<string, string> = {
  icecast: 'Icecast', wowza: 'Wowza', cpanel: 'cPanel', other: 'Outro',
};

const statusConfig = {
  online: { icon: <Wifi size={14} />, label: 'Online', class: 'bg-success/10 text-success border border-success/20' },
  offline: { icon: <WifiOff size={14} />, label: 'Offline', class: 'bg-destructive/10 text-destructive border border-destructive/20' },
  warning: { icon: <AlertTriangle size={14} />, label: 'Alerta', class: 'bg-warning/10 text-warning border border-warning/20' },
};

export function ServersView({ servers, setServers }: ServersViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingServer, setEditingServer] = useState<ServerType | null>(null);
  const [form, setForm] = useState<Partial<ServerType>>({});

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const openNew = () => {
    setEditingServer(null);
    setForm({ name: '', ip: '', port: '', type: 'icecast', capacity: 100, usage: 0, status: 'online', location: '' });
    setIsModalOpen(true);
  };

  const openEdit = (server: ServerType) => { setEditingServer(server); setForm({ ...server }); setIsModalOpen(true); };

  const handleSave = () => {
    if (!form.name || !form.ip) return;
    if (editingServer) {
      setServers(prev => prev.map(s => s.id === editingServer.id ? { ...s, ...form } as ServerType : s));
    } else {
      setServers(prev => [...prev, { ...form, id: Date.now() } as ServerType]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Remover este servidor?')) setServers(prev => prev.filter(s => s.id !== id));
  };

  const totalCapacity = servers.reduce((a, s) => a + s.capacity, 0);
  const totalUsage = servers.reduce((a, s) => a + s.usage, 0);
  const onlineCount = servers.filter(s => s.status === 'online').length;

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Servidores</h1>
          <p className="text-sm text-muted-foreground">Monitore e gerencie seus servidores de streaming e hospedagem.</p>
        </div>
        <button onClick={openNew} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap" style={{ boxShadow: 'var(--glow-primary)' }}>
          <Plus size={16} /> Novo Servidor
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card border border-border rounded-2xl p-6 border-l-4 border-l-success">
          <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">Online</p>
          <h3 className="text-3xl font-bold text-success">{onlineCount}/{servers.length}</h3>
          <p className="text-xs text-muted-foreground mt-2">Servidores ativos</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-6 border-l-4 border-l-primary">
          <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">Capacidade Total</p>
          <h3 className="text-3xl font-bold text-primary">{totalCapacity.toLocaleString()}</h3>
          <p className="text-xs text-muted-foreground mt-2">Conexões simultâneas</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-6 border-l-4 border-l-warning">
          <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">Em Uso</p>
          <h3 className="text-3xl font-bold text-warning">{totalUsage.toLocaleString()}</h3>
          <p className="text-xs text-muted-foreground mt-2">{totalCapacity > 0 ? Math.round((totalUsage / totalCapacity) * 100) : 0}% utilizado</p>
        </div>
      </div>

      {/* List Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
              <tr>
                <th className="px-6 py-4">Servidor</th>
                <th className="px-6 py-4">Tipo</th>
                <th className="px-6 py-4">IP:Porta</th>
                <th className="px-6 py-4">Localização</th>
                <th className="px-6 py-4">Uso</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {servers.map(server => {
                const sc = statusConfig[server.status];
                const usagePercent = server.capacity > 0 ? Math.round((server.usage / server.capacity) * 100) : 0;
                return (
                  <tr key={server.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
                          <Server size={16} className="text-primary" />
                        </div>
                        <span className="font-bold text-foreground">{server.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground text-xs font-medium uppercase">{typeLabels[server.type]}</td>
                    <td className="px-6 py-4 font-mono text-xs text-muted-foreground">{server.ip}:{server.port}</td>
                    <td className="px-6 py-4">
                      <span className="flex items-center gap-1 text-xs text-muted-foreground"><MapPin size={12} />{server.location}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-secondary rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${usagePercent > 90 ? 'bg-destructive' : usagePercent > 70 ? 'bg-warning' : 'bg-success'}`} style={{ width: `${Math.min(usagePercent, 100)}%` }} />
                        </div>
                        <span className={`text-xs font-bold ${usagePercent > 90 ? 'text-destructive' : usagePercent > 70 ? 'text-warning' : 'text-success'}`}>
                          {usagePercent}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${sc.class}`}>
                        {sc.icon} {sc.label}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => openEdit(server)} className="bg-info/10 hover:bg-info/20 text-info border border-info/20 p-2 rounded-lg transition-colors">
                              <Edit size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Editar configurações do servidor</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => handleDelete(server.id)} className="bg-destructive/10 hover:bg-destructive/20 text-destructive border border-destructive/20 p-2 rounded-lg transition-colors">
                              <Trash2 size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Remover servidor do sistema</TooltipContent>
                        </Tooltip>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {servers.length === 0 && (
            <div className="p-12 text-center text-muted-foreground">Nenhum servidor cadastrado.</div>
          )}
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-[70] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-foreground">{editingServer ? 'Editar Servidor' : 'Novo Servidor'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className={labelClass}>Nome</label>
                <input className={inputClass} value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="BR-01 (Áudio Icecast)" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>IP</label>
                  <input className={inputClass} value={form.ip || ''} onChange={e => setForm({ ...form, ip: e.target.value })} placeholder="192.168.1.100" />
                </div>
                <div>
                  <label className={labelClass}>Porta</label>
                  <input className={inputClass} value={form.port || ''} onChange={e => setForm({ ...form, port: e.target.value })} placeholder="8000" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Tipo</label>
                  <select className={inputClass} value={form.type || 'icecast'} onChange={e => setForm({ ...form, type: e.target.value as ServerType['type'] })}>
                    <option value="icecast">Icecast</option>
                    <option value="wowza">Wowza</option>
                    <option value="cpanel">cPanel</option>
                    <option value="other">Outro</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>Status</label>
                  <select className={inputClass} value={form.status || 'online'} onChange={e => setForm({ ...form, status: e.target.value as ServerType['status'] })}>
                    <option value="online">Online</option>
                    <option value="offline">Offline</option>
                    <option value="warning">Alerta</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Capacidade</label>
                  <input type="number" className={inputClass} value={form.capacity || ''} onChange={e => setForm({ ...form, capacity: parseInt(e.target.value) })} />
                </div>
                <div>
                  <label className={labelClass}>Em Uso</label>
                  <input type="number" className={inputClass} value={form.usage || ''} onChange={e => setForm({ ...form, usage: parseInt(e.target.value) })} />
                </div>
              </div>
              <div>
                <label className={labelClass}>Localização</label>
                <input className={inputClass} value={form.location || ''} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="São Paulo, BR" />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-border">
              <button onClick={() => setIsModalOpen(false)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Cancelar</button>
              <button onClick={handleSave} className="bg-primary hover:bg-primary/80 text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-bold transition-colors flex items-center gap-2" style={{ boxShadow: 'var(--glow-primary)' }}>
                <Save size={16} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
