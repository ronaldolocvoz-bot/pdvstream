import { useState, useRef } from 'react';
import { FolderPlus, Upload, Trash2, FolderOpen, FileIcon, Download, Users, Check, X, Search, Archive } from 'lucide-react';
import type { DownloadFolder, DownloadFile, Client } from '@/lib/types';
import { toast } from 'sonner';

interface DownloadsViewProps {
  folders: DownloadFolder[];
  setFolders: React.Dispatch<React.SetStateAction<DownloadFolder[]>>;
  files: DownloadFile[];
  setFiles: React.Dispatch<React.SetStateAction<DownloadFile[]>>;
  clients: Client[];
}

export function DownloadsView({ folders, setFolders, files, setFiles, clients }: DownloadsViewProps) {
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [showReleaseModal, setShowReleaseModal] = useState<string | null>(null);
  const [selectedClients, setSelectedClients] = useState<number[]>([]);
  const [searchClients, setSearchClients] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm";

  const handleCreateFolder = () => {
    if (!newFolderName.trim()) return;
    const folder: DownloadFolder = {
      id: Date.now().toString(),
      name: newFolderName.trim(),
      createdAt: new Date().toISOString(),
      clientIds: [],
    };
    setFolders(prev => [...prev, folder]);
    setNewFolderName('');
    setShowNewFolder(false);
    toast.success('Pasta criada com sucesso!');
  };

  const handleDeleteFolder = (folderId: string) => {
    if (!window.confirm('Excluir esta pasta e todos os arquivos dentro dela?')) return;
    setFolders(prev => prev.filter(f => f.id !== folderId));
    setFiles(prev => prev.filter(f => f.folderId !== folderId));
    if (selectedFolder === folderId) setSelectedFolder(null);
    toast.success('Pasta excluída!');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadFiles = e.target.files;
    if (!uploadFiles || !selectedFolder) return;

    Array.from(uploadFiles).forEach(file => {
      if (file.size > 50 * 1024 * 1024) {
        toast.error(`${file.name} excede 50MB`);
        return;
      }
      const reader = new FileReader();
      reader.onload = (ev) => {
        const newFile: DownloadFile = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
          folderId: selectedFolder,
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          data: ev.target?.result as string,
          createdAt: new Date().toISOString(),
        };
        setFiles(prev => [...prev, newFile]);
        toast.success(`${file.name} enviado!`);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const handleDeleteFile = (fileId: string) => {
    if (!window.confirm('Excluir este arquivo?')) return;
    setFiles(prev => prev.filter(f => f.id !== fileId));
    toast.success('Arquivo excluído!');
  };

  const handleDownloadFile = (file: DownloadFile) => {
    const a = document.createElement('a');
    a.href = file.data;
    a.download = file.name;
    a.click();
  };

  const openReleaseModal = (folderId: string) => {
    const folder = folders.find(f => f.id === folderId);
    setSelectedClients(folder?.clientIds || []);
    setShowReleaseModal(folderId);
    setSearchClients('');
  };

  const handleSaveRelease = () => {
    if (!showReleaseModal) return;
    setFolders(prev => prev.map(f =>
      f.id === showReleaseModal ? { ...f, clientIds: selectedClients } : f
    ));
    setShowReleaseModal(null);
    toast.success('Liberação atualizada!');
  };

  const toggleClient = (clientId: number) => {
    setSelectedClients(prev =>
      prev.includes(clientId) ? prev.filter(id => id !== clientId) : [...prev, clientId]
    );
  };

  const selectAllClients = () => {
    setSelectedClients(clients.map(c => c.id));
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const folderFiles = selectedFolder ? files.filter(f => f.folderId === selectedFolder) : [];
  const currentFolder = folders.find(f => f.id === selectedFolder);
  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(searchClients.toLowerCase()) ||
    c.phone.includes(searchClients)
  );

  const getFileIcon = (type: string) => {
    if (type.includes('zip') || type.includes('rar') || type.includes('compressed')) return <Archive size={18} className="text-warning" />;
    if (type.includes('image')) return <FileIcon size={18} className="text-info" />;
    if (type.includes('pdf')) return <FileIcon size={18} className="text-destructive" />;
    return <FileIcon size={18} className="text-muted-foreground" />;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Downloads</h1>
          <p className="text-sm text-muted-foreground">Gerencie pastas e arquivos para seus clientes.</p>
        </div>
        <button
          onClick={() => setShowNewFolder(true)}
          className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold hover:bg-primary/90 transition-colors"
        >
          <FolderPlus size={16} /> Nova Pasta
        </button>
      </div>

      {/* New Folder Input */}
      {showNewFolder && (
        <div className="bg-card border border-border rounded-xl p-4 mb-4 flex items-center gap-3">
          <FolderOpen size={20} className="text-primary" />
          <input
            className={inputClass}
            placeholder="Nome da pasta..."
            value={newFolderName}
            onChange={e => setNewFolderName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleCreateFolder()}
            autoFocus
          />
          <button onClick={handleCreateFolder} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-bold hover:bg-primary/90">
            Criar
          </button>
          <button onClick={() => { setShowNewFolder(false); setNewFolderName(''); }} className="text-muted-foreground hover:text-foreground p-2">
            <X size={16} />
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Folders List */}
        <div className="lg:col-span-1">
          <h2 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wider">Pastas</h2>
          <div className="space-y-2">
            {folders.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">Nenhuma pasta criada.</p>
            )}
            {folders.map(folder => {
              const fileCount = files.filter(f => f.folderId === folder.id).length;
              const isSelected = selectedFolder === folder.id;
              return (
                <div
                  key={folder.id}
                  onClick={() => setSelectedFolder(folder.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all group ${
                    isSelected
                      ? 'bg-primary/10 border-primary/30'
                      : 'bg-card border-border hover:border-primary/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <FolderOpen size={20} className={isSelected ? 'text-primary' : 'text-warning'} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-foreground truncate">{folder.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {fileCount} arquivo{fileCount !== 1 ? 's' : ''} •{' '}
                        {folder.clientIds.length > 0
                          ? <span className="text-green-400">{folder.clientIds.length} cliente{folder.clientIds.length !== 1 ? 's' : ''}</span>
                          : <span className="text-muted-foreground">Não liberada</span>
                        }
                      </p>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => { e.stopPropagation(); openReleaseModal(folder.id); }}
                        className="p-1.5 rounded-lg hover:bg-primary/10 text-primary transition-colors"
                        title="Liberar para clientes"
                      >
                        <Users size={14} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteFolder(folder.id); }}
                        className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                        title="Excluir pasta"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Files Area */}
        <div className="lg:col-span-2">
          {selectedFolder && currentFolder ? (
            <>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-bold text-foreground uppercase tracking-wider">
                  📁 {currentFolder.name}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openReleaseModal(selectedFolder)}
                    className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                  >
                    <Users size={14} />
                    {currentFolder.clientIds.length > 0
                      ? `${currentFolder.clientIds.length} cliente(s)`
                      : 'Liberar'}
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 bg-primary text-primary-foreground px-3 py-2 rounded-lg text-xs font-bold hover:bg-primary/90 transition-colors"
                  >
                    <Upload size={14} /> Upload
                  </button>
                </div>
              </div>

              {folderFiles.length === 0 ? (
                <div className="bg-card border border-dashed border-border rounded-xl p-12 text-center">
                  <Upload size={32} className="mx-auto text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">Nenhum arquivo nesta pasta.</p>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-3 text-xs font-bold text-primary hover:text-primary/80"
                  >
                    Clique para enviar arquivos
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {folderFiles.map(file => (
                    <div key={file.id} className="bg-card border border-border rounded-xl p-3 flex items-center gap-3 group hover:border-primary/20 transition-colors">
                      {getFileIcon(file.type)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {formatSize(file.size)} • {new Date(file.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleDownloadFile(file)}
                          className="p-1.5 rounded-lg hover:bg-primary/10 text-primary transition-colors"
                          title="Baixar"
                        >
                          <Download size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteFile(file.id)}
                          className="p-1.5 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="bg-card border border-dashed border-border rounded-xl p-12 text-center">
              <FolderOpen size={40} className="mx-auto text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">Selecione uma pasta para ver os arquivos.</p>
            </div>
          )}
        </div>
      </div>

      {/* File input hidden */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        multiple
        onChange={handleFileUpload}
        accept="*/*"
      />

      {/* Release Modal */}
      {showReleaseModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div>
                <h3 className="font-bold text-foreground flex items-center gap-2">
                  <Users size={18} className="text-primary" /> Liberar para Clientes
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {folders.find(f => f.id === showReleaseModal)?.name}
                </p>
              </div>
              <button onClick={() => setShowReleaseModal(null)} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  className={`${inputClass} pl-8`}
                  placeholder="Buscar cliente..."
                  value={searchClients}
                  onChange={e => setSearchClients(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2 mt-2">
                <button onClick={selectAllClients} className="text-[10px] text-primary font-bold hover:text-primary/80">
                  Selecionar todos
                </button>
                <span className="text-muted-foreground text-[10px]">•</span>
                <button onClick={() => setSelectedClients([])} className="text-[10px] text-muted-foreground font-bold hover:text-foreground">
                  Limpar
                </button>
                <span className="ml-auto text-[10px] text-muted-foreground">
                  {selectedClients.length} selecionado(s)
                </span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              {filteredClients.map(client => {
                const isSelected = selectedClients.includes(client.id);
                return (
                  <button
                    key={client.id}
                    onClick={() => toggleClient(client.id)}
                    className={`w-full flex items-center gap-3 p-2.5 rounded-lg text-left transition-colors ${
                      isSelected ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted border border-transparent'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center flex-shrink-0 transition-colors ${
                      isSelected ? 'bg-primary border-primary' : 'border-border'
                    }`}>
                      {isSelected && <Check size={12} className="text-primary-foreground" />}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{client.name}</p>
                      <p className="text-[10px] text-muted-foreground">{client.phone}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="p-4 border-t border-border">
              <button
                onClick={handleSaveRelease}
                className="w-full bg-primary text-primary-foreground py-2.5 rounded-xl text-sm font-bold hover:bg-primary/90 transition-colors"
              >
                Salvar Liberação
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
