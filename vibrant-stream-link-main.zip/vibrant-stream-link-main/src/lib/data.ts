import type { Client, Plan, Category, Transaction, CompanySettings, Ticket, Server } from './types';

export const defaultCategories: Category[] = [
  { id: 'Streaming Áudio', iconName: 'radio', color: 'bg-info/10 text-info border border-info/20' },
  { id: 'Streaming Vídeo', iconName: 'video', color: 'bg-primary/10 text-primary border border-primary/20' },
  { id: 'Hospedagem', iconName: 'server', color: 'bg-muted text-muted-foreground border border-border' },
  { id: 'Combo', iconName: 'layers', color: 'bg-warning/10 text-warning border border-warning/20' },
  { id: 'Outros', iconName: 'tag', color: 'bg-secondary text-secondary-foreground border border-border' },
];

export const defaultPlans: Plan[] = [
  { id: 'basic', name: 'Plano Start', price: 49.90, cost: 15.00, stock: -1, details: '64kbps, 100 ouvintes', category: 'Streaming Áudio', type: 'plan', active: true },
  { id: 'standard', name: 'Plano Gold', price: 89.90, cost: 25.00, stock: -1, details: '128kbps, 500 ouvintes', category: 'Streaming Áudio', type: 'plan', active: true },
  { id: 'pro', name: 'Plano Premium', price: 149.90, cost: 40.00, stock: 50, details: '320kbps, Ilimitado', category: 'Streaming Áudio', type: 'plan', active: true },
  { id: 'video', name: 'Web TV Full HD', price: 299.90, cost: 100.00, stock: -1, details: '1080p, Tráfego Ilimitado', category: 'Streaming Vídeo', type: 'plan', active: true },
  { id: 'host', name: 'Hospedagem Básica', price: 29.90, cost: 5.00, stock: -1, details: '5GB SSD, Tráfego Ilimitado', category: 'Hospedagem', type: 'service', active: true },
];

export const defaultServers: Server[] = [
  { id: 1, name: 'BR-01 (Áudio Icecast)', ip: '192.168.1.100', port: '8000', type: 'icecast', capacity: 1000, usage: 450, status: 'online', location: 'São Paulo, BR' },
  { id: 2, name: 'EUA-01 (Vídeo Wowza)', ip: '104.20.5.10', port: '1935', type: 'wowza', capacity: 500, usage: 120, status: 'online', location: 'Nova York, US' },
  { id: 3, name: 'BR-02 (Hospedagem cPanel)', ip: '192.168.1.105', port: '2083', type: 'cpanel', capacity: 200, usage: 195, status: 'warning', location: 'São Paulo, BR' },
];

export const defaultClients: Client[] = [
  {
    id: 1, name: 'Rádio Exemplo FM', ownerName: 'Admin',
    cep: '01001-000', address: 'Praça da Sé', neighborhood: 'Sé', city: 'São Paulo', state: 'SP',
    website: 'www.radioexemplo.com', logoUrl: '',
    audioUrl: 'https://stream.zeno.fm/r5pq15k8558uv',
    document: '', videoUrl: '', port: '8000', password: '123456',
    status: 'active', paymentStatus: 'paid',
    recurrence: 'monthly', planId: 'pro', amount: 149.90,
    startDate: '2023-11-01', dueDate: '2024-12-30',
    phone: '5561998585665', birthday: '', serviceType: 'radio', serverId: 1,
    schedules: [],
    createdAt: new Date().toISOString(),
    history: [{ date: new Date().toISOString(), action: 'Cadastro realizado', user: 'Sistema' }],
  },
];

export const defaultTransactions: Transaction[] = [
  { id: 1, date: new Date(Date.now() - 86400000 * 30).toISOString(), amount: 149.90, type: 'income', status: 'paid', clientName: 'Rádio Exemplo FM', description: 'Mensalidade Streaming', clientId: 1 },
  { id: 2, date: new Date(Date.now() - 86400000 * 60).toISOString(), amount: 149.90, type: 'income', status: 'paid', clientName: 'Rádio Exemplo FM', description: 'Mensalidade Streaming', clientId: 1 },
  { id: 3, date: new Date(Date.now() - 86400000 * 5).toISOString(), amount: 250.00, type: 'expense', status: 'paid', clientName: 'DigitalOcean', description: 'Pagamento Servidor VPS' },
];

export const defaultTickets: Ticket[] = [
  {
    id: 1, clientId: 1, subject: 'Dúvida na configuração do AutoDJ',
    description: 'O cliente não está conseguindo enviar as músicas para o servidor.',
    status: 'open', scheduledDate: '', scheduledTime: '',
    createdAt: new Date().toISOString(),
    history: [{ id: Date.now(), type: 'system', text: 'Chamado aberto pelo sistema.', date: new Date().toISOString() }],
  },
];

export const defaultSettings: CompanySettings = {
  name: 'Minha Host Streaming',
  website: '',
  logoUrl: '',
  cep: '',
  address: 'Rua da Tecnologia, 100 - Centro',
  document: '00.000.000/0001-00',
  phone: '5511999999999',
  supportPhone: '5511999999999',
  pixKey: 'pix@minhahost.com',
  pixQrCodeUrl: '',
  bankInfo: 'Banco Digital | Ag: 0001 | CC: 123456-7',
  paymentMethods: 'Pix, Cartão, Boleto',
  adminUser: 'admin',
  adminPassword: '123',
  theme: 'dark',
  fontSize: 3,
  colorScheme: 'indigo',
  autoBackupEnabled: false,
  autoBackupDay: 1,
  templateOverdue: "Olá *{cliente}*.\n\n🚨 *Aviso de Mensalidade em Aberto*\nConstamos que sua fatura de *R$ {valor}* venceu em *{vencimento}*.\n\nPor favor, regularize para evitar a suspensão automática dos serviços de streaming.\n\n*Chave Pix:* {pix}\n\nQualquer dúvida estamos à disposição.\nAtt, {empresa}",
  templatePending: "Olá *{cliente}*.\n\n📅 *Lembrete de Fatura*\nSua fatura de *R$ {valor}* tem o vencimento agendado para o dia *{vencimento}*.\n\n*Chave Pix:* {pix}\n\nAtt, {empresa}",
  templateThanks: "Olá *{cliente}*.\n\n✅ *Pagamento Confirmado*\nRecebemos sua mensalidade de *R$ {valor}*.\n\n📄 Segue em anexo o seu recibo em PDF.\n\nObrigado pela preferência!\n\nAtt, {empresa}",
  templateWelcome: "Olá *{cliente}*! Seja muito bem-vindo(a) à *{empresa}*.\n\nSeu painel já está liberado!\n📍 *Acesso:* {link_painel}\n👤 *Usuário:* {whatsapp}\n🔑 *Senha:* {senha}\n\nQualquer dúvida, é só chamar!",
  templateSupportAccepted: "Olá *{cliente}*.\n\n👍 *Suporte Aceito*\nSeu chamado sobre *{assunto}* foi aceito pela nossa equipe técnica e será atendido em breve.\n\nAguarde que entraremos em contato!\n\nAtt, Equipe {empresa}",
  templateSupportScheduled: "Olá *{cliente}*.\n\n🛠️ *Suporte Agendado*\nO seu atendimento para tratar sobre *{assunto}* foi agendado com sucesso para *{data}* às *{hora}*.\n\nPor favor, esteja disponível neste horário para que um de nossos técnicos possa lhe auxiliar.\n\nAtt, Equipe {empresa}",
  templateSupportInProgress: "Olá *{cliente}*.\n\n🔧 *Suporte em Andamento*\nSeu chamado sobre *{assunto}* está sendo atendido agora pela nossa equipe técnica.\n\nFique atento(a) ao chat para acompanhar o progresso!\n\nAtt, Equipe {empresa}",
  templateSupportResolved: "Olá *{cliente}*.\n\n✅ *Suporte Concluído*\nO seu chamado referente a *{assunto}* foi marcado como resolvido em nosso sistema.\n\nCaso precise de mais alguma coisa, continuamos à inteira disposição!\n\nAtt, Equipe {empresa}",
};
