import { useState, useEffect, useCallback } from 'react';

export function useStickyState<T>(defaultValue: T, key: string): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [value, setValue] = useState<T>(() => {
    try {
      const stickyValue = window.localStorage.getItem(key);
      if (stickyValue !== null) {
        const parsed = JSON.parse(stickyValue);
        // Merge with defaults to pick up new fields added after initial save
        if (defaultValue && typeof defaultValue === 'object' && !Array.isArray(defaultValue) && typeof parsed === 'object' && !Array.isArray(parsed)) {
          return { ...defaultValue, ...parsed } as T;
        }
        return parsed;
      }
      return defaultValue;
    } catch {
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      const serialized = JSON.stringify(value);
      window.localStorage.setItem(key, serialized);
    } catch (e) {
      console.warn(`[useStickyState] Failed to save key "${key}" (size: ${JSON.stringify(value).length} bytes):`, e);
      // If quota exceeded, try to clear old data and retry
      try {
        window.localStorage.setItem(key, JSON.stringify(value));
      } catch {
        // Last resort: skip saving
      }
    }
  }, [key, value]);

  // Sync across tabs/windows via storage event
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === key && e.newValue !== null) {
        try {
          setValue(JSON.parse(e.newValue));
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [key]);

  return [value, setValue];
}
