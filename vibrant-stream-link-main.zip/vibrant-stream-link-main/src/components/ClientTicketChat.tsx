import { useState, useRef, useEffect } from 'react';
import { Send, X, User, Shield, Settings, MessageCircle } from 'lucide-react';
import type { Ticket, TicketMessage, CompanySettings } from '@/lib/types';

interface ClientTicketChatProps {
  ticket: Ticket;
  clientName: string;
  clientPhone: string;
  companySettings: CompanySettings;
  onClose: () => void;
  onUpdateTicket: (updated: Ticket) => void;
}

export function ClientTicketChat({ ticket, clientName, clientPhone, companySettings, onClose, onUpdateTicket }: ClientTicketChatProps) {
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const history = ticket.history || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history.length]);

  // Mark as read by client on open
  useEffect(() => {
    onUpdateTicket({ ...ticket, lastClientReadAt: new Date().toISOString() });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSend = () => {
    if (!message.trim()) return;
    const msg: TicketMessage = { id: Date.now(), type: 'client', text: message.trim(), date: new Date().toISOString() };
    onUpdateTicket({ ...ticket, history: [...history, msg], lastClientReadAt: new Date().toISOString() });
    setMessage('');
  };

  const handleWhatsApp = () => {
    const phone = companySettings.supportPhone || companySettings.phone;
    const text = `Olá! Sou ${clientName}, sobre o ticket #${ticket.id}: ${message.trim() || ticket.subject}`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const statusColors: Record<string, string> = {
    open: 'bg-warning/10 text-warning border-warning/20',
    accepted: 'bg-info/10 text-info border-info/20',
    scheduled: 'bg-primary/10 text-primary border-primary/20',
    in_progress: 'bg-accent/10 text-accent-foreground border-accent/20',
    resolved: 'bg-success/10 text-success border-success/20',
  };
  const statusLabels: Record<string, string> = {
    open: 'Aberto',
    accepted: 'Aceito',
    scheduled: 'Agendado',
    in_progress: 'Em Andamento',
    resolved: 'Resolvido',
  };

  // Count unread admin messages
  const unreadAdminMsgs = history.filter(m =>
    m.type === 'admin' && (!ticket.lastClientReadAt || new Date(m.date) > new Date(ticket.lastClientReadAt))
  ).length;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-card border border-border rounded-2xl w-full max-w-2xl flex flex-col" style={{ height: '85vh' }}>
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
              <User size={18} className="text-primary" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-foreground truncate">{ticket.subject}</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Ticket #{ticket.id}</span>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColors[ticket.status]}`}>
                  {statusLabels[ticket.status]}
                </span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          <div className="flex justify-center">
            <div className="bg-secondary/50 border border-border rounded-xl px-4 py-2 text-center max-w-xs">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Ticket #{ticket.id}</p>
              <p className="text-xs text-foreground font-medium">{ticket.subject}</p>
              {ticket.description && <p className="text-xs text-muted-foreground mt-1">{ticket.description}</p>}
              <p className="text-[10px] text-muted-foreground mt-2">{new Date(ticket.createdAt).toLocaleString('pt-BR')}</p>
            </div>
          </div>

          {ticket.scheduledDate && (
            <div className="flex justify-center">
              <div className="bg-primary/10 border border-primary/20 rounded-xl px-4 py-2 text-center">
                <p className="text-xs text-primary font-medium">📅 Agendado: {new Date(ticket.scheduledDate).toLocaleDateString('pt-BR')} às {ticket.scheduledTime}</p>
              </div>
            </div>
          )}

          {history.map(msg => (
            <div key={msg.id} className={`flex ${msg.type === 'client' ? 'justify-end' : msg.type === 'admin' ? 'justify-start' : 'justify-center'}`}>
              {msg.type === 'system' ? (
                <div className="bg-secondary/50 border border-border rounded-xl px-3 py-1.5 max-w-sm">
                  <div className="flex items-center gap-1.5">
                    <Settings size={10} className="text-muted-foreground" />
                    <p className="text-[10px] text-muted-foreground">{new Date(msg.date).toLocaleString('pt-BR')}</p>
                  </div>
                  <p className="text-xs text-foreground mt-0.5">{msg.text}</p>
                </div>
              ) : msg.type === 'client' ? (
                <div className="max-w-[75%]">
                  <div className="bg-primary text-primary-foreground rounded-2xl rounded-br-md px-4 py-2.5">
                    <p className="text-sm">{msg.text}</p>
                  </div>
                  <div className="flex items-center justify-end gap-1 mt-1">
                    <User size={10} className="text-primary" />
                    <p className="text-[10px] text-muted-foreground">Você · {new Date(msg.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              ) : (
                <div className="max-w-[75%]">
                  <div className="bg-secondary border border-border rounded-2xl rounded-bl-md px-4 py-2.5">
                    <p className="text-sm text-foreground">{msg.text}</p>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <Shield size={10} className="text-muted-foreground" />
                    <p className="text-[10px] text-muted-foreground">Suporte · {new Date(msg.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        {ticket.status !== 'resolved' ? (
          <div className="p-3 border-t border-border flex-shrink-0">
            <div className="flex gap-2">
              <input
                className="flex-1 bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm"
                placeholder="Digite sua mensagem..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
              />
              <button onClick={handleWhatsApp} className="p-2.5 rounded-lg bg-success/20 text-success hover:bg-success/30 transition-colors" title="Falar via WhatsApp">
                <MessageCircle size={18} />
              </button>
              <button onClick={handleSend} className="p-2.5 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors" title="Enviar">
                <Send size={18} />
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5 text-center">
              Enter para enviar · <MessageCircle size={8} className="inline" /> para WhatsApp
            </p>
          </div>
        ) : (
          <div className="p-3 border-t border-border text-center flex-shrink-0">
            <p className="text-xs text-success font-medium">✅ Ticket resolvido</p>
          </div>
        )}
      </div>
    </div>
  );
}
