import { ArrowDownCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import type { Client, Transaction } from '@/lib/types';
import { formatCurrency } from '@/lib/format';

interface DashboardInsightsProps {
  clients: Client[];
  transactions: Transaction[];
}

export function DashboardInsights({ clients, transactions }: DashboardInsightsProps) {
  const expensesByCat = (transactions || [])
    .filter(t => t.type === 'expense' && t.status === 'paid')
    .reduce<Record<string, number>>((acc, t) => {
      acc[t.description] = (acc[t.description] || 0) + t.amount;
      return acc;
    }, {});
  const topExpenses = Object.entries(expensesByCat).sort((a, b) => b[1] - a[1]).slice(0, 4);

  const today = new Date().toISOString().split('T')[0];
  const lateClients = (clients || [])
    .filter(c => c.status !== 'inactive' && c.paymentStatus !== 'paid' && c.dueDate < today)
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 4);

  const punctualClients = (clients || [])
    .filter(c => c.status !== 'inactive' && c.paymentStatus === 'paid')
    .sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime())
    .slice(0, 4);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
      <div className="bg-card border border-border rounded-2xl p-6">
        <h4 className="font-bold text-sm text-foreground mb-5 flex items-center gap-2">
          <ArrowDownCircle className="text-destructive" size={18} /> Onde Há Mais Gastos
        </h4>
        <div className="space-y-4">
          {topExpenses.length > 0 ? topExpenses.map((exp, i) => (
            <div key={i} className="flex justify-between items-center text-sm border-b border-border pb-3 last:border-0 last:pb-0">
              <span className="text-muted-foreground truncate mr-2 font-medium">{exp[0]}</span>
              <span className="font-bold text-destructive whitespace-nowrap">{formatCurrency(exp[1])}</span>
            </div>
          )) : <p className="text-xs text-muted-foreground italic">Nenhum gasto registado no caixa.</p>}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6">
        <h4 className="font-bold text-sm text-foreground mb-5 flex items-center gap-2">
          <CheckCircle className="text-success" size={18} /> Clientes Mais Pontuais
        </h4>
        <div className="space-y-4">
          {punctualClients.length > 0 ? punctualClients.map((c, i) => (
            <div key={i} className="flex justify-between items-center text-sm border-b border-border pb-3 last:border-0 last:pb-0">
              <div className="flex items-center gap-2 overflow-hidden mr-2">
                <div className="w-6 h-6 rounded-full bg-success/10 text-success flex items-center justify-center flex-shrink-0 text-[10px] font-bold">{i + 1}º</div>
                <span className="text-muted-foreground truncate font-medium">{c.name}</span>
              </div>
              <span className="font-bold text-success whitespace-nowrap">{formatCurrency(c.amount)}</span>
            </div>
          )) : <p className="text-xs text-muted-foreground italic">Nenhum cliente em dia.</p>}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6">
        <h4 className="font-bold text-sm text-foreground mb-5 flex items-center gap-2">
          <AlertTriangle className="text-warning" size={18} /> Maiores Atrasos
        </h4>
        <div className="space-y-4">
          {lateClients.length > 0 ? lateClients.map((c, i) => {
            const daysLate = Math.floor((Date.now() - new Date(c.dueDate).getTime()) / (1000 * 60 * 60 * 24));
            return (
              <div key={i} className="flex justify-between items-center text-sm border-b border-border pb-3 last:border-0 last:pb-0">
                <div className="flex flex-col min-w-0 mr-2">
                  <span className="text-muted-foreground truncate font-medium">{c.name}</span>
                  <span className="text-[10px] text-warning font-bold bg-warning/10 px-2 py-0.5 rounded-full w-fit mt-1">{daysLate} dias de atraso</span>
                </div>
                <span className="font-bold text-destructive whitespace-nowrap">{formatCurrency(c.amount)}</span>
              </div>
            );
          }) : <p className="text-xs text-success font-medium italic">Nenhum cliente em atraso! 🎉</p>}
        </div>
      </div>
    </div>
  );
}
