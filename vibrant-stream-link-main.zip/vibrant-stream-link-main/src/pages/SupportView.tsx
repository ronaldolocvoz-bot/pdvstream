import { useState, useEffect, useRef } from 'react';
import { LifeBuoy, Plus, X, Search, MessageCircle, CheckCircle, CalendarClock, AlertCircle, ThumbsUp, Play, Lock, Check, XCircle, Volume2, VolumeX } from 'lucide-react';
import type { Client, Ticket, CompanySettings, PasswordRecoveryRequest } from '@/lib/types';
import { TicketChat } from '@/components/TicketChat';
import { isNotificationSoundEnabled, setNotificationSoundEnabled, playNotificationSound } from '@/lib/notificationSound';

interface SupportViewProps {
  tickets: Ticket[];
  setTickets: React.Dispatch<React.SetStateAction<Ticket[]>>;
  clients: Client[];
  companySettings: CompanySettings;
  recoveryRequests?: PasswordRecoveryRequest[];
  onApproveRecovery?: (requestId: number) => void;
  onRejectRecovery?: (requestId: number) => void;
}

export function SupportView({ tickets, setTickets, clients, companySettings, recoveryRequests, onApproveRecovery, onRejectRecovery }: SupportViewProps) {
  const [activeTab, setActiveTab] = useState<'open' | 'accepted' | 'scheduled' | 'in_progress' | 'resolved'>('open');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [chatTicket, setChatTicket] = useState<Ticket | null>(null);
  const [form, setForm] = useState({ clientId: '', subject: '', description: '' });
  const [soundEnabled, setSoundEnabled] = useState(isNotificationSoundEnabled);
  const prevRecoveryCountRef = useRef<number | null>(null);

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const openNew = () => {
    setForm({ clientId: '', subject: '', description: '' });
    setIsModalOpen(true);
  };

  const handleCreate = () => {
    if (!form.clientId || !form.subject) return;
    const newTicket: Ticket = {
      id: Date.now(),
      clientId: parseInt(form.clientId),
      subject: form.subject,
      description: form.description,
      status: 'open',
      scheduledDate: '',
      scheduledTime: '',
      createdAt: new Date().toISOString(),
      history: [{
        id: 1,
        type: 'system',
        text: `📋 Ticket criado: ${form.subject}`,
        date: new Date().toISOString(),
      }],
    };
    setTickets(prev => [newTicket, ...prev]);
    setIsModalOpen(false);
    setChatTicket(newTicket);
  };

  const handleUpdateTicket = (updated: Ticket) => {
    setTickets(prev => prev.map(t => t.id === updated.id ? updated : t));
    setChatTicket(updated);
  };

  const handleDelete = (id: number) => {
    if (!window.confirm('Excluir este ticket?')) return;
    setTickets(prev => prev.filter(t => t.id !== id));
  };

  const pendingRecoveries = (recoveryRequests || []).filter(r => r.status === 'pending');

  // Play sound when new recovery requests arrive
  useEffect(() => {
    const count = pendingRecoveries.length;
    if (prevRecoveryCountRef.current !== null && count > prevRecoveryCountRef.current) {
      playNotificationSound();
    }
    prevRecoveryCountRef.current = count;
  }, [pendingRecoveries.length]);

  const handleApproveRecoveryLocal = (requestId: number) => {
    const request = pendingRecoveries.find(r => r.id === requestId);
    if (!request) return;
    const client = clients.find(c => c.id === request.clientId);
    if (!client) return;
    const message = `Olá *${client.name}*!\n\n🔐 *Recuperação de Senha*\nSua senha é: *${client.password}*\n\nSe você não solicitou, entre em contato.`;
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(message)}`, '_blank');
    onApproveRecovery?.(requestId);
  };

  const getClientName = (clientId: number) => clients.find(c => c.id === clientId)?.name || 'Cliente removido';

  const getUnreadClientMsgs = (ticket: Ticket) => {
    const history = ticket.history || [];
    return history.filter(m =>
      m.type === 'client' && (!ticket.lastAdminReadAt || new Date(m.date) > new Date(ticket.lastAdminReadAt))
    ).length;
  };

  const filtered = tickets.filter(t => {
    const matchesTab = t.status === activeTab;
    const matchesSearch = getClientName(t.clientId).toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const statusConfig: Record<string, { icon: React.ReactNode; label: string; class: string }> = {
    open: { icon: <AlertCircle size={14} />, label: 'Aberto', class: 'bg-warning/10 text-warning border border-warning/20' },
    accepted: { icon: <ThumbsUp size={14} />, label: 'Aceito', class: 'bg-info/10 text-info border border-info/20' },
    scheduled: { icon: <CalendarClock size={14} />, label: 'Agendado', class: 'bg-primary/10 text-primary border border-primary/20' },
    in_progress: { icon: <Play size={14} />, label: 'Em Andamento', class: 'bg-accent/10 text-accent-foreground border border-accent/20' },
    resolved: { icon: <CheckCircle size={14} />, label: 'Resolvido', class: 'bg-success/10 text-success border border-success/20' },
  };

  const tabs = [
    { id: 'open' as const, label: `Abertos (${tickets.filter(t => t.status === 'open').length})`, activeClass: 'text-warning border-b-2 border-warning bg-warning/5' },
    { id: 'accepted' as const, label: `Aceitos (${tickets.filter(t => t.status === 'accepted').length})`, activeClass: 'text-info border-b-2 border-info bg-info/5' },
    { id: 'scheduled' as const, label: `Agendados (${tickets.filter(t => t.status === 'scheduled').length})`, activeClass: 'text-primary border-b-2 border-primary bg-primary/5' },
    { id: 'in_progress' as const, label: `Andamento (${tickets.filter(t => t.status === 'in_progress').length})`, activeClass: 'text-accent-foreground border-b-2 border-accent bg-accent/5' },
    { id: 'resolved' as const, label: `Resolvidos (${tickets.filter(t => t.status === 'resolved').length})`, activeClass: 'text-success border-b-2 border-success bg-success/5' },
  ];

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Suporte Técnico</h1>
          <p className="text-sm text-muted-foreground">Chat de atendimento, agendamento e histórico completo.</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input type="text" placeholder="Buscar..." className={`${inputClass} pl-10`} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <button onClick={openNew} className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap" style={{ boxShadow: 'var(--glow-primary)' }}>
            <Plus size={16} /> Novo Ticket
          </button>
          <button
            onClick={() => {
              const next = !soundEnabled;
              setSoundEnabled(next);
              setNotificationSoundEnabled(next);
              if (next) playNotificationSound();
            }}
            className={`p-2.5 rounded-xl border transition-colors ${soundEnabled ? 'bg-success/10 text-success border-success/20 hover:bg-success/20' : 'bg-muted text-muted-foreground border-border hover:bg-secondary'}`}
            title={soundEnabled ? 'Som ativado' : 'Som desativado'}
          >
            {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-card border border-border rounded-2xl p-4 border-l-4 border-l-warning">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Abertos</p>
          <h3 className="text-2xl font-bold text-warning">{tickets.filter(t => t.status === 'open').length}</h3>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 border-l-4 border-l-info">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Aceitos</p>
          <h3 className="text-2xl font-bold text-info">{tickets.filter(t => t.status === 'accepted').length}</h3>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 border-l-4 border-l-primary">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Agendados</p>
          <h3 className="text-2xl font-bold text-primary">{tickets.filter(t => t.status === 'scheduled').length}</h3>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 border-l-4 border-l-accent">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Andamento</p>
          <h3 className="text-2xl font-bold text-accent-foreground">{tickets.filter(t => t.status === 'in_progress').length}</h3>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4 border-l-4 border-l-success col-span-2 md:col-span-1">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Resolvidos</p>
          <h3 className="text-2xl font-bold text-success">{tickets.filter(t => t.status === 'resolved').length}</h3>
        </div>
      </div>

      {/* Recovery Requests */}
      {pendingRecoveries.length > 0 && (
        <div className="bg-card border-2 border-warning/40 rounded-2xl overflow-hidden shadow-lg animate-fade-in">
          <div className="flex items-center gap-2 p-4 border-b border-warning/20 bg-warning/10">
            <Lock size={18} className="text-warning" />
            <h3 className="font-bold text-warning text-sm uppercase tracking-wider">
              🔑 Recuperação de Senha ({pendingRecoveries.length})
            </h3>
          </div>
          <div className="divide-y divide-border">
            {pendingRecoveries.map(r => (
              <div key={r.id} className="p-4 hover:bg-warning/5 transition-colors">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-warning/15 flex items-center justify-center flex-shrink-0">
                      <Lock size={18} className="text-warning" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">{r.clientName}</p>
                      <p className="text-sm text-muted-foreground">{r.clientPhone}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Solicitado em {new Date(r.requestedAt).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button
                      onClick={() => handleApproveRecoveryLocal(r.id)}
                      className="flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-xl bg-success/10 text-success border border-success/20 hover:bg-success/20 transition-colors"
                    >
                      <Check size={14} /> Aprovar & WhatsApp
                    </button>
                    <button
                      onClick={() => onRejectRecovery?.(r.id)}
                      className="flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-xl bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 transition-colors"
                    >
                      <XCircle size={14} /> Rejeitar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabs + List */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="flex border-b border-border overflow-x-auto custom-scrollbar">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex-1 min-w-[120px] p-3 font-bold text-xs uppercase tracking-wider transition-colors ${activeTab === tab.id ? tab.activeClass : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="divide-y divide-border">
          {filtered.length > 0 ? filtered.map(ticket => {
            const sc = statusConfig[ticket.status];
            const msgCount = ticket.history?.length || 0;
            const unreadCount = getUnreadClientMsgs(ticket);
            return (
              <div key={ticket.id} className="p-5 hover:bg-secondary/30 transition-colors cursor-pointer group" onClick={() => setChatTicket(ticket)}>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${sc.class}`}>
                        {sc.icon} {sc.label}
                      </span>
                      <span className="text-[10px] text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString()}</span>
                      {msgCount > 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-secondary text-muted-foreground">
                          <MessageCircle size={10} /> {msgCount}
                        </span>
                      )}
                      {unreadCount > 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-destructive text-destructive-foreground animate-pulse">
                          🔔 {unreadCount} nova{unreadCount > 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                    <h4 className="font-bold text-foreground truncate group-hover:text-primary transition-colors">{ticket.subject}</h4>
                    <p className="text-sm text-muted-foreground truncate">{getClientName(ticket.clientId)}</p>
                    {ticket.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{ticket.description}</p>}
                    {ticket.status === 'scheduled' && ticket.scheduledDate && (
                      <p className="text-xs text-primary mt-1 font-medium">
                        📅 {new Date(ticket.scheduledDate).toLocaleDateString('pt-BR')} às {ticket.scheduledTime}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2 flex-shrink-0" onClick={e => e.stopPropagation()}>
                    <button onClick={() => setChatTicket(ticket)} className="bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                      <MessageCircle size={14} /> Chat
                      {unreadCount > 0 && (
                        <span className="bg-destructive text-destructive-foreground text-[9px] font-bold px-1 py-0.5 rounded-full min-w-[16px] text-center">{unreadCount}</span>
                      )}
                    </button>
                    <button onClick={() => handleDelete(ticket.id)} className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">
                      <X size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          }) : (
            <div className="p-12 text-center text-muted-foreground">
              {activeTab === 'resolved' ? 'Nenhum ticket resolvido ainda.' : 'Nenhum ticket encontrado.'}
            </div>
          )}
        </div>
      </div>

      {/* New ticket modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-lg p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-foreground flex items-center gap-2">
                <LifeBuoy size={20} className="text-primary" /> Novo Ticket
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <div>
              <label className={labelClass}>Cliente</label>
              <select className={inputClass} value={form.clientId} onChange={e => setForm({ ...form, clientId: e.target.value })}>
                <option value="">Selecionar...</option>
                {clients.filter(c => c.status === 'active').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className={labelClass}>Assunto</label>
              <input className={inputClass} value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="Ex: Problema no AutoDJ" />
            </div>
            <div>
              <label className={labelClass}>Descrição</label>
              <textarea className={`${inputClass} h-20 resize-none`} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Detalhes do problema..." />
            </div>
            <button onClick={handleCreate} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-xl font-bold transition-colors" style={{ boxShadow: 'var(--glow-primary)' }}>
              Criar Ticket & Abrir Chat
            </button>
          </div>
        </div>
      )}

      {/* Chat modal */}
      {chatTicket && (
        <TicketChat
          ticket={chatTicket}
          client={clients.find(c => c.id === chatTicket.clientId)}
          companySettings={companySettings}
          onClose={() => setChatTicket(null)}
          onUpdateTicket={handleUpdateTicket}
        />
      )}
    </div>
  );
}
