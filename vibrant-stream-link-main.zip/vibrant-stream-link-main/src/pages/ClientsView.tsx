import { useState, useCallback } from 'react';
import { Search, Plus, Edit, Trash2, Save, X, Radio, Tv, Lock, Key, Eye, EyeOff, MapPin, Loader2, FileText, ExternalLink, CheckCircle, AlertCircle, CreditCard, MessageCircle, CheckSquare, AlertTriangle, Printer, Link2, Gift, Percent, Copy } from 'lucide-react';
import type { Client, Plan, CompanySettings, Transaction, Ticket } from '@/lib/types';
import { formatCurrency, getClientProfileHTML, getReceiptHTML } from '@/lib/format';
import { StatusBadge } from '@/components/StatusBadge';
import { CompactStreamPlayer } from '@/components/CompactStreamPlayer';
import { ImageUpload } from '@/components/ImageUpload';
import { validateDocument, formatDocument } from '@/lib/documentValidation';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface ClientsViewProps {
  clients: Client[];
  setClients: React.Dispatch<React.SetStateAction<Client[]>>;
  plans: Plan[];
  companySettings: CompanySettings;
  transactions?: Transaction[];
  tickets?: Ticket[];
  onOpenCentral?: (clientId: number) => void;
  sendWhatsApp?: (client: Client, reason?: string) => void;
  handleConfirmPayment?: (client: Client) => void;
  setTransactions?: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

export function ClientsView({ clients, setClients, plans, companySettings, transactions = [], tickets = [], onOpenCentral, sendWhatsApp, handleConfirmPayment, setTransactions }: ClientsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [form, setForm] = useState<Partial<Client>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [adminAuthModal, setAdminAuthModal] = useState<{ action: 'edit' | 'showPass'; client?: Client } | null>(null);
  const [adminPassInput, setAdminPassInput] = useState('');
  const [adminAuthError, setAdminAuthError] = useState('');
  const [cepLoading, setCepLoading] = useState(false);
  const [docValidation, setDocValidation] = useState<{ valid: boolean; type: string } | null>(null);
  const [modalTab, setModalTab] = useState<'dados' | 'faturas' | 'historico' | 'afiliados'>('dados');
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editTxForm, setEditTxForm] = useState<Partial<Transaction>>({});
  const [affiliateDiscount, setAffiliateDiscount] = useState(10);

  const handleCepSearch = useCallback(async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;
    setCepLoading(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await res.json();
      if (!data.erro) {
        setForm(prev => ({ ...prev, address: data.logradouro || '', neighborhood: data.bairro || '', city: data.localidade || '', state: data.uf || '' }));
      }
    } catch { /* silently fail */ }
    finally { setCepLoading(false); }
  }, []);

  const handleDocumentChange = (val: string) => {
    const formatted = formatDocument(val);
    setForm(prev => ({ ...prev, document: formatted }));
    const cleaned = val.replace(/\D/g, '');
    if (cleaned.length === 11 || cleaned.length === 14) {
      setDocValidation(validateDocument(cleaned));
    } else {
      setDocValidation(null);
    }
  };

  const filtered = clients.filter((c) =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.document?.includes(searchTerm)
  );

  const openNew = () => {
    setEditingClient(null);
    setShowPassword(false);
    setDocValidation(null);
    setModalTab('dados');
    setForm({
      name: '', ownerName: '', document: '', cep: '', address: '', neighborhood: '', city: '', state: '',
      website: '', logoUrl: '', audioUrl: '', videoUrl: '',
      port: '', password: '', status: 'active', paymentStatus: 'pending', recurrence: 'monthly',
      planId: plans[0]?.id || '', amount: plans[0]?.price || 0,
      startDate: new Date().toISOString().split('T')[0], dueDate: '', phone: '', birthday: '',
      serviceType: 'radio', schedules: [], history: [],
    });
    setIsModalOpen(true);
  };

  const handlePrintProfile = (client: Client) => {
    const w = window.open('', '', 'width=900,height=800');
    if (w) { w.document.write(getClientProfileHTML(client, transactions, tickets, companySettings, plans)); w.document.close(); }
  };

  const requestEdit = (client: Client) => {
    setAdminPassInput(''); setAdminAuthError('');
    setAdminAuthModal({ action: 'edit', client });
  };

  const handleAdminAuth = () => {
    if (adminPassInput !== companySettings.adminPassword) { setAdminAuthError('Senha incorreta.'); return; }
    if (adminAuthModal?.action === 'edit' && adminAuthModal.client) {
      setEditingClient(adminAuthModal.client); setShowPassword(false);
      setForm({ ...adminAuthModal.client }); setIsModalOpen(true); setModalTab('dados');
      const doc = adminAuthModal.client.document;
      if (doc) { const cleaned = doc.replace(/\D/g, ''); if (cleaned.length === 11 || cleaned.length === 14) setDocValidation(validateDocument(cleaned)); }
    } else if (adminAuthModal?.action === 'showPass') { setShowPassword(true); }
    setAdminAuthModal(null); setAdminPassInput('');
  };

  const requestShowPassword = () => {
    setAdminPassInput(''); setAdminAuthError('');
    setAdminAuthModal({ action: 'showPass' });
  };

  const handleSave = () => {
    if (!form.name) return;
    if (editingClient) {
      setClients(prev => prev.map(c => c.id === editingClient.id ? { ...c, ...form } as Client : c));
    } else {
      const newClient: Client = {
        ...(form as Client), id: Date.now(), createdAt: new Date().toISOString(),
        history: [{ date: new Date().toISOString(), action: 'Cadastro realizado', user: 'Sistema' }], schedules: [],
      };
      setClients(prev => [...prev, newClient]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Remover este cliente permanentemente?')) setClients(prev => prev.filter(c => c.id !== id));
  };

  const handlePlanChange = (planId: string) => {
    const plan = plans.find(p => p.id === planId);
    setForm(prev => ({ ...prev, planId, amount: plan?.price || 0 }));
  };

  const handlePrintReceipt = (tx: Transaction) => {
    const client = clients.find(c => c.name === tx.clientName);
    const w = window.open('', '', 'width=900,height=800');
    if (w) { w.document.write(getReceiptHTML(tx.clientName, client?.phone || '', tx.amount, tx.date, companySettings, tx.id)); w.document.close(); }
  };

  // Get invoices for the editing client
  const editingClientTxs = editingClient
    ? transactions.filter(t => t.clientName === editingClient.name || t.clientId === editingClient.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];
  const today = new Date().toISOString().split('T')[0];
  const isClientOverdue = editingClient ? editingClient.paymentStatus !== 'paid' && editingClient.dueDate < today : false;

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Clientes</h1>
          <p className="text-sm text-muted-foreground">Gerencie sua base de clientes de streaming.</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input type="text" placeholder="Buscar cliente..." className={`${inputClass} pl-10`} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <button onClick={openNew} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap">
            <Plus size={16} /> Novo Cliente
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
              <tr>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Tipo</th>
                <th className="px-6 py-4">Cidade</th>
                <th className="px-6 py-4">Stream</th>
                <th className="px-6 py-4">Plano</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(client => {
                const plan = plans.find(p => p.id === client.planId);
                return (
                  <tr key={client.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-background border border-border flex items-center justify-center overflow-hidden flex-shrink-0">
                          {client.logoUrl ? <img src={client.logoUrl} className="w-full h-full object-cover" alt="" /> :
                            client.serviceType === 'tv' ? <Tv size={16} className="text-muted-foreground" /> : <Radio size={16} className="text-muted-foreground" />}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{client.name}</p>
                          <p className="text-[11px] text-muted-foreground">{client.ownerName}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4"><span className="text-xs font-medium text-muted-foreground uppercase">{client.serviceType === 'tv' ? 'Web TV' : 'Rádio'}</span></td>
                    <td className="px-6 py-4 text-muted-foreground">{client.city}</td>
                    <td className="px-6 py-4"><CompactStreamPlayer url={client.audioUrl} type={client.serviceType} /></td>
                    <td className="px-6 py-4 text-muted-foreground text-xs">{plan?.name || '—'}</td>
                    <td className="px-6 py-4 font-mono font-bold text-foreground">{formatCurrency(client.amount)}</td>
                    <td className="px-6 py-4"><StatusBadge status={client.paymentStatus} isActive={client.status === 'active'} dueDate={client.dueDate} /></td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1">
                        {onOpenCentral && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button onClick={() => onOpenCentral(client.id)} className="bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 p-2 rounded-lg transition-colors">
                                <ExternalLink size={14} />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>Abrir Central do Cliente com faturas, suporte e dados completos</TooltipContent>
                          </Tooltip>
                        )}
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => handlePrintProfile(client)} className="bg-info/10 hover:bg-info/20 text-info border border-info/20 p-2 rounded-lg transition-colors">
                              <FileText size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Gerar ficha cadastral completa em PDF</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => requestEdit(client)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border p-2 rounded-lg transition-colors">
                              <Edit size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Editar dados do cliente (requer senha admin)</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => handleDelete(client.id)} className="bg-destructive/10 hover:bg-destructive/20 text-destructive border border-destructive/20 p-2 rounded-lg transition-colors">
                              <Trash2 size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Excluir cliente permanentemente</TooltipContent>
                        </Tooltip>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhum cliente encontrado.</div>}
        </div>
      </div>

      {/* Admin Auth Modal */}
      {adminAuthModal && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-[80] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-foreground flex items-center gap-2"><Lock size={18} className="text-warning" /> Autorização Admin</h3>
              <button onClick={() => setAdminAuthModal(null)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Digite a senha do administrador.</p>
            {adminAuthError && <p className="text-sm text-destructive mb-3 font-medium">{adminAuthError}</p>}
            <input type="password" className={`${inputClass} mb-4`} placeholder="Senha admin..." value={adminPassInput} onChange={e => setAdminPassInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAdminAuth()} autoFocus />
            <div className="flex gap-3">
              <button onClick={() => setAdminAuthModal(null)} className="flex-1 bg-secondary hover:bg-muted text-secondary-foreground border border-border px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Cancelar</button>
              <button onClick={handleAdminAuth} className="flex-1 bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Confirmar</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit/Create Modal - Now with tabs */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-[70] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-3xl p-6 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-foreground">{editingClient ? 'Editar Cliente' : 'Novo Cliente'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>

            {/* Tabs inside modal */}
            {editingClient && (
              <div className="flex gap-1 bg-secondary/50 rounded-xl p-1 mb-6">
                <button onClick={() => setModalTab('dados')} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${modalTab === 'dados' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                  <Edit size={14} /> Dados
                </button>
                <button onClick={() => setModalTab('faturas')} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${modalTab === 'faturas' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                  <CreditCard size={14} /> Faturas ({editingClientTxs.length})
                </button>
                <button onClick={() => setModalTab('afiliados')} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${modalTab === 'afiliados' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                  <Gift size={14} /> Afiliados
                </button>
                <button onClick={() => setModalTab('historico')} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${modalTab === 'historico' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                  <FileText size={14} /> Histórico
                </button>
              </div>
            )}

            {/* Tab: Dados */}
            {(modalTab === 'dados' || !editingClient) && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className={labelClass}>Nome da Rádio/TV</label>
                    <input className={inputClass} value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} />
                  </div>
                  <div>
                    <label className={labelClass}>Responsável</label>
                    <input className={inputClass} value={form.ownerName || ''} onChange={e => setForm({ ...form, ownerName: e.target.value })} />
                  </div>
                  <div>
                    <label className={labelClass}>CPF/CNPJ</label>
                    <div className="relative">
                      <input className={inputClass} value={form.document || ''} onChange={e => handleDocumentChange(e.target.value)} placeholder="000.000.000-00" />
                      {docValidation && (
                        <span className={`absolute right-3 top-1/2 -translate-y-1/2 ${docValidation.valid ? 'text-success' : 'text-destructive'}`}>
                          {docValidation.valid ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
                        </span>
                      )}
                    </div>
                    {docValidation && (
                      <p className={`text-[10px] mt-1 font-medium ${docValidation.valid ? 'text-success' : 'text-destructive'}`}>
                        {docValidation.valid ? `${docValidation.type.toUpperCase()} válido ✓` : `${docValidation.type === 'unknown' ? 'Documento' : docValidation.type.toUpperCase()} inválido`}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className={labelClass}><span className="flex items-center gap-1.5"><MapPin size={12} /> CEP {cepLoading && <Loader2 size={12} className="animate-spin text-primary" />}</span></label>
                    <input className={inputClass} value={form.cep || ''} onChange={e => { const val = e.target.value; setForm({ ...form, cep: val }); if (val.replace(/\D/g, '').length === 8) handleCepSearch(val); }} placeholder="00000-000" />
                  </div>
                  <div className="md:col-span-2">
                    <label className={labelClass}>Endereço</label>
                    <input className={inputClass} value={form.address || ''} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Preenchido automaticamente pelo CEP" />
                  </div>
                  <div>
                    <label className={labelClass}>Cidade</label>
                    <input className={inputClass} value={form.city || ''} onChange={e => setForm({ ...form, city: e.target.value })} />
                  </div>
                  <div>
                    <label className={labelClass}>Estado (UF)</label>
                    <input className={inputClass} value={form.state || ''} onChange={e => setForm({ ...form, state: e.target.value })} placeholder="SP" maxLength={2} />
                  </div>
                  <div>
                    <label className={labelClass}>WhatsApp</label>
                    <input className={inputClass} value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="5511999999999" />
                  </div>
                  <div>
                    <label className={labelClass}>Website</label>
                    <input className={inputClass} value={form.website || ''} onChange={e => setForm({ ...form, website: e.target.value })} placeholder="www.exemplo.com" />
                  </div>
                  <div>
                    <label className={labelClass}>Data de Aniversário</label>
                    <input type="date" className={inputClass} value={form.birthday || ''} onChange={e => setForm({ ...form, birthday: e.target.value })} />
                  </div>
                  <div>
                    <label className={labelClass}>Tipo</label>
                    <select className={inputClass} value={form.serviceType || 'radio'} onChange={e => setForm({ ...form, serviceType: e.target.value as 'radio' | 'tv' })}>
                      <option value="radio">Rádio</option>
                      <option value="tv">Web TV</option>
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <ImageUpload value={form.logoUrl || ''} onChange={url => setForm({ ...form, logoUrl: url })} label="Logo da Rádio/TV" />
                  </div>

                  {/* Credenciais do Portal do Cliente */}
                  <div className="md:col-span-2 bg-primary/5 border border-primary/20 rounded-xl p-4 space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-1.5"><Lock size={12} /> Credenciais da Central do Cliente</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className={labelClass}>Usuário (WhatsApp)</label>
                        <input className={inputClass} value={form.phone || ''} readOnly disabled placeholder="WhatsApp do cliente" />
                        <p className="text-[10px] text-muted-foreground mt-1">O login é o WhatsApp do cliente</p>
                      </div>
                      <div>
                        <label className={labelClass}>Senha do Portal</label>
                        <div className="relative">
                          <input type={showPassword ? 'text' : 'password'} className={inputClass} value={form.password || ''} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="••••••" />
                          <button type="button" onClick={() => { if (showPassword) setShowPassword(false); else requestShowPassword(); }} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1">
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className={labelClass}><span className="flex items-center gap-1.5"><Key size={12} /> Porta</span></label>
                    <input className={inputClass} value={form.port || ''} onChange={e => setForm({ ...form, port: e.target.value })} placeholder="8000" />
                  </div>
                  <div>
                    <label className={labelClass}><span className="flex items-center gap-1.5"><Lock size={12} /> Senha do Stream</span></label>
                    <div className="relative">
                      <input type="text" className={inputClass} value={form.audioUrl ? '' : ''} readOnly disabled placeholder="Gerenciada via servidor" />
                    </div>
                  </div>

                  <div>
                    <label className={labelClass}>Plano</label>
                    <select className={inputClass} value={form.planId || ''} onChange={e => handlePlanChange(e.target.value)}>
                      {plans.filter(p => p.active).map(p => <option key={p.id} value={p.id}>{p.name} - {formatCurrency(p.price)}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Valor (R$)</label>
                    <input type="number" className={inputClass} value={form.amount || ''} onChange={e => setForm({ ...form, amount: parseFloat(e.target.value) })} />
                  </div>
                  <div>
                    <label className={labelClass}>Data Início do Plano</label>
                    <input type="date" className={inputClass} value={form.startDate || ''} onChange={e => setForm({ ...form, startDate: e.target.value })} />
                  </div>
                  <div>
                    <label className={labelClass}>Recorrência</label>
                    <select className={inputClass} value={form.recurrence || 'monthly'} onChange={e => {
                      const rec = e.target.value as 'monthly' | 'quarterly' | 'yearly';
                      const days = rec === 'monthly' ? 30 : rec === 'quarterly' ? 90 : 365;
                      const start = form.startDate || new Date().toISOString().split('T')[0];
                      const due = new Date(new Date(start).getTime() + days * 86400000).toISOString().split('T')[0];
                      setForm({ ...form, recurrence: rec, dueDate: due });
                    }}>
                      <option value="monthly">Mensal (30 dias)</option>
                      <option value="quarterly">Trimestral (90 dias)</option>
                      <option value="yearly">Anual (365 dias)</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Vencimento</label>
                    <input type="date" className={inputClass} value={form.dueDate || ''} onChange={e => setForm({ ...form, dueDate: e.target.value })} />
                  </div>

                  <div className="md:col-span-2">
                    <label className={labelClass}>URL do Stream</label>
                    <input className={inputClass} value={form.audioUrl || ''} onChange={e => setForm({ ...form, audioUrl: e.target.value })} placeholder="https://stream.exemplo.com/live" />
                    {form.audioUrl && <div className="mt-2"><CompactStreamPlayer url={form.audioUrl} type={form.serviceType || 'radio'} /></div>}
                  </div>

                  <div>
                    <label className={labelClass}>Status Pagamento</label>
                    <select className={inputClass} value={form.paymentStatus || 'pending'} onChange={e => setForm({ ...form, paymentStatus: e.target.value as Client['paymentStatus'] })}>
                      <option value="paid">Pago</option>
                      <option value="pending">Pendente</option>
                      <option value="overdue">Vencido</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-border">
                  <button onClick={() => setIsModalOpen(false)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Cancelar</button>
                  <button onClick={handleSave} className="bg-primary hover:bg-primary/80 text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-bold transition-colors flex items-center gap-2">
                    <Save size={16} /> Salvar
                  </button>
                </div>
              </>
            )}

            {/* Tab: Faturas */}
            {modalTab === 'faturas' && editingClient && (
              <div className="space-y-4">
                {/* Current invoice summary */}
                <div className={`bg-background border rounded-xl p-4 ${isClientOverdue ? 'border-destructive/30' : 'border-border'}`}>
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-bold text-foreground text-sm">Fatura Atual</h4>
                    <StatusBadge status={editingClient.paymentStatus} dueDate={editingClient.dueDate} />
                  </div>
                  <div className="grid grid-cols-3 gap-3 mb-3">
                    <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Valor</p><p className="text-lg font-bold text-foreground">{formatCurrency(editingClient.amount)}</p></div>
                    <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Vencimento</p><p className={`text-lg font-bold ${isClientOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(editingClient.dueDate).toLocaleDateString()}</p></div>
                    <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Plano</p><p className="text-lg font-bold text-foreground">{plans.find(p => p.id === editingClient.planId)?.name || '—'}</p></div>
                  </div>
                  {editingClient.affiliateCredits && editingClient.affiliateCredits > 0 ? (
                    <div className="bg-success/10 border border-success/20 rounded-lg p-2 mb-3 flex items-center gap-2">
                      <Gift size={14} className="text-success" />
                      <span className="text-xs font-bold text-success">Crédito de afiliado: {editingClient.affiliateCredits}% de desconto aplicado</span>
                    </div>
                  ) : null}
                  <div className="flex gap-2">
                    {sendWhatsApp && (
                      <Tooltip><TooltipTrigger asChild>
                        <button onClick={() => sendWhatsApp(editingClient, isClientOverdue ? 'overdue' : 'pending')}
                          className="bg-warning/10 hover:bg-warning/20 text-warning border border-warning/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                          <MessageCircle size={14} /> {isClientOverdue ? 'Cobrar' : 'Notificar'}
                        </button>
                      </TooltipTrigger><TooltipContent>Enviar cobrança ou lembrete via WhatsApp</TooltipContent></Tooltip>
                    )}
                    {handleConfirmPayment && (
                      <Tooltip><TooltipTrigger asChild>
                        <button onClick={() => handleConfirmPayment(editingClient)}
                          className="bg-success hover:bg-success/80 text-success-foreground px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5" style={{ boxShadow: 'var(--glow-success)' }}>
                          <CheckSquare size={14} /> Dar Baixa
                        </button>
                      </TooltipTrigger><TooltipContent>Confirmar pagamento e gerar recibo</TooltipContent></Tooltip>
                    )}
                  </div>
                </div>

                {/* Edit Invoice Modal */}
                {editingTx && (
                  <div className="bg-background border border-primary/30 rounded-xl p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-foreground text-sm flex items-center gap-2"><Edit size={14} className="text-primary" /> Editar Fatura #{editingTx.id}</h4>
                      <button onClick={() => setEditingTx(null)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className={labelClass}>Data de Pagamento</label>
                        <input type="date" className={inputClass} value={editTxForm.paymentDate || ''} onChange={e => setEditTxForm({ ...editTxForm, paymentDate: e.target.value })} />
                      </div>
                      <div>
                        <label className={labelClass}>Data de Vencimento</label>
                        <input type="date" className={inputClass} value={editTxForm.dueDate || ''} onChange={e => setEditTxForm({ ...editTxForm, dueDate: e.target.value })} />
                      </div>
                      <div>
                        <label className={labelClass}>Valor (R$)</label>
                        <input type="number" className={inputClass} value={editTxForm.amount || ''} onChange={e => setEditTxForm({ ...editTxForm, amount: parseFloat(e.target.value) })} />
                      </div>
                      <div>
                        <label className={labelClass}>Status</label>
                        <select className={inputClass} value={editTxForm.status || 'pending'} onChange={e => setEditTxForm({ ...editTxForm, status: e.target.value as Transaction['status'] })}>
                          <option value="paid">Paga</option>
                          <option value="pending">Pendente</option>
                          <option value="cancelled">Cancelada</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <label className={labelClass}>Descrição</label>
                        <input className={inputClass} value={editTxForm.description || ''} onChange={e => setEditTxForm({ ...editTxForm, description: e.target.value })} />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEditingTx(null)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">Cancelar</button>
                      <button onClick={() => {
                        if (setTransactions) {
                          setTransactions(prev => prev.map(t => t.id === editingTx.id ? { ...t, ...editTxForm } as Transaction : t));
                          // If status changed to paid, check affiliate bonification
                          if (editTxForm.status === 'paid' && editingTx.status !== 'paid') {
                            const referrer = clients.find(c => c.affiliateCode && editingClient.referredBy === c.affiliateCode);
                            if (referrer) {
                              const discount = affiliateDiscount;
                              setClients(prev => prev.map(c => c.id === referrer.id ? { ...c, affiliateCredits: (c.affiliateCredits || 0) + discount } as Client : c));
                            }
                          }
                        }
                        setEditingTx(null);
                      }} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                        <Save size={12} /> Salvar
                      </button>
                    </div>
                  </div>
                )}

                {/* Invoice history */}
                <div className="bg-background border border-border rounded-xl overflow-hidden">
                  <div className="p-3 border-b border-border"><h4 className="font-bold text-foreground text-sm">Histórico de Faturas</h4></div>
                  <table className="w-full text-left text-sm">
                    <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
                      <tr>
                        <th className="px-4 py-2">Data</th>
                        <th className="px-4 py-2">Vencimento</th>
                        <th className="px-4 py-2">Descrição</th>
                        <th className="px-4 py-2">Valor</th>
                        <th className="px-4 py-2">Status</th>
                        <th className="px-4 py-2 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {editingClientTxs.map(tx => (
                        <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                          <td className="px-4 py-2 text-muted-foreground text-xs">{new Date(tx.paymentDate || tx.date).toLocaleDateString()}</td>
                          <td className="px-4 py-2 text-muted-foreground text-xs">{tx.dueDate ? new Date(tx.dueDate).toLocaleDateString() : '—'}</td>
                          <td className="px-4 py-2 text-foreground text-xs">{tx.description}</td>
                          <td className="px-4 py-2 font-mono font-bold text-xs">{formatCurrency(tx.amount)}</td>
                          <td className="px-4 py-2">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              tx.status === 'paid' ? 'bg-success/10 text-success border-success/20' :
                              tx.status === 'cancelled' ? 'bg-muted text-muted-foreground border-border' :
                              'bg-warning/10 text-warning border-warning/20'
                            }`}>
                              {tx.status === 'paid' ? 'Paga' : tx.status === 'cancelled' ? 'Cancelada' : 'Pendente'}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right">
                            <div className="flex justify-end gap-1">
                              <Tooltip><TooltipTrigger asChild>
                                <button onClick={() => { setEditingTx(tx); setEditTxForm({ ...tx }); }} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-2 py-1 rounded text-[10px] font-bold transition-colors inline-flex items-center gap-1">
                                  <Edit size={12} /> Editar
                                </button>
                              </TooltipTrigger><TooltipContent>Editar fatura</TooltipContent></Tooltip>
                              {tx.status === 'paid' && (
                                <Tooltip><TooltipTrigger asChild>
                                  <button onClick={() => handlePrintReceipt(tx)} className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-2 py-1 rounded text-[10px] font-bold transition-colors inline-flex items-center gap-1">
                                    <Printer size={12} /> Recibo
                                  </button>
                                </TooltipTrigger><TooltipContent>Gerar recibo para impressão</TooltipContent></Tooltip>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {editingClientTxs.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">Nenhuma fatura encontrada.</div>}
                </div>
              </div>
            )}

            {/* Tab: Afiliados */}
            {modalTab === 'afiliados' && editingClient && (
              <div className="space-y-4">
                {/* Affiliate Link */}
                <div className="bg-background border border-border rounded-xl p-4">
                  <h4 className="font-bold text-foreground text-sm mb-3 flex items-center gap-2"><Link2 size={14} className="text-primary" /> Link de Afiliado</h4>
                  <p className="text-xs text-muted-foreground mb-3">Gere um link exclusivo para este cliente indicar novos clientes. A cada indicação confirmada (fatura paga), o cliente recebe um desconto na próxima fatura.</p>
                  
                  {editingClient.affiliateCode ? (
                    <div className="space-y-3">
                      <div className="flex gap-2">
                        <input readOnly className={`${inputClass} font-mono text-xs`} value={`${window.location.origin}/central?ref=${editingClient.affiliateCode}`} />
                        <Tooltip><TooltipTrigger asChild>
                          <button onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/central?ref=${editingClient.affiliateCode}`); }} className="bg-primary hover:bg-primary/80 text-primary-foreground px-3 py-2 rounded-lg transition-colors flex-shrink-0">
                            <Copy size={14} />
                          </button>
                        </TooltipTrigger><TooltipContent>Copiar link</TooltipContent></Tooltip>
                      </div>
                      <div className="bg-success/10 border border-success/20 rounded-lg p-3">
                        <p className="text-xs font-bold text-success mb-1">Código: {editingClient.affiliateCode}</p>
                        <p className="text-xs text-success/80">Créditos acumulados: {editingClient.affiliateCredits || 0}%</p>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => {
                      const code = `AF${editingClient.id}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
                      setClients(prev => prev.map(c => c.id === editingClient.id ? { ...c, affiliateCode: code, affiliateCredits: 0 } as Client : c));
                      setEditingClient({ ...editingClient, affiliateCode: code, affiliateCredits: 0 });
                    }} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2.5 rounded-lg text-sm font-bold transition-colors flex items-center gap-2">
                      <Link2 size={14} /> Gerar Link de Afiliado
                    </button>
                  )}
                </div>

                {/* Discount config */}
                <div className="bg-background border border-border rounded-xl p-4">
                  <h4 className="font-bold text-foreground text-sm mb-3 flex items-center gap-2"><Percent size={14} className="text-warning" /> Bonificação por Indicação</h4>
                  <p className="text-xs text-muted-foreground mb-3">Defina o percentual de desconto que o cliente ganha a cada indicação com fatura confirmada.</p>
                  <div className="flex items-center gap-3">
                    <input type="number" min={1} max={100} className={`${inputClass} w-24`} value={affiliateDiscount} onChange={e => setAffiliateDiscount(parseInt(e.target.value) || 0)} />
                    <span className="text-sm font-bold text-foreground">% de desconto por indicação</span>
                  </div>
                </div>

                {/* Referred clients */}
                <div className="bg-background border border-border rounded-xl p-4">
                  <h4 className="font-bold text-foreground text-sm mb-3 flex items-center gap-2"><Gift size={14} className="text-info" /> Indicações Realizadas</h4>
                  {(() => {
                    const referrals = editingClient.affiliateCode ? clients.filter(c => c.referredBy === editingClient.affiliateCode) : [];
                    if (referrals.length === 0) return <p className="text-sm text-muted-foreground">Nenhuma indicação registrada ainda.</p>;
                    return (
                      <div className="space-y-2">
                        {referrals.map(ref => {
                          const refTxs = transactions.filter(t => (t.clientId === ref.id || t.clientName === ref.name) && t.status === 'paid');
                          return (
                            <div key={ref.id} className="flex items-center justify-between bg-secondary/30 rounded-lg p-3">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-lg bg-background border border-border flex items-center justify-center">
                                  {ref.serviceType === 'tv' ? <Tv size={14} className="text-muted-foreground" /> : <Radio size={14} className="text-muted-foreground" />}
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-foreground">{ref.name}</p>
                                  <p className="text-[10px] text-muted-foreground">{ref.city || 'Sem cidade'}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${refTxs.length > 0 ? 'bg-success/10 text-success border-success/20' : 'bg-warning/10 text-warning border-warning/20'}`}>
                                  {refTxs.length > 0 ? `${refTxs.length} fatura(s) paga(s)` : 'Aguardando pagamento'}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>

                {/* Referrer info */}
                {editingClient.referredBy && (
                  <div className="bg-info/10 border border-info/20 rounded-xl p-4">
                    <h4 className="font-bold text-info text-sm mb-1 flex items-center gap-2"><Link2 size={14} /> Indicado por</h4>
                    <p className="text-xs text-info/80">Código: {editingClient.referredBy}</p>
                    {(() => {
                      const referrer = clients.find(c => c.affiliateCode === editingClient.referredBy);
                      return referrer ? <p className="text-xs text-info/80">Cliente: {referrer.name}</p> : null;
                    })()}
                  </div>
                )}
              </div>
            )}

            {/* Tab: Histórico */}
            {modalTab === 'historico' && editingClient && (
              <div className="space-y-3">
                {(editingClient.history || []).length > 0 ? editingClient.history.map((entry, i) => (
                  <div key={i} className="bg-background border border-border rounded-lg p-3 flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-foreground">{entry.action}</p>
                      <p className="text-[10px] text-muted-foreground">{new Date(entry.date).toLocaleString()} • {entry.user}</p>
                    </div>
                  </div>
                )) : (
                  <div className="p-8 text-center text-muted-foreground">Nenhum registro no histórico.</div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
