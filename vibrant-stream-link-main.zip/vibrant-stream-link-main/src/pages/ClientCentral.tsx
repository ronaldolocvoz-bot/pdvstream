import { useState } from 'react';
import { ArrowLeft, Radio, Tv, Wifi, CreditCard, LifeBuoy, FileText, User, Clock, CheckCircle, AlertTriangle, MessageCircle, Plus, X, CalendarClock, AlertCircle, Copy } from 'lucide-react';
import type { Client, Plan, Transaction, Ticket, CompanySettings, ViewType } from '@/lib/types';
import { formatCurrency, getReceiptHTML } from '@/lib/format';
import { StatusBadge } from '@/components/StatusBadge';
import { CompactStreamPlayer } from '@/components/CompactStreamPlayer';

interface ClientCentralProps {
  client: Client;
  plans: Plan[];
  transactions: Transaction[];
  tickets: Ticket[];
  companySettings: CompanySettings;
  sendWhatsApp: (client: Client, reason?: string) => void;
  handleConfirmPayment: (client: Client) => void;
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  setTickets: React.Dispatch<React.SetStateAction<Ticket[]>>;
  onBack: () => void;
  clients: Client[];
}

export function ClientCentral({ client, plans, transactions, tickets, companySettings, sendWhatsApp, handleConfirmPayment, setTransactions, setTickets, onBack, clients }: ClientCentralProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'invoices' | 'support'>('overview');
  const [showNewInvoice, setShowNewInvoice] = useState(false);
  const [invoiceForm, setInvoiceForm] = useState({ amount: client.amount, description: 'Fatura Avulsa' });
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [ticketForm, setTicketForm] = useState({ subject: '', description: '' });

  const plan = plans.find(p => p.id === client.planId);
  const clientTxs = transactions.filter(t => t.clientName === client.name || t.clientId === client.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const clientTickets = tickets.filter(t => t.clientId === client.id).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const isOverdue = client.paymentStatus !== 'paid' && client.dueDate < new Date().toISOString().split('T')[0];

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => alert("Copiado!"));
  };

  const handleAddInvoice = () => {
    if (!invoiceForm.amount) return;
    const newTx: Transaction = {
      id: Date.now(),
      date: new Date().toISOString(),
      amount: invoiceForm.amount,
      type: 'income',
      status: 'pending',
      clientName: client.name,
      clientId: client.id,
      description: invoiceForm.description,
    };
    setTransactions(prev => [newTx, ...prev]);
    setShowNewInvoice(false);
    setInvoiceForm({ amount: client.amount, description: 'Fatura Avulsa' });
  };

  const handleAddTicket = () => {
    if (!ticketForm.subject) return;
    const newTicket: Ticket = {
      id: Date.now(),
      clientId: client.id,
      subject: ticketForm.subject,
      description: ticketForm.description,
      status: 'open',
      scheduledDate: '',
      scheduledTime: '',
      createdAt: new Date().toISOString(),
    };
    setTickets(prev => [newTicket, ...prev]);
    setShowNewTicket(false);
    setTicketForm({ subject: '', description: '' });
  };

  const handlePrintReceipt = (tx: Transaction) => {
    const w = window.open('', '', 'width=900,height=800');
    if (w) {
      w.document.write(getReceiptHTML(client.name, client.phone, tx.amount, tx.date, companySettings, tx.id));
      w.document.close();
    }
  };

  const statusConfig = {
    open: { icon: <AlertCircle size={12} />, label: 'Aberto', class: 'bg-warning/10 text-warning border-warning/20' },
    scheduled: { icon: <CalendarClock size={12} />, label: 'Agendado', class: 'bg-primary/10 text-primary border-primary/20' },
    resolved: { icon: <CheckCircle size={12} />, label: 'Resolvido', class: 'bg-success/10 text-success border-success/20' },
  };

  const tabs = [
    { id: 'overview' as const, label: 'Visão Geral', icon: <User size={16} /> },
    { id: 'invoices' as const, label: `Faturas (${clientTxs.length})`, icon: <FileText size={16} /> },
    { id: 'support' as const, label: `Suporte (${clientTickets.length})`, icon: <LifeBuoy size={16} /> },
  ];

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border p-2.5 rounded-xl transition-colors">
          <ArrowLeft size={18} />
        </button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center overflow-hidden flex-shrink-0">
            {client.logoUrl ? <img src={client.logoUrl} className="w-full h-full object-cover" alt="" /> :
              client.serviceType === 'tv' ? <Tv size={20} className="text-primary" /> : <Radio size={20} className="text-primary" />
            }
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{client.name}</h1>
            <p className="text-sm text-muted-foreground">{client.ownerName} • {client.phone} • Cliente desde {new Date(client.createdAt).toLocaleDateString()}</p>
          </div>
        </div>
        <StatusBadge status={client.paymentStatus} isActive={client.status === 'active'} dueDate={client.dueDate} />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary/50 rounded-xl p-1">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-bold transition-all ${activeTab === tab.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Plan Info */}
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-foreground flex items-center gap-2"><CreditCard size={18} className="text-primary" /> Plano Contratado</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Plano</p><p className="text-sm font-bold text-foreground">{plan?.name || client.planId}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Valor</p><p className="text-sm font-bold text-foreground">{formatCurrency(client.amount)}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Recorrência</p><p className="text-sm font-bold text-foreground">{client.recurrence === 'monthly' ? 'Mensal' : client.recurrence === 'quarterly' ? 'Trimestral' : 'Anual'}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Início do Plano</p><p className="text-sm font-bold text-foreground">{client.startDate ? new Date(client.startDate).toLocaleDateString() : '—'}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Vencimento</p><p className={`text-sm font-bold ${isOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(client.dueDate).toLocaleDateString()}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Aniversário</p><p className="text-sm font-bold text-foreground">{client.birthday ? new Date(client.birthday).toLocaleDateString() : '—'}</p></div>
            </div>
            {plan?.details && <p className="text-xs text-muted-foreground bg-background rounded-lg p-3">📋 {plan.details}</p>}
          </div>

          {/* Stream & Technical */}
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-foreground flex items-center gap-2"><Wifi size={18} className="text-success" /> Dados Técnicos</h3>
            <div className="flex items-center justify-between bg-background rounded-lg p-3">
              <span className="text-sm text-muted-foreground">Status da Transmissão</span>
              <CompactStreamPlayer url={client.audioUrl || client.videoUrl} type={client.serviceType} />
            </div>
            {client.audioUrl && (
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-bold mb-1">URL Áudio</p>
                <div className="flex gap-2">
                  <input readOnly className="flex-1 bg-background border border-border rounded-lg p-2 text-foreground text-xs font-mono" value={client.audioUrl} />
                  <button onClick={() => copyToClipboard(client.audioUrl)} className="p-2 bg-secondary border border-border rounded-lg hover:bg-muted transition-colors"><Copy size={14} /></button>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Porta</p><p className="text-sm font-mono text-foreground">{client.port || '—'}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">CPF/CNPJ</p><p className="text-sm font-mono text-foreground">{client.document || '—'}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Website</p><p className="text-sm text-foreground">{client.website || '—'}</p></div>
              <div className="bg-background rounded-lg p-3"><p className="text-[10px] text-muted-foreground uppercase font-bold">Cidade</p><p className="text-sm text-foreground">{client.city ? `${client.city}/${client.state}` : '—'}</p></div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="lg:col-span-2 bg-card border border-border rounded-2xl p-6">
            <h3 className="font-bold text-foreground mb-4">⚡ Ações Rápidas</h3>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => sendWhatsApp(client, isOverdue ? 'overdue' : 'pending')}
                className="bg-warning/10 hover:bg-warning/20 text-warning border border-warning/20 px-4 py-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-2">
                <MessageCircle size={14} /> {isOverdue ? 'Cobrar Atraso' : 'Enviar Lembrete'}
              </button>
              <button onClick={() => handleConfirmPayment(client)}
                className="bg-success hover:bg-success/80 text-success-foreground px-4 py-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-2" style={{ boxShadow: 'var(--glow-success)' }}>
                <CheckCircle size={14} /> Confirmar Pagamento
              </button>
              <button onClick={() => { setActiveTab('invoices'); setShowNewInvoice(true); }}
                className="bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 px-4 py-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-2">
                <Plus size={14} /> Nova Fatura Avulsa
              </button>
              <button onClick={() => { setActiveTab('support'); setShowNewTicket(true); }}
                className="bg-info/10 hover:bg-info/20 text-info border border-info/20 px-4 py-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-2">
                <LifeBuoy size={14} /> Abrir Ticket
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'invoices' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-foreground">Faturas do Cliente</h3>
            <button onClick={() => setShowNewInvoice(true)} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors">
              <Plus size={14} /> Fatura Avulsa
            </button>
          </div>

          {/* Current Invoice */}
          <div className={`bg-card border rounded-2xl p-6 ${isOverdue ? 'border-destructive/30' : 'border-border'}`}>
            <div className="flex justify-between items-center mb-3">
              <h4 className="font-bold text-foreground">Fatura Atual</h4>
              <StatusBadge status={client.paymentStatus} dueDate={client.dueDate} />
            </div>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Valor</p><p className="text-lg font-bold text-foreground">{formatCurrency(client.amount)}</p></div>
              <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Vencimento</p><p className={`text-lg font-bold ${isOverdue ? 'text-destructive' : 'text-foreground'}`}>{new Date(client.dueDate).toLocaleDateString()}</p></div>
              <div><p className="text-[10px] text-muted-foreground uppercase font-bold">Plano</p><p className="text-lg font-bold text-foreground">{plan?.name || '—'}</p></div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => sendWhatsApp(client, isOverdue ? 'overdue' : 'pending')}
                className="bg-warning/10 hover:bg-warning/20 text-warning border border-warning/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                <MessageCircle size={14} /> Notificar
              </button>
              <button onClick={() => handleConfirmPayment(client)}
                className="bg-success hover:bg-success/80 text-success-foreground px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                <CheckCircle size={14} /> Dar Baixa
              </button>
            </div>
          </div>

          {/* History */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-border"><h4 className="font-bold text-foreground text-sm">Histórico de Transações</h4></div>
            <table className="w-full text-left text-sm">
              <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
                <tr>
                  <th className="px-6 py-3">Data</th>
                  <th className="px-6 py-3">Descrição</th>
                  <th className="px-6 py-3">Valor</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {clientTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-3 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                    <td className="px-6 py-3 text-foreground">{tx.description}</td>
                    <td className="px-6 py-3 font-mono font-bold text-foreground">{formatCurrency(tx.amount)}</td>
                    <td className="px-6 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tx.status === 'paid' ? 'bg-success/10 text-success border-success/20' : 'bg-warning/10 text-warning border-warning/20'}`}>
                        {tx.status === 'paid' ? 'Pago' : 'Pendente'}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-right">
                      {tx.status === 'paid' && (
                        <button onClick={() => handlePrintReceipt(tx)} className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-2 py-1 rounded-lg text-[10px] font-bold transition-colors">
                          Recibo
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {clientTxs.length === 0 && <div className="p-8 text-center text-muted-foreground">Nenhuma transação encontrada.</div>}
          </div>

          {/* New Invoice Modal */}
          {showNewInvoice && (
            <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-foreground">Nova Fatura Avulsa</h3>
                  <button onClick={() => setShowNewInvoice(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>
                <div>
                  <label className={labelClass}>Valor (R$)</label>
                  <input type="number" step="0.01" className={inputClass} value={invoiceForm.amount} onChange={e => setInvoiceForm({ ...invoiceForm, amount: parseFloat(e.target.value) })} />
                </div>
                <div>
                  <label className={labelClass}>Descrição</label>
                  <input className={inputClass} value={invoiceForm.description} onChange={e => setInvoiceForm({ ...invoiceForm, description: e.target.value })} />
                </div>
                <button onClick={handleAddInvoice} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-xl font-bold transition-colors">
                  Gerar Fatura
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'support' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-foreground">Tickets de Suporte</h3>
            <button onClick={() => setShowNewTicket(true)} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors">
              <Plus size={14} /> Novo Ticket
            </button>
          </div>

          <div className="bg-card border border-border rounded-2xl overflow-hidden divide-y divide-border">
            {clientTickets.length > 0 ? clientTickets.map(ticket => {
              const sc = statusConfig[ticket.status];
              return (
                <div key={ticket.id} className="p-5 hover:bg-secondary/30 transition-colors">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${sc.class}`}>
                      {sc.icon} {sc.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h4 className="font-bold text-foreground">{ticket.subject}</h4>
                  {ticket.description && <p className="text-xs text-muted-foreground mt-1">{ticket.description}</p>}
                  {ticket.status === 'scheduled' && ticket.scheduledDate && (
                    <p className="text-xs text-primary mt-1 font-medium">📅 {new Date(ticket.scheduledDate).toLocaleDateString('pt-BR')} às {ticket.scheduledTime}</p>
                  )}
                </div>
              );
            }) : (
              <div className="p-12 text-center text-muted-foreground">Nenhum ticket registrado.</div>
            )}
          </div>

          {/* New Ticket Modal */}
          {showNewTicket && (
            <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-foreground">Novo Ticket</h3>
                  <button onClick={() => setShowNewTicket(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
                </div>
                <div>
                  <label className={labelClass}>Assunto</label>
                  <input className={inputClass} value={ticketForm.subject} onChange={e => setTicketForm({ ...ticketForm, subject: e.target.value })} placeholder="Ex: Problema no stream" />
                </div>
                <div>
                  <label className={labelClass}>Descrição</label>
                  <textarea className={`${inputClass} h-20 resize-none`} value={ticketForm.description} onChange={e => setTicketForm({ ...ticketForm, description: e.target.value })} />
                </div>
                <button onClick={handleAddTicket} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-xl font-bold transition-colors">
                  Criar Ticket
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
