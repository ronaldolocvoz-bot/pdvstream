import React from 'react';

interface DashboardStatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  variant: 'primary' | 'warning' | 'destructive' | 'success';
  subtext: string;
}

const variantStyles: Record<string, string> = {
  primary: 'bg-primary/10 text-primary border-primary/20',
  warning: 'bg-warning/10 text-warning border-warning/20',
  destructive: 'bg-destructive/10 text-destructive border-destructive/20',
  success: 'bg-success/10 text-success border-success/20',
};

export function DashboardStatCard({ title, value, icon, variant, subtext }: DashboardStatCardProps) {
  return (
    <div className="bg-card border border-border rounded-2xl p-6 hover:border-muted transition-colors">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-xl border ${variantStyles[variant]}`}>{icon}</div>
        <span className="text-[10px] font-bold bg-secondary border border-border text-muted-foreground px-2.5 py-1 rounded-full uppercase tracking-wider">
          {subtext}
        </span>
      </div>
      <div>
        <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
        <h3 className="text-3xl font-bold text-foreground tracking-tight">{value}</h3>
      </div>
    </div>
  );
}
