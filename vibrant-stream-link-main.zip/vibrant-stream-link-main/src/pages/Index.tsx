import { useState, useEffect, useRef, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import type { Client, Plan, Transaction, CompanySettings, ViewType, Ticket, Server, DownloadFolder, DownloadFile, PasswordRecoveryRequest } from '@/lib/types';
import { defaultClients, defaultPlans, defaultTransactions, defaultSettings, defaultTickets, defaultServers } from '@/lib/data';
import { generatePassword } from '@/lib/format';
import { validateBackupData, stripSensitiveDataForExport } from '@/lib/backupValidation';
import { useStickyState } from '@/hooks/use-sticky-state';
import { AppSidebar, type SettingsSection } from '@/components/layout/AppSidebar';
import { DashboardView } from './DashboardView';
import { ClientsView } from './ClientsView';
import { InvoicesView } from './InvoicesView';
import { PlansView } from './PlansView';
import { ServersView } from './ServersView';
import { SettingsView } from './SettingsView';
import { SupportView } from './SupportView';
import { LoginScreen } from './LoginScreen';
import { ClientPortal } from './ClientPortal';
import { ClientCentral } from './ClientCentral';
import { DownloadsView } from './DownloadsView';

const Index = () => {
  const [loginState, setLoginState] = useStickyState<{ type: 'none' | 'admin' | 'client'; clientId?: number }>({ type: 'none' }, 'sp_login_state');
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [settingsSection, setSettingsSection] = useState<SettingsSection>('appearance');
  const [clients, setClients] = useStickyState<Client[]>(defaultClients, 'sp_clients');
  const [plans, setPlans] = useStickyState<Plan[]>(defaultPlans, 'sp_plans');
  const [transactions, setTransactions] = useStickyState<Transaction[]>(defaultTransactions, 'sp_transactions');
  const [settings, setSettings] = useStickyState<CompanySettings>(defaultSettings, 'sp_settings');
  const [tickets, setTickets] = useStickyState<Ticket[]>(defaultTickets, 'sp_tickets');
  const [servers, setServers] = useStickyState<Server[]>(defaultServers, 'sp_servers');
  const [downloadFolders, setDownloadFolders] = useStickyState<DownloadFolder[]>([], 'sp_download_folders');
  const [downloadFiles, setDownloadFiles] = useStickyState<DownloadFile[]>([], 'sp_download_files');
  const [recoveryRequests, setRecoveryRequests] = useStickyState<PasswordRecoveryRequest[]>([], 'sp_recovery_requests');
  const [centralClientId, setCentralClientId] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Color scheme definitions
  const colorSchemes = useMemo<Record<string, { dark: { primary: string; accent: string; ring: string; sidebarPrimary: string; sidebarRing: string; glowPrimary: string }; light: { primary: string; accent: string; ring: string; sidebarPrimary: string; sidebarRing: string; glowPrimary: string } }>>(() => ({
    indigo: {
      dark: { primary: '239 84% 67%', accent: '239 84% 67%', ring: '239 84% 67%', sidebarPrimary: '239 84% 67%', sidebarRing: '239 84% 67%', glowPrimary: '0 0 20px hsl(239 84% 67% / 0.15)' },
      light: { primary: '239 84% 57%', accent: '239 84% 57%', ring: '239 84% 57%', sidebarPrimary: '239 84% 57%', sidebarRing: '239 84% 57%', glowPrimary: '0 0 20px hsl(239 84% 57% / 0.1)' },
    },
    blue: {
      dark: { primary: '217 91% 60%', accent: '217 91% 60%', ring: '217 91% 60%', sidebarPrimary: '217 91% 60%', sidebarRing: '217 91% 60%', glowPrimary: '0 0 20px hsl(217 91% 60% / 0.15)' },
      light: { primary: '217 91% 50%', accent: '217 91% 50%', ring: '217 91% 50%', sidebarPrimary: '217 91% 50%', sidebarRing: '217 91% 50%', glowPrimary: '0 0 20px hsl(217 91% 50% / 0.1)' },
    },
    emerald: {
      dark: { primary: '160 84% 39%', accent: '160 84% 39%', ring: '160 84% 39%', sidebarPrimary: '160 84% 39%', sidebarRing: '160 84% 39%', glowPrimary: '0 0 20px hsl(160 84% 39% / 0.15)' },
      light: { primary: '160 84% 32%', accent: '160 84% 32%', ring: '160 84% 32%', sidebarPrimary: '160 84% 32%', sidebarRing: '160 84% 32%', glowPrimary: '0 0 20px hsl(160 84% 32% / 0.1)' },
    },
    rose: {
      dark: { primary: '346 77% 60%', accent: '346 77% 60%', ring: '346 77% 60%', sidebarPrimary: '346 77% 60%', sidebarRing: '346 77% 60%', glowPrimary: '0 0 20px hsl(346 77% 60% / 0.15)' },
      light: { primary: '346 77% 50%', accent: '346 77% 50%', ring: '346 77% 50%', sidebarPrimary: '346 77% 50%', sidebarRing: '346 77% 50%', glowPrimary: '0 0 20px hsl(346 77% 50% / 0.1)' },
    },
    amber: {
      dark: { primary: '38 92% 50%', accent: '38 92% 50%', ring: '38 92% 50%', sidebarPrimary: '38 92% 50%', sidebarRing: '38 92% 50%', glowPrimary: '0 0 20px hsl(38 92% 50% / 0.15)' },
      light: { primary: '38 92% 45%', accent: '38 92% 45%', ring: '38 92% 45%', sidebarPrimary: '38 92% 45%', sidebarRing: '38 92% 45%', glowPrimary: '0 0 20px hsl(38 92% 45% / 0.1)' },
    },
    violet: {
      dark: { primary: '270 70% 60%', accent: '270 70% 60%', ring: '270 70% 60%', sidebarPrimary: '270 70% 60%', sidebarRing: '270 70% 60%', glowPrimary: '0 0 20px hsl(270 70% 60% / 0.15)' },
      light: { primary: '270 70% 50%', accent: '270 70% 50%', ring: '270 70% 50%', sidebarPrimary: '270 70% 50%', sidebarRing: '270 70% 50%', glowPrimary: '0 0 20px hsl(270 70% 50% / 0.1)' },
    },
    cyan: {
      dark: { primary: '187 85% 53%', accent: '187 85% 53%', ring: '187 85% 53%', sidebarPrimary: '187 85% 53%', sidebarRing: '187 85% 53%', glowPrimary: '0 0 20px hsl(187 85% 53% / 0.15)' },
      light: { primary: '187 85% 40%', accent: '187 85% 40%', ring: '187 85% 40%', sidebarPrimary: '187 85% 40%', sidebarRing: '187 85% 40%', glowPrimary: '0 0 20px hsl(187 85% 40% / 0.1)' },
    },
    red: {
      dark: { primary: '0 72% 51%', accent: '0 72% 51%', ring: '0 72% 51%', sidebarPrimary: '0 72% 51%', sidebarRing: '0 72% 51%', glowPrimary: '0 0 20px hsl(0 72% 51% / 0.15)' },
      light: { primary: '0 72% 45%', accent: '0 72% 45%', ring: '0 72% 45%', sidebarPrimary: '0 72% 45%', sidebarRing: '0 72% 45%', glowPrimary: '0 0 20px hsl(0 72% 45% / 0.1)' },
    },
  }), []);

  // Apply theme and color scheme
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'light') {
      root.classList.add('light-theme');
    } else {
      root.classList.remove('light-theme');
    }
    const fontSizeMap: Record<number, string> = { 1: '12px', 2: '14px', 3: '16px', 4: '18px', 5: '20px' };
    root.style.fontSize = fontSizeMap[settings.fontSize] || '16px';

    // Apply color scheme
    const scheme = colorSchemes[settings.colorScheme || 'indigo'];
    if (settings.colorScheme === 'custom' && settings.customColor) {
      // Convert hex to HSL
      const hex = settings.customColor;
      const r = parseInt(hex.slice(1, 3), 16) / 255;
      const g = parseInt(hex.slice(3, 5), 16) / 255;
      const b = parseInt(hex.slice(5, 7), 16) / 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      let h = 0, s = 0;
      const l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: h = ((g - b) / d + (g < b ? 6 : 0)) * 60; break;
          case g: h = ((b - r) / d + 2) * 60; break;
          case b: h = ((r - g) / d + 4) * 60; break;
        }
      }
      const hslVal = `${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
      root.style.setProperty('--primary', hslVal);
      root.style.setProperty('--accent', hslVal);
      root.style.setProperty('--ring', hslVal);
      root.style.setProperty('--sidebar-primary', hslVal);
      root.style.setProperty('--sidebar-ring', hslVal);
      root.style.setProperty('--glow-primary', `0 0 20px hsl(${hslVal} / 0.15)`);
    } else if (scheme) {
      const colors = settings.theme === 'light' ? scheme.light : scheme.dark;
      root.style.setProperty('--primary', colors.primary);
      root.style.setProperty('--accent', colors.accent);
      root.style.setProperty('--ring', colors.ring);
      root.style.setProperty('--sidebar-primary', colors.sidebarPrimary);
      root.style.setProperty('--sidebar-ring', colors.sidebarRing);
      root.style.setProperty('--glow-primary', colors.glowPrimary);
    }
  }, [settings.theme, settings.fontSize, settings.colorScheme, settings.customColor, colorSchemes]);

  // Note: Anti-inspect protection removed — it provides no real security.

  // Auto backup scheduler
  useEffect(() => {
    if (!settings.autoBackupEnabled || loginState.type !== 'admin') return;
    const now = new Date();
    const today = now.getDay();
    const todayStr = now.toISOString().split('T')[0];
    if (today === settings.autoBackupDay && settings.lastAutoBackupDate?.split('T')[0] !== todayStr) {
      // Trigger auto backup
      const rawData = { clients, plans, transactions, settings, tickets, servers, recoveryRequests, exportDate: now.toISOString() };
      const data = stripSensitiveDataForExport(rawData);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_auto_streampro_${todayStr}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setSettings(prev => ({ ...prev, lastAutoBackupDate: now.toISOString() }));
    }
  }, [settings.autoBackupEnabled, settings.autoBackupDay, loginState.type]);

  // Recovery request handlers
  const handleRecoveryRequest = (request: PasswordRecoveryRequest) => {
    setRecoveryRequests(prev => [...prev, request]);
  };

  const handleApproveRecovery = (requestId: number) => {
    setRecoveryRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'approved' as const } : r));
  };

  const handleRejectRecovery = (requestId: number) => {
    setRecoveryRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'rejected' as const } : r));
  };

  // Detect client route via React Router
  const location = useLocation();
  const isClientRoute = location.pathname === '/central' || location.pathname === '/portal';

  // If somehow a client login reached admin routes, redirect to none
  useEffect(() => {
    if (!isClientRoute && loginState.type === 'client') {
      setLoginState({ type: 'none' });
    }
  }, [loginState.type, isClientRoute]);

  // If on client route, always show client flow (never admin panel)
  if (isClientRoute) {
    if (loginState.type === 'client' && loginState.clientId) {
      const client = clients.find(c => c.id === loginState.clientId);
      if (!client) { setLoginState({ type: 'none' }); return null; }
      return (
        <ClientPortal
          client={client}
          transactions={transactions}
          tickets={tickets}
          companySettings={settings}
          plans={plans}
          onLogout={() => setLoginState({ type: 'none' })}
          setTickets={setTickets}
          setSettings={setSettings}
          downloadFolders={downloadFolders}
          downloadFiles={downloadFiles}
        />
      );
    }
    // Not logged in as client — show client login
    return (
      <LoginScreen
        onLoginAdmin={() => setLoginState({ type: 'admin' })}
        onLoginClient={(clientId) => setLoginState({ type: 'client', clientId })}
        onRegisterClient={(newClient) => setClients(prev => [...prev, newClient])}
        clients={clients}
        plans={plans}
        companySettings={settings}
        isClientRoute={true}
        recoveryRequests={recoveryRequests}
        onRecoveryRequest={handleRecoveryRequest}
      />
    );
  }

  // Not logged in (admin routes)
  if (loginState.type === 'none') {
    return (
      <LoginScreen
        onLoginAdmin={() => setLoginState({ type: 'admin' })}
        onLoginClient={(clientId) => setLoginState({ type: 'client', clientId })}
        onRegisterClient={(newClient) => setClients(prev => [...prev, newClient])}
        clients={clients}
        plans={plans}
        companySettings={settings}
        isClientRoute={false}
      />
    );
  }

  if (loginState.type === 'client') {
    return null;
  }

  // Admin panel
  const sendWhatsApp = (client: Client, reason?: string) => {
    const today = new Date().toISOString().split('T')[0];
    const isOverdue = client.dueDate < today;
    const template = reason === 'pending' || (!isOverdue && reason !== 'overdue')
      ? settings.templatePending : settings.templateOverdue;
    const message = template
      .replace(/{cliente}/g, client.name).replace(/{valor}/g, (client.amount || 0).toFixed(2))
      .replace(/{vencimento}/g, new Date(client.dueDate).toLocaleDateString())
      .replace(/{pix}/g, settings.pixKey).replace(/{empresa}/g, settings.name);
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleConfirmPayment = (client: Client) => {
    if (!window.confirm(`Confirmar pagamento de R$ ${(client.amount || 0).toFixed(2)} de ${client.name}?`)) return;
    const recurrence = client.recurrence || 'monthly';
    const days = recurrence === 'monthly' ? 30 : recurrence === 'quarterly' ? 90 : 365;
    const nextDue = new Date(new Date(client.dueDate).getTime() + days * 86400000).toISOString().split('T')[0];
    setClients(prev => prev.map(c => c.id === client.id ? {
      ...c, paymentStatus: 'paid' as const, dueDate: nextDue,
      history: [...(c.history || []), { date: new Date().toISOString(), action: `Pagamento confirmado - R$ ${(c.amount || 0).toFixed(2)}`, user: 'Admin' }],
    } : c));
    const newTransaction: Transaction = {
      id: Date.now(), date: new Date().toISOString(), amount: client.amount,
      type: 'income', status: 'paid', clientName: client.name, clientId: client.id, description: 'Mensalidade Streaming',
    };
    setTransactions(prev => [newTransaction, ...prev]);
    const message = settings.templateThanks
      .replace(/{cliente}/g, client.name).replace(/{valor}/g, (client.amount || 0).toFixed(2)).replace(/{empresa}/g, settings.name);
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  // Backup
  const handleBackup = () => {
    const rawData = { clients, plans, transactions, settings, tickets, servers, recoveryRequests, exportDate: new Date().toISOString() };
    const data = stripSensitiveDataForExport(rawData);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_streampro_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRestore = () => {
    fileInputRef.current?.click();
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const rawData = JSON.parse(ev.target?.result as string);
        const result = validateBackupData(rawData);
        if (!result.success) {
          alert(`Erro na validação do backup: ${'error' in result ? result.error : 'Formato inválido'}`);
          return;
        }
        if (!window.confirm('Restaurar backup? Isso substituirá todos os dados atuais.')) return;
        const data = result.data;
        if (data.clients) setClients(data.clients);
        if (data.plans) setPlans(data.plans);
        if (data.transactions) setTransactions(data.transactions);
        if (data.settings) setSettings(data.settings);
        if (data.tickets) setTickets(data.tickets);
        if (data.servers) setServers(data.servers);
        if (data.recoveryRequests) setRecoveryRequests(data.recoveryRequests);
        alert('Backup restaurado com sucesso!');
      } catch { alert('Arquivo de backup inválido.'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const openClientCentral = (clientId: number) => {
    setCentralClientId(clientId);
    setActiveView('client-central');
  };

  const renderView = () => {
    if (activeView === 'client-central' && centralClientId) {
      const client = clients.find(c => c.id === centralClientId);
      if (!client) return null;
      return (
        <ClientCentral
          client={client}
          plans={plans}
          transactions={transactions}
          tickets={tickets}
          companySettings={settings}
          sendWhatsApp={sendWhatsApp}
          handleConfirmPayment={handleConfirmPayment}
          setTransactions={setTransactions}
          setTickets={setTickets}
          onBack={() => setActiveView('clients')}
          clients={clients}
        />
      );
    }

    switch (activeView) {
      case 'dashboard':
        return <DashboardView clients={clients} transactions={transactions} tickets={tickets} sendWhatsApp={sendWhatsApp} handleConfirmPayment={handleConfirmPayment} companySettings={settings} onNavigate={setActiveView} recoveryRequests={recoveryRequests} onApproveRecovery={handleApproveRecovery} onRejectRecovery={handleRejectRecovery} />;
      case 'clients':
        return <ClientsView clients={clients} setClients={setClients} plans={plans} companySettings={settings} transactions={transactions} tickets={tickets} onOpenCentral={openClientCentral} sendWhatsApp={sendWhatsApp} handleConfirmPayment={handleConfirmPayment} setTransactions={setTransactions} />;
      case 'invoices':
        return <InvoicesView clients={clients} transactions={transactions} setTransactions={setTransactions} sendWhatsApp={sendWhatsApp} handleConfirmPayment={handleConfirmPayment} companySettings={settings} />;
      case 'plans':
        return <PlansView plans={plans} setPlans={setPlans} />;
      case 'servers':
        return <ServersView servers={servers} setServers={setServers} />;
      case 'downloads':
        return <DownloadsView folders={downloadFolders} setFolders={setDownloadFolders} files={downloadFiles} setFiles={setDownloadFiles} clients={clients} />;
      case 'support':
        return <SupportView tickets={tickets} setTickets={setTickets} clients={clients} companySettings={settings} recoveryRequests={recoveryRequests} onApproveRecovery={handleApproveRecovery} onRejectRecovery={handleRejectRecovery} />;
      case 'settings':
        return <SettingsView settings={settings} setSettings={setSettings} onLogout={() => setLoginState({ type: 'none' })} onBackup={handleBackup} onRestore={handleRestore} activeSection={settingsSection} />;
      default:
        return null;
    }
  };

  // Count unread client messages for admin sidebar badge
  const unreadSupportCount = tickets.reduce((count, ticket) => {
    const unread = (ticket.history || []).filter(m =>
      m.type === 'client' && (!ticket.lastAdminReadAt || new Date(m.date) > new Date(ticket.lastAdminReadAt))
    ).length;
    return count + unread;
  }, 0);

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar activeView={activeView} onNavigate={setActiveView} companyName={settings.name} logoUrl={settings.logoUrl} unreadSupportCount={unreadSupportCount} settingsSection={settingsSection} onSettingsSection={setSettingsSection} />
      <main className="ml-64 p-8 transition-all duration-300">
        {renderView()}
      </main>
      <input type="file" ref={fileInputRef} accept=".json" onChange={handleFileRestore} className="hidden" />
    </div>
  );
};

export default Index;
