import { CheckCircle, Clock, AlertCircle, Power } from 'lucide-react';

interface StatusBadgeProps {
  status: string;
  isActive?: boolean;
  dueDate?: string;
}

export function StatusBadge({ status, isActive = true, dueDate }: StatusBadgeProps) {
  if (!isActive) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-secondary text-muted-foreground border border-border">
        <Power size={12} /> Inativo
      </span>
    );
  }

  let currentStatus = status;
  if (status !== 'paid' && dueDate) {
    const today = new Date().toISOString().split('T')[0];
    currentStatus = dueDate < today ? 'overdue' : 'pending';
  }

  const config: Record<string, { classes: string; label: string; icon: React.ReactNode }> = {
    paid: {
      classes: 'bg-success/10 text-success border border-success/20',
      label: 'Pago',
      icon: <CheckCircle size={12} />,
    },
    pending: {
      classes: 'bg-warning/10 text-warning border border-warning/20',
      label: 'A Vencer',
      icon: <Clock size={12} />,
    },
    overdue: {
      classes: 'bg-destructive/10 text-destructive border border-destructive/20',
      label: 'Vencido',
      icon: <AlertCircle size={12} />,
    },
  };

  const s = config[currentStatus] || config.pending;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${s.classes}`}>
      {s.icon} {s.label}
    </span>
  );
}
