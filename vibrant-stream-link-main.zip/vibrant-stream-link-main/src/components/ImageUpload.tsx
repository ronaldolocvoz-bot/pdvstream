import { useState, useRef } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface ImageUploadProps {
  value: string;
  onChange: (url: string) => void;
  label?: string;
  className?: string;
}

export function ImageUpload({ value, onChange, label = 'Logo', className = '' }: ImageUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const compressImage = (file: File, maxWidth = 200, quality = 0.5): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new window.Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ratio = Math.min(maxWidth / img.width, maxWidth / img.height, 1);
          canvas.width = img.width * ratio;
          canvas.height = img.height * ratio;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            // Try webp first, fallback to jpeg
            let result = canvas.toDataURL('image/webp', quality);
            // If webp not supported or too large, try jpeg
            if (result.length > 50000) {
              result = canvas.toDataURL('image/jpeg', 0.4);
            }
            resolve(result);
          } else {
            resolve(e.target?.result as string);
          }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const compressed = await compressImage(file);
    onChange(compressed);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  return (
    <div className={className}>
      <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium flex items-center gap-1.5">
        <ImageIcon size={12} /> {label}
      </label>

      <div className="flex items-start gap-3">
        {/* Preview */}
        <div
          className={`relative w-20 h-20 rounded-xl border-2 border-dashed flex items-center justify-center overflow-hidden flex-shrink-0 transition-colors cursor-pointer ${
            dragOver ? 'border-primary bg-primary/10' : value ? 'border-border bg-background' : 'border-border hover:border-primary/50 bg-secondary/30'
          }`}
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
        >
          {value ? (
            <>
              <img src={value} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); onChange(''); }}
                className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center text-xs hover:scale-110 transition-transform"
              >
                <X size={10} />
              </button>
            </>
          ) : (
            <Upload size={20} className="text-muted-foreground" />
          )}
        </div>

        {/* URL input + upload button */}
        <div className="flex-1 space-y-2">
          <div className="flex gap-2">
            <input
              className="flex-1 bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm"
              value={value?.startsWith('data:') ? '' : value || ''}
              onChange={(e) => onChange(e.target.value)}
              placeholder="Cole a URL ou faça upload..."
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-medium whitespace-nowrap"
            >
              <Upload size={14} /> Upload
            </button>
          </div>
          {value && (
            <span className="text-[10px] text-muted-foreground">
              {value.startsWith('data:') ? '📎 Arquivo local carregado' : '🔗 URL externa'}
            </span>
          )}
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
          e.target.value = '';
        }}
      />
    </div>
  );
}
