import { DollarSign, Clock, AlertCircle, Users, Bell, Activity, WifiOff, CalendarClock, LifeBuoy } from 'lucide-react';
import type { Client, Transaction, Ticket, CompanySettings, ViewType, PasswordRecoveryRequest } from '@/lib/types';
import { formatCurrency } from '@/lib/format';
import { DashboardStatCard } from '@/components/DashboardStatCard';
import { FinancialOverviewChart } from '@/components/FinancialOverviewChart';
import { ActivityTimeline } from '@/components/ActivityTimeline';
import { StatusBadge } from '@/components/StatusBadge';
import { NotificationsPanel } from '@/components/NotificationsPanel';
import { AlertCard } from '@/components/AlertCard';
import { DashboardInsights } from '@/components/DashboardInsights';

interface DashboardViewProps {
  clients: Client[];
  transactions: Transaction[];
  tickets: Ticket[];
  sendWhatsApp: (client: Client, reason?: string) => void;
  handleConfirmPayment: (client: Client) => void;
  companySettings: CompanySettings;
  onNavigate: (view: ViewType) => void;
  recoveryRequests?: PasswordRecoveryRequest[];
  onApproveRecovery?: (requestId: number) => void;
  onRejectRecovery?: (requestId: number) => void;
}

export function DashboardView({ clients, transactions, tickets, sendWhatsApp, handleConfirmPayment, companySettings, onNavigate, recoveryRequests, onApproveRecovery, onRejectRecovery }: DashboardViewProps) {
  const activeClients = (clients || []).filter((c) => c.status !== 'inactive');
  const todayStr = new Date().toISOString().split('T')[0];
  const next7Days = new Date();
  next7Days.setDate(next7Days.getDate() + 7);
  const next7DaysStr = next7Days.toISOString().split('T')[0];

  const totalRevenue = activeClients.reduce((acc, c) => acc + (c.amount || 0), 0);
  const paidRevenue = activeClients.filter((c) => c.paymentStatus === 'paid').reduce((acc, c) => acc + (c.amount || 0), 0);
  const pendingRevenue = totalRevenue - paidRevenue;
  const overdueClients = activeClients.filter((c) => c.paymentStatus !== 'paid' && c.dueDate < todayStr);
  const dueSoonClients = activeClients.filter((c) => c.paymentStatus !== 'paid' && c.dueDate >= todayStr && c.dueDate <= next7DaysStr);
  const pendingSchedulesCount = activeClients.reduce((acc, client) => acc + (client.schedules?.filter(s => s.status === 'pending').length || 0), 0);
  const openTicketsCount = (tickets || []).filter(t => t.status !== 'resolved').length;

  return (
    <div className="space-y-8 animate-fade-in pb-32">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 text-primary mb-1">
            <Activity size={16} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Painel Administrativo</span>
          </div>
          <h1 className="text-3xl font-black text-foreground tracking-tight">
            Olá, {companySettings?.adminUser || 'Admin'}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Aqui está o resumo do seu sistema de streaming hoje.</p>
        </div>
        <NotificationsPanel clients={clients} recoveryRequests={recoveryRequests} onApproveRecovery={onApproveRecovery} onRejectRecovery={onRejectRecovery} />
      </div>

      {/* Alert Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <AlertCard icon={<WifiOff size={24} />} title="Sinais Offline" value={0} color="primary" desc="Tudo operacional" />
        <AlertCard icon={<Clock size={24} />} title="Vence em Breve" value={dueSoonClients.length} color={dueSoonClients.length > 0 ? 'warning' : 'primary'} desc="Próximos 7 dias" onClick={() => onNavigate('invoices')} />
        <AlertCard icon={<LifeBuoy size={24} />} title="Suporte Técnico" value={openTicketsCount} color={openTicketsCount > 0 ? 'destructive' : 'primary'} desc="Tickets aguardando" onClick={() => onNavigate('support')} />
        <AlertCard icon={<CalendarClock size={24} />} title="Automações" value={pendingSchedulesCount} color="primary" desc="Envios pendentes" />
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardStatCard title="Receita Prevista" value={formatCurrency(totalRevenue)} icon={<DollarSign size={24} />} variant="primary" subtext="Mensal" />
        <DashboardStatCard title="Em Aberto" value={formatCurrency(pendingRevenue)} icon={<Activity size={24} />} variant="warning" subtext="Pendente" />
        <DashboardStatCard title="Inadimplência" value={overdueClients.length} icon={<AlertCircle size={24} />} variant="destructive" subtext="Atrasos" />
        <DashboardStatCard title="Base Ativa" value={activeClients.length} icon={<Users size={24} />} variant="success" subtext="Total" />
      </div>

      {/* Charts + Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <FinancialOverviewChart transactions={transactions} clients={clients} />

          {/* Pending Table */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-border flex justify-between items-center">
              <h3 className="font-bold text-lg text-foreground flex items-center gap-2">
                <Bell size={20} className="text-warning" /> Pendências Recentes
              </h3>
              <span className="text-[10px] bg-secondary text-muted-foreground border border-border px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">Ação Rápida</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
                  <tr>
                    <th className="px-6 py-4">Cliente</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Valor</th>
                    <th className="px-6 py-4">Vencimento</th>
                    <th className="px-6 py-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {clients
                    .filter((c) => c.paymentStatus !== 'paid' && c.status !== 'inactive')
                    .slice(0, 5)
                    .map((client) => (
                      <tr key={client.id} className="hover:bg-secondary/30 transition-colors">
                        <td className="px-6 py-4 font-medium text-foreground">{client.name}</td>
                        <td className="px-6 py-4">
                          <StatusBadge status={client.paymentStatus} dueDate={client.dueDate} />
                        </td>
                        <td className="px-6 py-4 font-mono">{formatCurrency(client.amount)}</td>
                        <td className={`px-6 py-4 ${client.dueDate < todayStr ? 'text-destructive font-bold' : 'text-muted-foreground'}`}>
                          {new Date(client.dueDate).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button onClick={() => sendWhatsApp(client)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">
                              Cobrar
                            </button>
                            <button onClick={() => handleConfirmPayment(client)} className="bg-success hover:bg-success/80 text-success-foreground px-3 py-1.5 rounded-lg text-xs font-bold transition-colors" style={{ boxShadow: 'var(--glow-success)' }}>
                              Baixa
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
              {clients.filter((c) => c.paymentStatus !== 'paid' && c.status !== 'inactive').length === 0 && (
                <div className="p-8 text-center text-muted-foreground">Nenhuma pendência recente.</div>
              )}
            </div>
          </div>
        </div>

        <div className="w-full">
          <ActivityTimeline clients={clients} transactions={transactions} />
        </div>
      </div>

      {/* Insights */}
      <DashboardInsights clients={clients} transactions={transactions} />
    </div>
  );
}
