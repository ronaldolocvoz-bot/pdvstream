import { BarChart3 } from 'lucide-react';
import type { Client, Transaction } from '@/lib/types';
import { formatCurrency } from '@/lib/format';

interface FinancialOverviewChartProps {
  transactions: Transaction[];
  clients: Client[];
}

export function FinancialOverviewChart({ transactions, clients }: FinancialOverviewChartProps) {
  const getLast6Months = () => {
    const months: { name: string; key: string }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      months.push({
        name: d.toLocaleString('pt-PT', { month: 'short' }),
        key: `${d.getFullYear()}-${d.getMonth()}`,
      });
    }
    return months;
  };

  const chartData = getLast6Months().map(m => {
    const mTransactions = (transactions || []).filter(t => {
      const d = new Date(t.date);
      return `${d.getFullYear()}-${d.getMonth()}` === m.key;
    });
    const income = mTransactions
      .filter(t => (t.type === 'income' || t.type === 'payment') && t.status === 'paid')
      .reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const expense = mTransactions
      .filter(t => (t.type === 'expense' || t.type === 'withdrawal') && t.status === 'paid')
      .reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const newClientsCount = (clients || []).filter(c => {
      const d = new Date(c.createdAt || Date.now());
      return `${d.getFullYear()}-${d.getMonth()}` === m.key;
    }).length;
    return { ...m, income, expense, newClients: newClientsCount };
  });

  const maxVal = Math.max(...chartData.flatMap(d => [d.income, d.expense]), 100);

  return (
    <div className="bg-card border border-border rounded-2xl p-6 w-full">
      <div className="flex justify-between items-center mb-8">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <BarChart3 size={20} className="text-primary" /> Evolução Financeira & Clientes
        </h3>
        <div className="flex gap-4 text-[10px] font-bold uppercase tracking-wider">
          <span className="flex items-center gap-1.5 text-success"><div className="w-2.5 h-2.5 rounded-sm bg-success/80" /> Entradas</span>
          <span className="flex items-center gap-1.5 text-destructive"><div className="w-2.5 h-2.5 rounded-sm bg-destructive/80" /> Saídas</span>
        </div>
      </div>
      <div className="flex items-end justify-between h-56 gap-2 md:gap-4 px-2 relative">
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-5">
          {[0, 1, 2, 3].map(i => <div key={i} className="w-full h-px bg-foreground" />)}
        </div>
        {chartData.map((data, index) => (
          <div key={index} className="flex flex-col items-center flex-1 group z-10 h-full justify-end relative cursor-crosshair">
            <div className="absolute -top-12 text-[10px] font-bold text-foreground opacity-0 group-hover:opacity-100 transition-opacity bg-card border border-border p-2 rounded-lg z-20 whitespace-nowrap shadow-xl pointer-events-none">
              <div className="text-success">Receitas: {formatCurrency(data.income)}</div>
              <div className="text-destructive">Despesas: {formatCurrency(data.expense)}</div>
              <div className="text-primary mt-1 pt-1 border-t border-border">{data.newClients} novos clientes</div>
            </div>
            <div className="w-full flex justify-center gap-1 items-end h-[80%]">
              <div className="w-full max-w-[24px] bg-gradient-to-t from-success/20 to-success/80 rounded-t-sm transition-all duration-1000 hover:from-success hover:to-success/60" style={{ height: `${(data.income / maxVal) * 100}%` }} />
              <div className="w-full max-w-[24px] bg-gradient-to-t from-destructive/20 to-destructive/80 rounded-t-sm transition-all duration-1000 hover:from-destructive hover:to-destructive/60" style={{ height: `${(data.expense / maxVal) * 100}%` }} />
            </div>
            <span className="text-[10px] text-muted-foreground mt-3 font-medium uppercase tracking-wider flex flex-col items-center gap-1">
              {data.name}
              <span className="text-primary font-bold bg-primary/10 px-1.5 rounded-full text-[9px]">{data.newClients > 0 ? `+${data.newClients}` : '-'}</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
