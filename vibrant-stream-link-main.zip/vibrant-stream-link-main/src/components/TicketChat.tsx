import { useState, useRef, useEffect } from 'react';
import { Send, X, User, Shield, Settings, CalendarClock, CheckCircle, MessageCircle, Play, ThumbsUp } from 'lucide-react';
import type { Ticket, TicketMessage, Client, CompanySettings } from '@/lib/types';

interface TicketChatProps {
  ticket: Ticket;
  client: Client | undefined;
  companySettings: CompanySettings;
  onClose: () => void;
  onUpdateTicket: (updated: Ticket) => void;
}

export function TicketChat({ ticket, client, companySettings, onClose, onUpdateTicket }: TicketChatProps) {
  const [message, setMessage] = useState('');
  const [showSchedule, setShowSchedule] = useState(false);
  const [schedDate, setSchedDate] = useState(ticket.scheduledDate || '');
  const [schedTime, setSchedTime] = useState(ticket.scheduledTime || '09:00');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const history = ticket.history || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history.length]);

  // Mark as read by admin on open
  useEffect(() => {
    if (!ticket.lastAdminReadAt || new Date(ticket.lastAdminReadAt) < new Date()) {
      onUpdateTicket({ ...ticket, lastAdminReadAt: new Date().toISOString() });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const addMessage = (type: TicketMessage['type'], text: string) => {
    const msg: TicketMessage = { id: Date.now(), type, text, date: new Date().toISOString() };
    onUpdateTicket({ ...ticket, history: [...history, msg], lastAdminReadAt: new Date().toISOString() });
  };

  const handleSend = () => {
    if (!message.trim()) return;
    addMessage('admin', message.trim());
    setMessage('');
  };

  const sendWhatsAppNotification = (template: string, extraReplacements?: Record<string, string>) => {
    if (!client) return;
    let msg = template
      .replace(/{cliente}/g, client.name)
      .replace(/{assunto}/g, ticket.subject)
      .replace(/{empresa}/g, companySettings.name);
    if (extraReplacements) {
      Object.entries(extraReplacements).forEach(([key, val]) => {
        msg = msg.replace(new RegExp(`{${key}}`, 'g'), val);
      });
    }
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleAccept = () => {
    const now = new Date().toISOString();
    const msg: TicketMessage = { id: Date.now(), type: 'system', text: '👍 Suporte aceito pela equipe técnica.', date: now };
    onUpdateTicket({ ...ticket, status: 'accepted', history: [...history, msg], lastAdminReadAt: now });
    sendWhatsAppNotification(companySettings.templateSupportAccepted);
  };

  const handleSchedule = () => {
    if (!schedDate) return;
    const dateStr = new Date(schedDate + 'T00:00:00').toLocaleDateString('pt-BR');
    const now = new Date().toISOString();
    const msg: TicketMessage = { id: Date.now(), type: 'system', text: `⏰ Suporte agendado para ${dateStr} às ${schedTime}`, date: now };
    onUpdateTicket({
      ...ticket,
      scheduledDate: schedDate,
      scheduledTime: schedTime,
      status: 'scheduled',
      history: [...history, msg],
      lastAdminReadAt: now,
    });
    setShowSchedule(false);
    sendWhatsAppNotification(companySettings.templateSupportScheduled, { data: dateStr, hora: schedTime });
  };

  const handleStartProgress = () => {
    const now = new Date().toISOString();
    const msg: TicketMessage = { id: Date.now(), type: 'system', text: '🔧 Suporte em andamento — técnico atendendo.', date: now };
    onUpdateTicket({ ...ticket, status: 'in_progress', history: [...history, msg], lastAdminReadAt: now });
    sendWhatsAppNotification(companySettings.templateSupportInProgress);
  };

  const handleResolve = () => {
    const now = new Date().toISOString();
    const msg: TicketMessage = { id: Date.now(), type: 'system', text: '🎉 Ticket marcado como resolvido.', date: now };
    onUpdateTicket({ ...ticket, status: 'resolved', history: [...history, msg], lastAdminReadAt: now });
    sendWhatsAppNotification(companySettings.templateSupportResolved);
  };

  const handleWhatsApp = (text: string) => {
    if (!client) return;
    window.open(`https://wa.me/${client.phone}?text=${encodeURIComponent(text)}`, '_blank');
    addMessage('system', `📱 Mensagem enviada via WhatsApp: "${text.substring(0, 50)}..."`);
  };

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm";

  const statusColors: Record<string, string> = {
    open: 'bg-warning/10 text-warning border-warning/20',
    accepted: 'bg-info/10 text-info border-info/20',
    scheduled: 'bg-primary/10 text-primary border-primary/20',
    in_progress: 'bg-accent/10 text-accent-foreground border-accent/20',
    resolved: 'bg-success/10 text-success border-success/20',
  };
  const statusLabels: Record<string, string> = {
    open: 'Aberto',
    accepted: 'Aceito',
    scheduled: 'Agendado',
    in_progress: 'Em Andamento',
    resolved: 'Resolvido',
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-card border border-border rounded-2xl w-full max-w-2xl flex flex-col" style={{ height: '85vh' }}>
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
              <User size={18} className="text-primary" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-foreground truncate">{ticket.subject}</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{client?.name || 'Cliente removido'}</span>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColors[ticket.status]}`}>
                  {statusLabels[ticket.status]}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap">
            {ticket.status === 'open' && (
              <button onClick={handleAccept} className="p-2 rounded-lg bg-info/10 text-info hover:bg-info/20 transition-colors" title="Aceitar ticket">
                <ThumbsUp size={16} />
              </button>
            )}
            {(ticket.status === 'open' || ticket.status === 'accepted') && (
              <button onClick={() => setShowSchedule(!showSchedule)} className="p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors" title="Agendar suporte">
                <CalendarClock size={16} />
              </button>
            )}
            {(ticket.status === 'accepted' || ticket.status === 'scheduled') && (
              <button onClick={handleStartProgress} className="p-2 rounded-lg bg-warning/10 text-warning hover:bg-warning/20 transition-colors" title="Iniciar atendimento">
                <Play size={16} />
              </button>
            )}
            {ticket.status !== 'resolved' && (
              <button onClick={handleResolve} className="p-2 rounded-lg bg-success hover:bg-success/80 text-success-foreground transition-colors" title="Resolver ticket">
                <CheckCircle size={16} />
              </button>
            )}
            <button onClick={onClose} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Schedule bar */}
        {showSchedule && (
          <div className="p-3 border-b border-border bg-primary/5 flex items-end gap-3 flex-shrink-0">
            <div className="flex-1">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Data</label>
              <input type="date" className={inputClass} value={schedDate} onChange={e => setSchedDate(e.target.value)} />
            </div>
            <div className="w-28">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Hora</label>
              <input type="time" className={inputClass} value={schedTime} onChange={e => setSchedTime(e.target.value)} />
            </div>
            <button onClick={handleSchedule} className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap">
              Agendar & Notificar
            </button>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          <div className="flex justify-center">
            <div className="bg-secondary/50 border border-border rounded-xl px-4 py-2 text-center max-w-xs">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Ticket #{ticket.id}</p>
              <p className="text-xs text-foreground font-medium">{ticket.subject}</p>
              {ticket.description && <p className="text-xs text-muted-foreground mt-1">{ticket.description}</p>}
              <p className="text-[10px] text-muted-foreground mt-2">{new Date(ticket.createdAt).toLocaleString('pt-BR')}</p>
            </div>
          </div>

          {ticket.scheduledDate && (
            <div className="flex justify-center my-2">
              <div className="bg-primary/15 border-2 border-primary/40 rounded-2xl px-6 py-3 text-center shadow-lg shadow-primary/10 animate-fade-in">
                <CalendarClock size={20} className="text-primary mx-auto mb-1.5" />
                <p className="text-sm text-primary font-bold">📅 Suporte Agendado</p>
                <p className="text-base text-primary font-extrabold mt-1">
                  {new Date(ticket.scheduledDate + 'T00:00:00').toLocaleDateString('pt-BR')} às {ticket.scheduledTime}
                </p>
                <p className="text-[10px] text-primary/60 mt-1 uppercase tracking-wider">Cliente notificado via WhatsApp</p>
              </div>
            </div>
          )}

          {history.map(msg => (
            <div key={msg.id} className={`flex ${msg.type === 'admin' ? 'justify-end' : msg.type === 'client' ? 'justify-start' : 'justify-center'}`}>
              {msg.type === 'system' ? (
                (() => {
                  const isSchedule = msg.text.includes('⏰') || msg.text.includes('agendado') || msg.text.includes('Agendado');
                  return isSchedule ? (
                    <div className="bg-primary/15 border-2 border-primary/30 rounded-2xl px-5 py-3 max-w-sm shadow-md shadow-primary/10 animate-fade-in">
                      <div className="flex items-center gap-2 justify-center mb-1">
                        <CalendarClock size={14} className="text-primary" />
                        <p className="text-[10px] text-primary/70 uppercase tracking-wider font-semibold">{new Date(msg.date).toLocaleString('pt-BR')}</p>
                      </div>
                      <p className="text-sm text-primary font-bold text-center">{msg.text}</p>
                    </div>
                  ) : (
                    <div className="bg-secondary/50 border border-border rounded-xl px-3 py-1.5 max-w-sm">
                      <div className="flex items-center gap-1.5">
                        <Settings size={10} className="text-muted-foreground" />
                        <p className="text-[10px] text-muted-foreground">{new Date(msg.date).toLocaleString('pt-BR')}</p>
                      </div>
                      <p className="text-xs text-foreground mt-0.5">{msg.text}</p>
                    </div>
                  );
                })()
              ) : msg.type === 'admin' ? (
                <div className="max-w-[75%]">
                  <div className="bg-primary text-primary-foreground rounded-2xl rounded-br-md px-4 py-2.5">
                    <p className="text-sm">{msg.text}</p>
                  </div>
                  <div className="flex items-center justify-end gap-1 mt-1">
                    <Shield size={10} className="text-primary" />
                    <p className="text-[10px] text-muted-foreground">Admin · {new Date(msg.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              ) : (
                <div className="max-w-[75%]">
                  <div className="bg-secondary border border-border rounded-2xl rounded-bl-md px-4 py-2.5">
                    <p className="text-sm text-foreground">{msg.text}</p>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <User size={10} className="text-muted-foreground" />
                    <p className="text-[10px] text-muted-foreground">Cliente · {new Date(msg.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        {ticket.status !== 'resolved' ? (
          <div className="p-3 border-t border-border flex-shrink-0">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <input
                  className={inputClass}
                  placeholder="Digite uma mensagem..."
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
                />
              </div>
              <button
                onClick={() => message.trim() && handleWhatsApp(message.trim())}
                className="p-2.5 rounded-lg bg-success/20 text-success hover:bg-success/30 transition-colors"
                title="Enviar via WhatsApp"
              >
                <MessageCircle size={18} />
              </button>
              <button
                onClick={handleSend}
                className="p-2.5 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
                title="Enviar mensagem"
              >
                <Send size={18} />
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5 text-center">
              Enter para registrar · <MessageCircle size={8} className="inline" /> para enviar via WhatsApp
            </p>
          </div>
        ) : (
          <div className="p-3 border-t border-border text-center flex-shrink-0">
            <p className="text-xs text-success font-medium">✅ Ticket resolvido</p>
          </div>
        )}
      </div>
    </div>
  );
}
