import { useState, useCallback } from 'react';
import { Save, Building, Key, CreditCard, MessageCircle, LifeBuoy, LogOut, MapPin, Loader2, Globe, Sun, Moon, Type, Download, Upload, Palette, Minus, Plus, Clock, CalendarClock } from 'lucide-react';
import type { CompanySettings } from '@/lib/types';
import { ImageUpload } from '@/components/ImageUpload';
// v2 - removed forwardRef

interface SettingsViewProps {
  settings: CompanySettings;
  setSettings: React.Dispatch<React.SetStateAction<CompanySettings>>;
  onLogout: () => void;
  onBackup: () => void;
  onRestore: () => void;
  activeSection?: 'appearance' | 'company' | 'payment' | 'access' | 'backup' | 'templates';
}

export const SettingsView = ({ settings, setSettings, onLogout, onBackup, onRestore, activeSection = 'appearance' }: SettingsViewProps) => {
  const [cepLoading, setCepLoading] = useState(false);

  const update = (field: keyof CompanySettings, value: string) => {
    setSettings((prev) => ({ ...prev, [field]: value }));
  };

  const handleCepSearch = useCallback(async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;
    setCepLoading(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await res.json();
      if (!data.erro) {
        setSettings(prev => ({
          ...prev,
          address: `${data.logradouro || ''}, ${data.bairro || ''} - ${data.localidade || ''} / ${data.uf || ''}`,
        }));
      }
    } catch { /* silently fail */ }
    finally { setCepLoading(false); }
  }, [setSettings]);

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";


  return (
    <div className="pb-32 animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Configurações</h1>
          <p className="text-sm text-muted-foreground">Configure os dados da sua empresa e templates de mensagens.</p>
        </div>
        <button onClick={onLogout} className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors">
          <LogOut size={16} /> Sair
        </button>
      </div>

      <div className="max-w-3xl space-y-6">
          {/* Appearance */}
          {activeSection === 'appearance' && (
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-bold text-foreground flex items-center gap-2 mb-6">
                <Palette size={20} className="text-warning" /> Aparência
              </h3>
              <div className="space-y-6">
                <div>
                  <label className={labelClass}>Tema do Sistema</label>
                  <div className="flex gap-3">
                    <button onClick={() => setSettings(prev => ({ ...prev, theme: 'dark' }))}
                      className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold border transition-all ${settings.theme === 'dark' ? 'bg-primary/10 text-primary border-primary/30 shadow-sm' : 'bg-secondary text-muted-foreground border-border hover:text-foreground'}`}>
                      <Moon size={18} /> Modo Escuro
                    </button>
                    <button onClick={() => setSettings(prev => ({ ...prev, theme: 'light' }))}
                      className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold border transition-all ${settings.theme === 'light' ? 'bg-primary/10 text-primary border-primary/30 shadow-sm' : 'bg-secondary text-muted-foreground border-border hover:text-foreground'}`}>
                      <Sun size={18} /> Modo Claro
                    </button>
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Tamanho da Fonte</label>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => setSettings(prev => ({ ...prev, fontSize: Math.max(1, prev.fontSize - 1) }))}
                      disabled={settings.fontSize <= 1}
                      className="w-12 h-12 rounded-xl border border-border bg-secondary text-foreground flex items-center justify-center hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Minus size={20} />
                    </button>
                    <div className="flex-1 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {[1, 2, 3, 4, 5].map(level => (
                          <div
                            key={level}
                            className={`h-2 flex-1 rounded-full transition-colors ${level <= settings.fontSize ? 'bg-primary' : 'bg-border'}`}
                          />
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        {settings.fontSize === 1 ? 'Muito Pequena' : settings.fontSize === 2 ? 'Pequena' : settings.fontSize === 3 ? 'Média' : settings.fontSize === 4 ? 'Grande' : 'Muito Grande'}
                      </p>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ ...prev, fontSize: Math.min(5, prev.fontSize + 1) }))}
                      disabled={settings.fontSize >= 5}
                      className="w-12 h-12 rounded-xl border border-border bg-secondary text-foreground flex items-center justify-center hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Plus size={20} />
                    </button>
                  </div>
                </div>

                {/* Color Scheme */}
                <div>
                  <label className={labelClass}>Esquema de Cores</label>
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { id: 'indigo', label: 'Índigo', dark: '239 84% 67%', light: '239 84% 57%' },
                      { id: 'blue', label: 'Azul', dark: '217 91% 60%', light: '217 91% 50%' },
                      { id: 'cyan', label: 'Ciano', dark: '187 85% 53%', light: '187 85% 40%' },
                      { id: 'emerald', label: 'Esmeralda', dark: '160 84% 39%', light: '160 84% 32%' },
                      { id: 'amber', label: 'Âmbar', dark: '38 92% 50%', light: '38 92% 45%' },
                      { id: 'rose', label: 'Rosa', dark: '346 77% 60%', light: '346 77% 50%' },
                      { id: 'violet', label: 'Violeta', dark: '270 70% 60%', light: '270 70% 50%' },
                      { id: 'red', label: 'Vermelho', dark: '0 72% 51%', light: '0 72% 45%' },
                    ].map(color => {
                      const hsl = settings.theme === 'light' ? color.light : color.dark;
                      const isSelected = (settings.colorScheme || 'indigo') === color.id;
                      return (
                        <button
                          key={color.id}
                          onClick={() => setSettings(prev => ({ ...prev, colorScheme: color.id }))}
                          className={`flex flex-col items-center gap-2 py-3 rounded-xl text-xs font-bold border transition-all ${
                            isSelected
                              ? 'border-foreground/30 bg-secondary shadow-sm'
                              : 'border-border bg-secondary/50 hover:border-foreground/20'
                          }`}
                        >
                          <div
                            className={`w-8 h-8 rounded-full transition-all ${isSelected ? 'ring-2 ring-offset-2 ring-offset-card' : ''}`}
                            style={{
                              backgroundColor: `hsl(${hsl})`,
                              boxShadow: isSelected ? `0 0 12px hsl(${hsl} / 0.5)` : undefined,
                            }}
                          />
                          <span className={isSelected ? 'text-foreground' : 'text-muted-foreground'}>{color.label}</span>
                        </button>
                      );
                    })}
                    {/* Custom color picker */}
                    <button
                      onClick={() => setSettings(prev => ({ ...prev, colorScheme: 'custom' }))}
                      className={`flex flex-col items-center gap-2 py-3 rounded-xl text-xs font-bold border transition-all ${
                        (settings.colorScheme || 'indigo') === 'custom'
                          ? 'border-foreground/30 bg-secondary shadow-sm'
                          : 'border-border bg-secondary/50 hover:border-foreground/20'
                      }`}
                    >
                      <div className="relative w-8 h-8">
                        <div className="w-8 h-8 rounded-full" style={{
                          background: 'conic-gradient(hsl(0 80% 60%), hsl(60 80% 60%), hsl(120 80% 60%), hsl(180 80% 60%), hsl(240 80% 60%), hsl(300 80% 60%), hsl(360 80% 60%))',
                        }} />
                        {(settings.colorScheme || 'indigo') === 'custom' && settings.customColor && (
                          <div className="absolute inset-1 rounded-full border-2 border-card" style={{ backgroundColor: settings.customColor }} />
                        )}
                      </div>
                      <span className={(settings.colorScheme || 'indigo') === 'custom' ? 'text-foreground' : 'text-muted-foreground'}>Personalizado</span>
                    </button>
                  </div>
                  {(settings.colorScheme || 'indigo') === 'custom' && (
                    <div className="mt-4 flex items-center gap-4 p-4 bg-secondary/50 rounded-xl border border-border">
                      <label className="text-sm text-muted-foreground font-medium whitespace-nowrap">Escolha a cor:</label>
                      <input
                        type="color"
                        value={settings.customColor || '#6366f1'}
                        onChange={(e) => setSettings(prev => ({ ...prev, customColor: e.target.value }))}
                        className="w-12 h-12 rounded-lg cursor-pointer border-2 border-border bg-transparent p-0.5"
                      />
                      <div
                        className="flex-1 h-10 rounded-lg border border-border"
                        style={{ backgroundColor: settings.customColor || '#6366f1' }}
                      />
                      <span className="text-xs text-muted-foreground font-mono">{(settings.customColor || '#6366f1').toUpperCase()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Company Info */}
          {activeSection === 'company' && (
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-bold text-foreground flex items-center gap-2 mb-6">
                <Building size={20} className="text-primary" /> Dados da Empresa
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className={labelClass}>Nome da Empresa</label>
                  <input className={inputClass} value={settings.name} onChange={(e) => update('name', e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>CNPJ/CPF</label>
                  <input className={inputClass} value={settings.document} onChange={(e) => update('document', e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>WhatsApp Comercial</label>
                  <input className={inputClass} value={settings.phone} onChange={(e) => update('phone', e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}>WhatsApp Suporte</label>
                  <input className={inputClass} value={settings.supportPhone} onChange={(e) => update('supportPhone', e.target.value)} />
                </div>
                <div>
                  <label className={labelClass}><span className="flex items-center gap-1.5"><Globe size={12} /> Website</span></label>
                  <input className={inputClass} value={settings.website} onChange={(e) => update('website', e.target.value)} placeholder="www.suaempresa.com" />
                </div>
                <div>
                  <label className={labelClass}><span className="flex items-center gap-1.5"><MapPin size={12} /> CEP {cepLoading && <Loader2 size={12} className="animate-spin text-primary" />}</span></label>
                  <input className={inputClass} value={settings.cep} onChange={(e) => { const val = e.target.value; update('cep', val); if (val.replace(/\D/g, '').length === 8) handleCepSearch(val); }} placeholder="00000-000" />
                </div>
                <div className="md:col-span-2">
                  <label className={labelClass}>Endereço</label>
                  <input className={inputClass} value={settings.address} onChange={(e) => update('address', e.target.value)} />
                </div>
                <div className="md:col-span-2">
                  <ImageUpload value={settings.logoUrl} onChange={(url) => update('logoUrl', url)} label="Logo da Empresa" />
                </div>
              </div>
            </div>
          )}

          {/* Payment Info */}
          {activeSection === 'payment' && (
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-bold text-foreground flex items-center gap-2 mb-6">
                <CreditCard size={20} className="text-success" /> Pagamento
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className={labelClass}>Chave Pix</label><input className={inputClass} value={settings.pixKey} onChange={(e) => update('pixKey', e.target.value)} /></div>
                <div><label className={labelClass}>Dados Bancários</label><input className={inputClass} value={settings.bankInfo} onChange={(e) => update('bankInfo', e.target.value)} /></div>
                <div><label className={labelClass}>Formas de Pagamento</label><input className={inputClass} value={settings.paymentMethods} onChange={(e) => update('paymentMethods', e.target.value)} /></div>
                <div className="md:col-span-2">
                  <ImageUpload value={settings.pixQrCodeUrl} onChange={(url) => update('pixQrCodeUrl', url)} label="QR Code PIX (imagem manual)" />
                </div>
              </div>
            </div>
          )}

          {/* Access */}
          {activeSection === 'access' && (
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-bold text-foreground flex items-center gap-2 mb-6">
                <Key size={20} className="text-warning" /> Acesso Admin
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className={labelClass}>Usuário</label><input className={inputClass} value={settings.adminUser} onChange={(e) => update('adminUser', e.target.value)} /></div>
                <div><label className={labelClass}>Senha</label><input type="password" className={inputClass} value={settings.adminPassword} onChange={(e) => update('adminPassword', e.target.value)} /></div>
              </div>
            </div>
          )}

          {/* Backup & Restore */}
          {activeSection === 'backup' && (
            <>
              <div className="bg-card border border-border rounded-2xl p-6">
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-4">
                  <Save size={20} className="text-info" /> Backup & Restauração
                </h3>
                <p className="text-sm text-muted-foreground mb-6">Exporte todos os dados do sistema (clientes, faturas, tickets, configurações) ou restaure a partir de um arquivo de backup.</p>
                <div className="flex gap-3">
                  <button onClick={onBackup} className="bg-success/10 text-success border border-success/20 hover:bg-success/20 px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors">
                    <Download size={18} /> Fazer Backup
                  </button>
                  <button onClick={onRestore} className="bg-warning/10 text-warning border border-warning/20 hover:bg-warning/20 px-5 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors">
                    <Upload size={18} /> Restaurar Backup
                  </button>
                </div>
              </div>

              <div className="bg-card border border-border rounded-2xl p-6">
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-4">
                  <CalendarClock size={20} className="text-primary" /> Backup Automático
                </h3>
                <p className="text-sm text-muted-foreground mb-6">Agende o backup automático para ser realizado em um dia específico da semana. O download será feito automaticamente ao abrir o sistema no dia agendado.</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Clock size={18} className="text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Ativar backup agendado</p>
                        <p className="text-xs text-muted-foreground">O backup será baixado automaticamente</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setSettings(prev => ({ ...prev, autoBackupEnabled: !prev.autoBackupEnabled }))}
                      className={`relative w-12 h-6 rounded-full transition-colors ${settings.autoBackupEnabled ? 'bg-primary' : 'bg-border'}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${settings.autoBackupEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                  </div>

                  {settings.autoBackupEnabled && (
                    <div>
                      <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium">Dia da Semana</label>
                      <div className="grid grid-cols-7 gap-2">
                        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, i) => (
                          <button
                            key={i}
                            onClick={() => setSettings(prev => ({ ...prev, autoBackupDay: i }))}
                            className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                              settings.autoBackupDay === i
                                ? 'bg-primary/10 text-primary border-primary/30 shadow-sm'
                                : 'bg-secondary text-muted-foreground border-border hover:text-foreground hover:border-primary/20'
                            }`}
                          >
                            {day}
                          </button>
                        ))}
                      </div>
                      {settings.lastAutoBackupDate && (
                        <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1.5">
                          <Clock size={12} /> Último backup automático: {new Date(settings.lastAutoBackupDate).toLocaleDateString('pt-BR')} às {new Date(settings.lastAutoBackupDate).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* Templates */}
          {activeSection === 'templates' && (
            <>
              <div className="bg-card border border-border rounded-2xl p-6">
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-2">
                  <MessageCircle size={20} className="text-success" /> Templates WhatsApp
                </h3>
                <p className="text-xs text-muted-foreground mb-6">Use variáveis: {'{cliente}'}, {'{valor}'}, {'{vencimento}'}, {'{pix}'}, {'{empresa}'}</p>
                <div className="space-y-4">
                  <div><label className={labelClass}>Cobrança (Atraso)</label><textarea className={`${inputClass} h-32 resize-none`} value={settings.templateOverdue} onChange={(e) => update('templateOverdue', e.target.value)} /></div>
                  <div><label className={labelClass}>Lembrete (A Vencer)</label><textarea className={`${inputClass} h-32 resize-none`} value={settings.templatePending} onChange={(e) => update('templatePending', e.target.value)} /></div>
                  <div><label className={labelClass}>Agradecimento (Pago)</label><textarea className={`${inputClass} h-32 resize-none`} value={settings.templateThanks} onChange={(e) => update('templateThanks', e.target.value)} /></div>
                  <div><label className={labelClass}>Boas-Vindas (Novo Cliente)</label><textarea className={`${inputClass} h-32 resize-none`} value={settings.templateWelcome} onChange={(e) => update('templateWelcome', e.target.value)} /></div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-2xl p-6">
                <h3 className="font-bold text-foreground flex items-center gap-2 mb-2">
                  <LifeBuoy size={20} className="text-primary" /> Templates de Suporte
                </h3>
                <p className="text-xs text-muted-foreground mb-6">Use variáveis: {'{cliente}'}, {'{assunto}'}, {'{data}'}, {'{hora}'}, {'{empresa}'}</p>
                <div className="space-y-4">
                  <div><label className={labelClass}>Suporte Aceito</label><textarea className={`${inputClass} h-28 resize-none`} value={settings.templateSupportAccepted} onChange={(e) => update('templateSupportAccepted', e.target.value)} /></div>
                  <div><label className={labelClass}>Suporte Agendado</label><textarea className={`${inputClass} h-28 resize-none`} value={settings.templateSupportScheduled} onChange={(e) => update('templateSupportScheduled', e.target.value)} /></div>
                  <div><label className={labelClass}>Suporte em Andamento</label><textarea className={`${inputClass} h-28 resize-none`} value={settings.templateSupportInProgress} onChange={(e) => update('templateSupportInProgress', e.target.value)} /></div>
                  <div><label className={labelClass}>Suporte Resolvido</label><textarea className={`${inputClass} h-28 resize-none`} value={settings.templateSupportResolved} onChange={(e) => update('templateSupportResolved', e.target.value)} /></div>
                </div>
              </div>
            </>
          )}

          <div className="bg-success/10 border border-success/20 rounded-xl p-4 text-center">
            <p className="text-sm text-success font-medium">✅ As configurações são salvas automaticamente.</p>
          </div>
      </div>
    </div>
  );
};
