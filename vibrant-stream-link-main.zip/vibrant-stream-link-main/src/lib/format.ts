import type { CompanySettings, Client, Transaction, Ticket, Plan } from './types';
import { sanitizeString, sanitizeUrl } from './backupValidation';

export const formatCurrency = (val: number) =>
  new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

export const generatePassword = () => {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$";
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map(b => charset[b % charset.length])
    .join('');
};

// --- PIX BR CODE (BCB Official) ---
export const createPixPayload = (pixKey: string, merchantName: string, merchantCity: string, amount?: number) => {
  const formatLength = (val: string) => String(val.length).padStart(2, '0');
  const payloadFormat = "000201";

  const merchantAccountGui = "0014br.gov.bcb.pix";
  const merchantAccountKey = `01${formatLength(pixKey)}${pixKey}`;
  const merchantAccountInfo = merchantAccountGui + merchantAccountKey;
  const merchantAccountInfoField = `26${formatLength(merchantAccountInfo)}${merchantAccountInfo}`;

  const merchantCategoryCode = "52040000";
  const transactionCurrency = "5303986";

  let transactionAmountField = "";
  if (amount) {
    const amountStr = amount.toFixed(2);
    transactionAmountField = `54${formatLength(amountStr)}${amountStr}`;
  }

  const countryCode = "5802BR";

  const name = (merchantName || "EMPRESA").substring(0, 25).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z ]/ig, '').trim().toUpperCase() || "EMPRESA";
  const merchantNameField = `59${formatLength(name)}${name}`;

  const city = (merchantCity || "BRASIL").substring(0, 15).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z ]/ig, '').trim().toUpperCase() || "BRASIL";
  const merchantCityField = `60${formatLength(city)}${city}`;

  const additionalDataField = "62070503***";

  let payload = payloadFormat + merchantAccountInfoField + merchantCategoryCode + transactionCurrency + transactionAmountField + countryCode + merchantNameField + merchantCityField + additionalDataField + "6304";

  let crc = 0xFFFF;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) { crc = (crc << 1) ^ 0x1021; }
      else { crc = crc << 1; }
    }
  }

  const crcStr = (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
  return payload + crcStr;
};

// --- RECEIPT HTML ---
export const getReceiptHTML = (
  clientName: string,
  clientPhone: string,
  amount: number,
  date: string,
  settings: CompanySettings,
  transactionId?: number
) => {
  // Sanitize all user-controlled inputs to prevent XSS
  const safeClientName = sanitizeString(clientName || '');
  const safeClientPhone = sanitizeString(clientPhone || '');
  const safeSettingsName = sanitizeString(settings.name || '');
  const safeSettingsDocument = sanitizeString(settings.document || '');
  const safeSettingsPhone = sanitizeString(settings.phone || '');
  const safeSettingsAddress = sanitizeString(settings.address || '');
  const safeLogoUrl = sanitizeUrl(settings.logoUrl || '');

  const formattedAmount = formatCurrency(amount);
  const formattedDate = new Date(date).toLocaleDateString('pt-BR');
  const now = new Date().toLocaleString('pt-BR');
  const authHash = (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `AUTH-${Math.random().toString(36).substring(2, 15)}`).toUpperCase();
  const receiptNumber = (transactionId || Date.now()).toString().slice(-6);
  const whatsappMsg = encodeURIComponent(
    `Olá *${clientName}*! 🧾\n\nRecebemos o seu pagamento de *${formattedAmount}*.\n\n📄 Segue em anexo o seu recibo em PDF.\n\nAgradecemos a preferência!\nAtt, ${settings.name}`
  );
  const waLink = clientPhone
    ? `https://wa.me/${clientPhone}?text=${whatsappMsg}`
    : `https://wa.me/?text=${whatsappMsg}`;

  return `<!DOCTYPE html>
<html lang="pt"><head><meta charset="UTF-8"><title>Recibo #${receiptNumber} - ${safeClientName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
  :root { --primary: #4f46e5; --text-main: #1f2937; --text-muted: #6b7280; --border-color: #e5e7eb; --bg-light: #f9fafb; }
  body { font-family: 'Inter', sans-serif; background-color: #e2e8f0; margin: 0; padding: 20px; color: var(--text-main); -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .action-bar { max-width: 800px; margin: 0 auto 20px auto; display: flex; flex-wrap: wrap; justify-content: center; align-items: center; gap: 15px; background: #1e293b; padding: 15px 20px; border-radius: 12px; }
  .action-text { color: white; font-size: 14px; margin-right: auto; font-weight: 500; text-align: center; width: 100%; }
  @media(min-width: 600px) { .action-text { width: auto; text-align: left; } }
  .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 18px; border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; border: none; text-decoration: none; width: 100%; }
  @media(min-width: 600px) { .btn { width: auto; } }
  .btn-print { background-color: white; color: #1e293b; }
  .btn-wa { background-color: #22c55e; color: white; }
  .receipt-container { max-width: 800px; min-height: 1000px; margin: 0 auto; background: white; padding: 40px 20px; border-radius: 4px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); position: relative; overflow: hidden; box-sizing: border-box; }
  @media(min-width: 600px) { .receipt-container { padding: 60px; } }
  .receipt-container::before { content: ""; position: absolute; top: 0; left: 0; right: 0; height: 8px; background: linear-gradient(90deg, var(--primary), #818cf8); }
  .watermark { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 300px; height: 300px; opacity: 0.03; pointer-events: none; background-image: url('${safeLogoUrl}'); background-size: contain; background-repeat: no-repeat; background-position: center; z-index: 0; }
  .content-wrapper { position: relative; z-index: 1; }
  .header { display: flex; flex-direction: column; gap: 20px; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }
  @media(min-width: 600px) { .header { flex-direction: row; margin-bottom: 50px; } }
  .logo-container { max-width: 250px; }
  .logo { max-width: 100%; max-height: 80px; object-fit: contain; }
  .company-fallback { font-size: 24px; font-weight: 800; color: #111827; margin: 0; letter-spacing: -0.5px; }
  .receipt-meta { text-align: left; }
  @media(min-width: 600px) { .receipt-meta { text-align: right; } }
  .title { font-size: 32px; font-weight: 800; color: var(--primary); margin: 0 0 5px 0; }
  .receipt-number { font-size: 14px; color: var(--text-muted); font-weight: 600; }
  .info-grid { display: grid; grid-template-columns: 1fr; gap: 30px; margin-bottom: 40px; padding-bottom: 30px; border-bottom: 2px solid var(--border-color); }
  @media(min-width: 600px) { .info-grid { grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 50px; padding-bottom: 40px; } }
  .info-block h4 { font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin: 0 0 10px 0; }
  .info-value { font-size: 14px; color: var(--text-main); line-height: 1.6; }
  .info-value strong { color: #111827; font-size: 16px; display: block; margin-bottom: 4px; }
  .body-content { margin-bottom: 50px; }
  .declaration { font-size: 15px; color: #374151; line-height: 1.8; text-align: justify; }
  .amount-box { background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid var(--primary); border-radius: 8px; padding: 20px; display: flex; flex-direction: column; gap: 10px; justify-content: space-between; align-items: flex-start; margin: 30px 0; }
  @media(min-width: 600px) { .amount-box { flex-direction: row; align-items: center; padding: 25px; margin: 40px 0; } }
  .amount-label { font-size: 13px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; }
  .amount-value { font-size: 36px; font-weight: 800; color: #10b981; line-height: 1; }
  .amount-status { font-size: 12px; font-weight: 700; color: #10b981; background: #ecfdf5; border: 1px solid #a7f3d0; padding: 4px 12px; border-radius: 20px; }
  .signature-section { display: flex; justify-content: center; margin-top: 60px; }
  @media(min-width: 600px) { .signature-section { justify-content: flex-end; margin-top: 80px; } }
  .signature-box { text-align: center; width: 100%; max-width: 300px; }
  .signature-line { border-top: 1px solid var(--text-main); margin-bottom: 10px; }
  .signature-name { font-weight: 700; font-size: 14px; color: var(--text-main); }
  .signature-role { font-size: 12px; color: var(--text-muted); }
  .footer { margin-top: 60px; padding-top: 20px; border-top: 1px dashed var(--border-color); font-size: 10px; color: #9ca3af; display: flex; flex-direction: column; gap: 15px; justify-content: space-between; align-items: center; text-align: center; }
  @media(min-width: 600px) { .footer { flex-direction: row; align-items: flex-end; text-align: right; margin-top: 80px; padding-top: 25px; font-size: 11px; } .footer > div:first-child { text-align: left; } }
  .auth-box p { margin: 0 0 4px 0; }
  .auth-hash { font-family: monospace; font-size: 11px; color: var(--text-muted); font-weight: 600; }
  @media print { @page { size: A4; margin: 0; } body { background-color: white; padding: 0; } .action-bar { display: none !important; } .receipt-container { box-shadow: none; padding: 20mm; min-height: auto; } }
</style>
</head><body>
<div class="action-bar">
  <span class="action-text">Para enviar ao cliente, salve o PDF e depois clique em enviar via WhatsApp.</span>
  <button class="btn btn-print" onclick="window.print()">📄 1. Salvar PDF</button>
  <a class="btn btn-wa" href="${waLink}" target="_blank">💬 2. Enviar no WhatsApp</a>
</div>
<div class="receipt-container">
  <div class="watermark"></div>
  <div class="content-wrapper">
    <div class="header">
      <div class="logo-container">
        ${safeLogoUrl
    ? `<img src="${safeLogoUrl}" class="logo" alt="${safeSettingsName}" />`
    : `<h2 class="company-fallback">${safeSettingsName}</h2>`
  }
      </div>
      <div class="receipt-meta">
        <h1 class="title">RECIBO</h1>
        <p class="receipt-number">Nº ${receiptNumber}</p>
      </div>
    </div>
    <div class="info-grid">
      <div class="info-block">
        <h4>Dados do Emitente</h4>
        <div class="info-value">
          <strong>${safeSettingsName}</strong>
          ${safeSettingsDocument ? `CNPJ/CPF: ${safeSettingsDocument}<br>` : ''}
          ${safeSettingsPhone ? `Telefone/WhatsApp: ${safeSettingsPhone}<br>` : ''}
          ${safeSettingsAddress ? safeSettingsAddress : ''}
        </div>
      </div>
      <div class="info-block">
        <h4>Dados do Cliente (Sacado)</h4>
        <div class="info-value">
          <strong>${safeClientName}</strong>
          Telefone: ${safeClientPhone || 'Não informado'}<br>
          Data de Emissão: ${formattedDate}<br>
          Referência: Serviços de Streaming / Hospedagem
        </div>
      </div>
    </div>
    <div class="body-content">
      <p class="declaration">Recebemos de <strong>${safeClientName}</strong>, a importância de <strong>${formattedAmount}</strong>, referente ao pagamento de serviços de streaming de áudio/vídeo e hospedagem prestados pela <strong>${safeSettingsName}</strong>.</p>
      <div class="amount-box">
        <div>
          <div class="amount-label">Valor Recebido</div>
          <div class="amount-value">${formattedAmount}</div>
        </div>
        <span class="amount-status">✓ Pago</span>
      </div>
      <p class="declaration">Para maior clareza e validade, firmamos o presente recibo dando plena, rasa e irrevogável quitação referente ao valor acima mencionado.</p>
    </div>
    <div class="signature-section">
      <div class="signature-box">
        <div class="signature-line"></div>
        <p class="signature-name">${safeSettingsName}</p>
        <p class="signature-role">Departamento Financeiro</p>
      </div>
    </div>
    <div class="footer">
      <div class="auth-box">
        <p>Autenticação Eletrônica (Gerado em ${now})</p>
        <p class="auth-hash">${authHash}</p>
      </div>
      <div>
        <p>Documento gerado por ${safeSettingsName}.</p>
        <p>Este recibo tem validade legal.</p>
      </div>
    </div>
  </div>
</div>
</body></html>`;
};

// --- CLIENT PROFILE HTML ---
export const getClientProfileHTML = (
  client: Client,
  transactions: Transaction[],
  tickets: Ticket[],
  companySettings: CompanySettings,
  plans: Plan[]
) => {
  // Sanitize all user-controlled inputs to prevent XSS
  const safeClientName = sanitizeString(client.name || '');
  const safeOwnerName = sanitizeString(client.ownerName || '');
  const safePhone = sanitizeString(client.phone || '');
  const safeWebsite = sanitizeString(client.website || '');
  const safeAddress = sanitizeString(client.address || '');
  const safeNeighborhood = sanitizeString(client.neighborhood || '');
  const safeCity = sanitizeString(client.city || '');
  const safeState = sanitizeString(client.state || '');
  const safeCep = sanitizeString(client.cep || '');
  const safeServerId = sanitizeString(String(client.serverId || ''));
  const safeAudioUrl = sanitizeString(client.audioUrl || '');
  const safeVideoUrl = sanitizeString(client.videoUrl || '');
  const safePort = sanitizeString(String(client.port || ''));
  const safeCompanyName = sanitizeString(companySettings?.name || 'StreamPRO');
  const safeCompanyLogo = sanitizeUrl(companySettings?.logoUrl || '');
  
  const clientTxs = transactions.filter(t => t.clientName === client.name).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const clientTickets = tickets.filter(t => t.clientId === client.id).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const plan = plans.find(p => p.id === client.planId);
  const safePlanName = sanitizeString(plan?.name || client.planId || '');
  const now = new Date().toLocaleString('pt-BR');

  return `<!DOCTYPE html>
<html lang="pt"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ficha - ${safeClientName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
  body { font-family: 'Inter', sans-serif; background: #f1f5f9; color: #1e293b; margin: 0; padding: 20px; }
  .no-print { max-width: 900px; margin: 0 auto 20px; text-align: center; }
  .no-print button { background: #1e293b; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 14px; }
  .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
  .header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #e2e8f0; }
  .header h1 { font-size: 22px; margin: 0 0 4px 0; color: #4f46e5; }
  .header h2 { font-size: 16px; font-weight: 400; color: #64748b; margin: 0 0 4px 0; }
  .header p { font-size: 12px; color: #94a3b8; margin: 0; }
  .section-title { font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #4f46e5; margin: 30px 0 15px; padding: 8px 12px; background: #f8fafc; border-left: 4px solid #4f46e5; border-radius: 4px; }
  .fields { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .field { padding: 10px; background: #f8fafc; border-radius: 6px; font-size: 13px; }
  .field strong { display: block; font-size: 11px; text-transform: uppercase; color: #64748b; margin-bottom: 4px; letter-spacing: 0.5px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
  th { background: #f1f5f9; text-align: left; padding: 10px; font-size: 11px; text-transform: uppercase; color: #64748b; }
  td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
  .empty { text-align: center; padding: 20px; color: #94a3b8; font-style: italic; }
  @media print { @page { size: A4; margin: 0; } body { background: white; padding: 0; } .no-print { display: none !important; } .container { border: none; padding: 20mm; box-shadow: none; max-width: 100%; } .field { border: none; padding: 4px 0; background: transparent; } .section-title { background: transparent; border-bottom: 2px solid #e5e7eb; padding-left: 0; border-left: none; } }
</style>
</head><body>
<div class="no-print">
  <button onclick="window.print()">🖨️ Imprimir Ficha / Salvar PDF</button>
  <p style="font-size:12px;color:#64748b;margin-top:8px;">Para salvar, clique em imprimir e escolha "Salvar como PDF" no destino.</p>
</div>
<div class="container">
  <div class="header">
    ${safeCompanyLogo ? `<img src="${safeCompanyLogo}" style="max-height:60px;max-width:200px;object-fit:contain;margin:0 auto 10px;" alt="${safeCompanyName}" />` : ''}
    <h1>${safeCompanyName}</h1>
    <h2>Ficha Cadastral e Histórico de Cliente</h2>
    <p>Documento gerado em: ${now}</p>
  </div>
  <div class="section-title">Dados Principais e Contato</div>
  <div class="fields">
    <div class="field"><strong>Nome da Rádio / Empresa</strong>${safeClientName}</div>
    <div class="field"><strong>Responsável</strong>${safeOwnerName || 'Não informado'}</div>
    <div class="field"><strong>WhatsApp / Telefone</strong>${safePhone}</div>
    <div class="field"><strong>Site ou App</strong>${safeWebsite || 'N/A'}</div>
    <div class="field"><strong>Endereço</strong>${safeAddress || 'N/A'}, ${safeNeighborhood}</div>
    <div class="field"><strong>Cidade / UF</strong>${safeCity || 'N/A'} - ${safeState}</div>
    <div class="field"><strong>CEP</strong>${safeCep || 'N/A'}</div>
    <div class="field"><strong>Cliente desde</strong>${new Date(client.createdAt).toLocaleDateString()}</div>
  </div>
  <div class="section-title">Serviço Contratado e Financeiro</div>
  <div class="fields">
    <div class="field"><strong>Plano</strong>${safePlanName}</div>
    <div class="field"><strong>Valor</strong>R$ ${client.amount.toFixed(2).replace('.', ',')}</div>
    <div class="field"><strong>Ciclo</strong>${client.recurrence === 'monthly' ? 'Mensal' : client.recurrence === 'yearly' ? 'Anual' : sanitizeString(client.recurrence || '') || 'Mensal'}</div>
    <div class="field"><strong>Vencimento</strong>${new Date(client.dueDate).toLocaleDateString()}</div>
    <div class="field"><strong>Status</strong>${client.status === 'active' ? 'ATIVA' : 'SUSPENSA'}</div>
    <div class="field"><strong>Financeiro</strong>${client.paymentStatus === 'paid' ? 'Em Dia' : 'Pendente/Atrasado'}</div>
  </div>
  <div class="section-title">Configurações Técnicas</div>
  <div class="fields">
    <div class="field"><strong>Tipo de Streaming</strong>${client.serviceType === 'radio' ? 'Áudio' : 'Vídeo/TV'}</div>
    <div class="field"><strong>Servidor</strong>${safeServerId || 'Nenhum'}</div>
    <div class="field"><strong>URL de Transmissão</strong>${safeAudioUrl || safeVideoUrl || 'Não configurada'}</div>
    <div class="field"><strong>Porta</strong>${safePort || 'N/A'}</div>
  </div>
  <div class="section-title">Histórico de Transações</div>
  <table>
    <thead><tr><th>Data</th><th>Descrição</th><th>Tipo</th><th>Valor</th></tr></thead>
    <tbody>
      ${clientTxs.length ? clientTxs.slice(0, 10).map(t => `<tr>
        <td>${new Date(t.date).toLocaleDateString()}</td>
        <td>${sanitizeString(t.description || '')}</td>
        <td>${t.type === 'income' || t.type === 'payment' ? 'Receita' : 'Despesa'}</td>
        <td>R$ ${t.amount.toFixed(2).replace('.', ',')}</td>
      </tr>`).join('') : '<tr><td colspan="4" class="empty">Nenhuma transação registrada.</td></tr>'}
    </tbody>
  </table>
  <div class="section-title">Histórico de Suporte</div>
  <table>
    <thead><tr><th>Data</th><th>Assunto</th><th>Status</th></tr></thead>
    <tbody>
      ${clientTickets.length ? clientTickets.map(t => `<tr>
        <td>${new Date(t.createdAt).toLocaleDateString()}</td>
        <td>${sanitizeString(t.subject || '')}</td>
        <td>${t.status === 'open' ? 'Aberto' : t.status === 'resolved' ? 'Resolvido' : 'Agendado'}</td>
      </tr>`).join('') : '<tr><td colspan="3" class="empty">Nenhum chamado registrado.</td></tr>'}
    </tbody>
  </table>
</div>
</body></html>`;
};
