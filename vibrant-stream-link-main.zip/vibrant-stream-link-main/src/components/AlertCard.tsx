import { ArrowRight } from 'lucide-react';
import React from 'react';

interface AlertCardProps {
  icon: React.ReactNode;
  title: string;
  value: number | string;
  color: 'destructive' | 'warning' | 'primary' | 'success';
  desc: string;
  onClick?: () => void;
}

const colorMap: Record<string, string> = {
  destructive: 'bg-destructive/10 border-destructive/30 text-destructive hover:border-destructive/50',
  warning: 'bg-warning/10 border-warning/30 text-warning hover:border-warning/50',
  primary: 'bg-primary/10 border-primary/30 text-primary hover:border-primary/50',
  success: 'bg-success/10 border-success/30 text-success hover:border-success/50',
};

export function AlertCard({ icon, title, value, color, desc, onClick }: AlertCardProps) {
  const c = colorMap[color] || colorMap.primary;
  return (
    <div onClick={onClick} className={`p-5 rounded-2xl border transition-all duration-300 cursor-pointer group flex items-center gap-4 ${c}`}>
      <div className="p-3.5 rounded-xl bg-background border border-border text-current flex-shrink-0 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-black leading-none mb-1 text-foreground">{value}</div>
          <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
        <div className="text-[11px] font-bold uppercase tracking-wider opacity-90">{title}</div>
        <div className="text-[10px] opacity-60 mt-0.5">{desc}</div>
      </div>
    </div>
  );
}
