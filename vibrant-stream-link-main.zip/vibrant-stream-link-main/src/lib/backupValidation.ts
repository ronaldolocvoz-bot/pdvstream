import { z } from 'zod';
import type { Client, Plan, Transaction, CompanySettings, Ticket, Server, PasswordRecoveryRequest, DownloadFolder, DownloadFile } from './types';
const scheduleSchema = z.object({
  id: z.number(),
  type: z.enum(['once', 'recurring']),
  date: z.string(),
  time: z.string(),
  days: z.array(z.number()),
  status: z.enum(['pending', 'sent']),
  createdAt: z.string(),
});

const historyEntrySchema = z.object({
  date: z.string(),
  action: z.string(),
  user: z.string(),
});

const clientSchema = z.object({
  id: z.number(),
  name: z.string(),
  ownerName: z.string(),
  document: z.string(),
  cep: z.string(),
  address: z.string(),
  neighborhood: z.string(),
  city: z.string(),
  state: z.string(),
  website: z.string(),
  logoUrl: z.string(),
  audioUrl: z.string(),
  videoUrl: z.string(),
  port: z.string(),
  password: z.string(),
  status: z.enum(['active', 'inactive']),
  paymentStatus: z.enum(['paid', 'pending', 'overdue', 'cancelled']),
  recurrence: z.enum(['monthly', 'quarterly', 'yearly']),
  planId: z.string(),
  amount: z.number(),
  startDate: z.string(),
  dueDate: z.string(),
  phone: z.string(),
  birthday: z.string(),
  serviceType: z.enum(['radio', 'tv']),
  serverId: z.number().optional(),
  schedules: z.array(scheduleSchema),
  affiliateCode: z.string().optional(),
  referredBy: z.string().optional(),
  affiliateCredits: z.number().optional(),
  createdAt: z.string(),
  history: z.array(historyEntrySchema),
});

const planSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
  cost: z.number(),
  stock: z.number(),
  details: z.string(),
  category: z.string(),
  type: z.enum(['plan', 'service', 'category']),
  active: z.boolean(),
});

const transactionSchema = z.object({
  id: z.number(),
  date: z.string(),
  amount: z.number(),
  type: z.enum(['payment', 'income', 'expense', 'withdrawal']),
  status: z.enum(['paid', 'pending', 'cancelled']),
  clientName: z.string(),
  description: z.string(),
  clientId: z.number().optional(),
  dueDate: z.string().optional(),
  paymentDate: z.string().optional(),
});

const ticketMessageSchema = z.object({
  id: z.number(),
  type: z.enum(['system', 'admin', 'client']),
  text: z.string(),
  date: z.string(),
});

const ticketSchema = z.object({
  id: z.number(),
  clientId: z.number(),
  subject: z.string(),
  description: z.string(),
  status: z.enum(['open', 'accepted', 'scheduled', 'in_progress', 'resolved']),
  scheduledDate: z.string(),
  scheduledTime: z.string(),
  createdAt: z.string(),
  history: z.array(ticketMessageSchema).optional(),
  lastAdminReadAt: z.string().optional(),
  lastClientReadAt: z.string().optional(),
});

const serverSchema = z.object({
  id: z.number(),
  name: z.string(),
  ip: z.string(),
  port: z.string(),
  type: z.enum(['icecast', 'wowza', 'cpanel', 'other']),
  capacity: z.number(),
  usage: z.number(),
  status: z.enum(['online', 'offline', 'warning']),
  location: z.string(),
});

const companySettingsSchema = z.object({
  name: z.string(),
  website: z.string(),
  logoUrl: z.string(),
  cep: z.string(),
  address: z.string(),
  document: z.string(),
  phone: z.string(),
  supportPhone: z.string(),
  pixKey: z.string(),
  pixQrCodeUrl: z.string(),
  bankInfo: z.string(),
  paymentMethods: z.string(),
  adminUser: z.string(),
  adminPassword: z.string(),
  templateOverdue: z.string(),
  templatePending: z.string(),
  templateThanks: z.string(),
  templateWelcome: z.string(),
  templateSupportAccepted: z.string(),
  templateSupportScheduled: z.string(),
  templateSupportInProgress: z.string(),
  templateSupportResolved: z.string(),
  theme: z.enum(['dark', 'light']),
  fontSize: z.number(),
  colorScheme: z.string(),
  autoBackupEnabled: z.boolean(),
  autoBackupDay: z.number(),
  lastAutoBackupDate: z.string().optional(),
});

const downloadFolderSchema = z.object({
  id: z.string(),
  name: z.string(),
  createdAt: z.string(),
  clientIds: z.array(z.number()),
});

const downloadFileSchema = z.object({
  id: z.string(),
  folderId: z.string(),
  name: z.string(),
  size: z.number(),
  type: z.string(),
  data: z.string(),
  createdAt: z.string(),
});

const recoveryRequestSchema = z.object({
  id: z.number(),
  clientId: z.number(),
  clientPhone: z.string(),
  clientName: z.string(),
  requestedAt: z.string(),
  status: z.enum(['pending', 'approved', 'rejected']),
});

export const backupSchema = z.object({
  clients: z.array(clientSchema).optional(),
  plans: z.array(planSchema).optional(),
  transactions: z.array(transactionSchema).optional(),
  settings: companySettingsSchema.optional(),
  tickets: z.array(ticketSchema).optional(),
  servers: z.array(serverSchema).optional(),
  downloadFolders: z.array(downloadFolderSchema).optional(),
  downloadFiles: z.array(downloadFileSchema).optional(),
  recoveryRequests: z.array(recoveryRequestSchema).optional(),
  exportDate: z.string().optional(),
});

export type BackupData = z.infer<typeof backupSchema>;

// Sanitize string fields to prevent XSS
export function sanitizeString(str: string): string {
  return str
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// Sanitize URL for safe use in HTML src/href attributes (preserves slashes and colons)
export function sanitizeUrl(url: string): string {
  if (!url) return '';
  // Allow data URIs and http(s) URLs only
  if (url.startsWith('data:') || url.startsWith('http://') || url.startsWith('https://')) {
    return url
      .replace(/</g, '')
      .replace(/>/g, '')
      .replace(/"/g, '')
      .replace(/'/g, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+\s*=/gi, '');
  }
  return sanitizeString(url);
}

// Sanitize settings templates (allow some HTML but remove scripts)
export function sanitizeTemplate(template: string): string {
  return template
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .replace(/javascript:/gi, '');
}

// Validated backup data with correct types
export interface ValidatedBackupData {
  clients?: Client[];
  plans?: Plan[];
  transactions?: Transaction[];
  settings?: CompanySettings;
  tickets?: Ticket[];
  servers?: Server[];
  downloadFolders?: DownloadFolder[];
  downloadFiles?: DownloadFile[];
  recoveryRequests?: PasswordRecoveryRequest[];
  exportDate?: string;
}

// Validate and sanitize backup data
export function validateBackupData(data: unknown): { success: true; data: ValidatedBackupData } | { success: false; error: string } {
  try {
    const parsed = backupSchema.parse(data);
    
    // Sanitize template strings in settings
    if (parsed.settings) {
      parsed.settings.templateOverdue = sanitizeTemplate(parsed.settings.templateOverdue);
      parsed.settings.templatePending = sanitizeTemplate(parsed.settings.templatePending);
      parsed.settings.templateThanks = sanitizeTemplate(parsed.settings.templateThanks);
      parsed.settings.templateWelcome = sanitizeTemplate(parsed.settings.templateWelcome);
      parsed.settings.templateSupportAccepted = sanitizeTemplate(parsed.settings.templateSupportAccepted);
      parsed.settings.templateSupportScheduled = sanitizeTemplate(parsed.settings.templateSupportScheduled);
      parsed.settings.templateSupportInProgress = sanitizeTemplate(parsed.settings.templateSupportInProgress);
      parsed.settings.templateSupportResolved = sanitizeTemplate(parsed.settings.templateSupportResolved);
    }
    
    return { success: true, data: parsed as ValidatedBackupData };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const issues = error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', ');
      return { success: false, error: `Formato de backup inválido: ${issues}` };
    }
    return { success: false, error: 'Erro ao validar backup' };
  }
}

// Strip sensitive data from backup export
export function stripSensitiveDataForExport(data: Record<string, unknown>): Record<string, unknown> {
  const sanitized = { ...data };
  
  // Remove client passwords
  if (Array.isArray(sanitized.clients)) {
    sanitized.clients = (sanitized.clients as Array<Record<string, unknown>>).map(client => {
      const { password, ...rest } = client;
      return { ...rest, password: '********' };
    });
  }
  
  // Remove admin password
  if (sanitized.settings && typeof sanitized.settings === 'object') {
    const { adminPassword, ...restSettings } = sanitized.settings as Record<string, unknown>;
    sanitized.settings = { ...restSettings, adminPassword: '********' };
  }
  
  return sanitized;
}
