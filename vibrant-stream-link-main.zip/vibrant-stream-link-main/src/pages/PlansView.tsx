import { useState } from 'react';
import { Plus, Edit, Trash2, Save, X, Radio, Tv, Server, Layers, Tag, Package, Wrench, FolderOpen } from 'lucide-react';
import type { Plan } from '@/lib/types';
import { formatCurrency } from '@/lib/format';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface PlansViewProps {
  plans: Plan[];
  setPlans: React.Dispatch<React.SetStateAction<Plan[]>>;
}

const categoryIcons: Record<string, React.ReactNode> = {
  'Streaming Áudio': <Radio size={14} />,
  'Streaming Vídeo': <Tv size={14} />,
  'Hospedagem': <Server size={14} />,
  'Combo': <Layers size={14} />,
  'Outros': <Tag size={14} />,
};

const typeConfig = {
  plan: { label: 'Plano', icon: <Package size={14} />, class: 'bg-primary/10 text-primary border-primary/20' },
  service: { label: 'Serviço', icon: <Wrench size={14} />, class: 'bg-success/10 text-success border-success/20' },
  category: { label: 'Categoria', icon: <FolderOpen size={14} />, class: 'bg-warning/10 text-warning border-warning/20' },
};

export function PlansView({ plans, setPlans }: PlansViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [form, setForm] = useState<Partial<Plan>>({});
  const [filterType, setFilterType] = useState<'all' | 'plan' | 'service' | 'category'>('all');

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const openNew = () => {
    setEditingPlan(null);
    setForm({ name: '', price: 0, cost: 0, stock: -1, details: '', category: 'Streaming Áudio', type: 'plan', active: true });
    setIsModalOpen(true);
  };

  const openEdit = (plan: Plan) => {
    setEditingPlan(plan);
    setForm({ ...plan });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!form.name) return;
    if (editingPlan) {
      setPlans((prev) => prev.map((p) => (p.id === editingPlan.id ? { ...p, ...form } as Plan : p)));
    } else {
      setPlans((prev) => [...prev, { ...form, id: `plan_${Date.now()}` } as Plan]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Remover este plano?')) {
      setPlans((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const toggleActive = (plan: Plan) => {
    setPlans((prev) => prev.map((p) => p.id === plan.id ? { ...p, active: !p.active } : p));
  };

  const categories = ['Streaming Áudio', 'Streaming Vídeo', 'Hospedagem', 'Combo', 'Outros'];
  const filtered = filterType === 'all' ? plans : plans.filter(p => (p.type || 'plan') === filterType);

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Planos & Serviços</h1>
          <p className="text-sm text-muted-foreground">Gerencie planos, serviços e categorias.</p>
        </div>
        <div className="flex gap-3">
          <div className="flex gap-1 bg-secondary/50 rounded-lg p-1">
            {(['all', 'plan', 'service', 'category'] as const).map(t => (
              <button key={t} onClick={() => setFilterType(t)}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors ${filterType === t ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                {t === 'all' ? 'Todos' : t === 'plan' ? 'Planos' : t === 'service' ? 'Serviços' : 'Categorias'}
              </button>
            ))}
          </div>
          <button onClick={openNew} className="bg-primary hover:bg-primary/80 text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap" style={{ boxShadow: 'var(--glow-primary)' }}>
            <Plus size={16} /> Novo
          </button>
        </div>
      </div>

      {/* List Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
              <tr>
                <th className="px-6 py-4">Nome</th>
                <th className="px-6 py-4">Tipo</th>
                <th className="px-6 py-4">Categoria</th>
                <th className="px-6 py-4">Preço</th>
                <th className="px-6 py-4">Custo</th>
                <th className="px-6 py-4">Lucro</th>
                <th className="px-6 py-4">Estoque</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((plan) => {
                const tc = typeConfig[plan.type || 'plan'];
                return (
                  <tr key={plan.id} className={`hover:bg-secondary/30 transition-colors ${!plan.active ? 'opacity-50' : ''}`}>
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-bold text-foreground">{plan.name}</p>
                        <p className="text-[11px] text-muted-foreground">{plan.details}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${tc.class}`}>
                        {tc.icon} {tc.label}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                        {categoryIcons[plan.category] || <Tag size={14} />}
                        {plan.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono font-bold text-foreground">{formatCurrency(plan.price)}</td>
                    <td className="px-6 py-4 font-mono text-muted-foreground">{plan.cost > 0 ? formatCurrency(plan.cost) : '—'}</td>
                    <td className="px-6 py-4 font-mono text-success font-bold">{plan.cost > 0 ? formatCurrency(plan.price - plan.cost) : '—'}</td>
                    <td className="px-6 py-4">
                      {plan.stock < 0 ? (
                        <span className="text-xs text-muted-foreground">Ilimitado</span>
                      ) : (
                        <span className={`text-xs font-bold ${plan.stock < 10 ? 'text-warning' : 'text-foreground'}`}>{plan.stock}</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <button onClick={() => toggleActive(plan)} className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${plan.active ? 'bg-success/10 text-success border-success/20' : 'bg-destructive/10 text-destructive border-destructive/20'}`}>
                        {plan.active ? 'Ativo' : 'Inativo'}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => openEdit(plan)} className="bg-info/10 hover:bg-info/20 text-info border border-info/20 p-2 rounded-lg transition-colors">
                              <Edit size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Editar plano, preço e detalhes</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button onClick={() => handleDelete(plan.id)} className="bg-destructive/10 hover:bg-destructive/20 text-destructive border border-destructive/20 p-2 rounded-lg transition-colors">
                              <Trash2 size={14} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent>Excluir permanentemente este plano</TooltipContent>
                        </Tooltip>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="p-12 text-center text-muted-foreground">Nenhum item encontrado.</div>
          )}
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md z-[70] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-foreground">{editingPlan ? 'Editar' : 'Novo Item'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className={labelClass}>Nome</label>
                <input className={inputClass} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Tipo</label>
                  <select className={inputClass} value={form.type || 'plan'} onChange={(e) => setForm({ ...form, type: e.target.value as Plan['type'] })}>
                    <option value="plan">Plano</option>
                    <option value="service">Serviço</option>
                    <option value="category">Categoria</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>Categoria</label>
                  <select className={inputClass} value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                    {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Preço (R$)</label>
                  <input type="number" step="0.01" className={inputClass} value={form.price || ''} onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) })} />
                </div>
                <div>
                  <label className={labelClass}>Custo (R$)</label>
                  <input type="number" step="0.01" className={inputClass} value={form.cost || ''} onChange={(e) => setForm({ ...form, cost: parseFloat(e.target.value) })} />
                </div>
              </div>
              <div>
                <label className={labelClass}>Estoque (-1 = ilimitado)</label>
                <input type="number" className={inputClass} value={form.stock ?? -1} onChange={(e) => setForm({ ...form, stock: parseInt(e.target.value) })} />
              </div>
              <div>
                <label className={labelClass}>Detalhes</label>
                <input className={inputClass} value={form.details || ''} onChange={(e) => setForm({ ...form, details: e.target.value })} />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" checked={form.active ?? true} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="rounded" />
                <label className="text-sm text-muted-foreground">Ativo</label>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-border">
              <button onClick={() => setIsModalOpen(false)} className="bg-secondary hover:bg-muted text-secondary-foreground border border-border px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Cancelar</button>
              <button onClick={handleSave} className="bg-primary hover:bg-primary/80 text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-bold transition-colors flex items-center gap-2" style={{ boxShadow: 'var(--glow-primary)' }}>
                <Save size={16} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
