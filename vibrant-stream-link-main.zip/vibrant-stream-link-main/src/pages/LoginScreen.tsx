import { useState } from 'react';
import { Radio, Lock, User, LogIn, UserPlus, MapPin, FileText, Phone, Globe, Calendar, CheckCircle, XCircle, Loader2, Gift, ShieldAlert } from 'lucide-react';
import type { Client, Plan, CompanySettings, PasswordRecoveryRequest } from '@/lib/types';
import { formatCurrency } from '@/lib/format';
import { validateDocument, formatDocument } from '@/lib/documentValidation';
import { formatPhoneDisplay, stripPhone } from '@/lib/phoneFormat';

interface LoginScreenProps {
  onLoginAdmin: () => void;
  onLoginClient: (clientId: number) => void;
  onRegisterClient: (client: Client) => void;
  clients: Client[];
  plans: Plan[];
  companySettings: CompanySettings;
  isClientRoute: boolean;
  recoveryRequests?: PasswordRecoveryRequest[];
  onRecoveryRequest?: (request: PasswordRecoveryRequest) => void;
}

export function LoginScreen({ onLoginAdmin, onLoginClient, onRegisterClient, clients, plans, companySettings, isClientRoute, recoveryRequests, onRecoveryRequest }: LoginScreenProps) {
  const [view, setView] = useState<'login' | 'register'>('login');
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [error, setError] = useState('');
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<number | null>(null);
  const MAX_ATTEMPTS = 5;
  const LOCKOUT_MS = 60_000; // 1 minute

  // Registration fields
  const [reg, setReg] = useState({
    name: '', ownerName: '', phone: '', password: '', confirmPassword: '',
    document: '', cep: '', address: '', neighborhood: '', city: '', state: '',
    website: '', birthday: '', planId: '', serviceType: 'radio' as 'radio' | 'tv',
    referralCode: '',
  });
  const [docStatus, setDocStatus] = useState<'idle' | 'valid' | 'invalid'>('idle');
  const [cepLoading, setCepLoading] = useState(false);
  const [cepStatus, setCepStatus] = useState<'idle' | 'found' | 'notfound'>('idle');

  const [forgotPassword, setForgotPassword] = useState(false);
  const [recoveryPhone, setRecoveryPhone] = useState('');
  const [recoverySubmitted, setRecoverySubmitted] = useState(false);
  const [recoveryError, setRecoveryError] = useState('');

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground text-sm";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const handlePhoneInput = (value: string, setter: (v: string) => void) => {
    const digits = stripPhone(value);
    setter(digits.slice(0, 13));
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Rate limiting check
    if (lockoutUntil && Date.now() < lockoutUntil) {
      const secsLeft = Math.ceil((lockoutUntil - Date.now()) / 1000);
      setError(`Muitas tentativas. Tente novamente em ${secsLeft}s.`);
      return;
    }
    if (lockoutUntil && Date.now() >= lockoutUntil) {
      setLockoutUntil(null);
      setLoginAttempts(0);
    }

    if (!isClientRoute) {
      if (user === companySettings.adminUser && pass === companySettings.adminPassword) {
        setLoginAttempts(0);
        onLoginAdmin();
      } else {
        const attempts = loginAttempts + 1;
        setLoginAttempts(attempts);
        if (attempts >= MAX_ATTEMPTS) {
          setLockoutUntil(Date.now() + LOCKOUT_MS);
          setError(`Muitas tentativas. Bloqueado por 60 segundos.`);
        } else {
          setError(`Credenciais incorretas. (${MAX_ATTEMPTS - attempts} tentativas restantes)`);
        }
      }
    } else {
      const normalizePhone = (p: string) => {
        const digits = p.replace(/\D/g, '');
        return digits.startsWith('55') && digits.length > 11 ? digits.slice(2) : digits;
      };
      const userNorm = normalizePhone(user);
      const client = clients.find(c => normalizePhone(c.phone) === userNorm && c.password === pass);
      if (client) {
        setLoginAttempts(0);
        onLoginClient(client.id);
      } else {
        const attempts = loginAttempts + 1;
        setLoginAttempts(attempts);
        if (attempts >= MAX_ATTEMPTS) {
          setLockoutUntil(Date.now() + LOCKOUT_MS);
          setError(`Muitas tentativas. Bloqueado por 60 segundos.`);
        } else {
          setError(`WhatsApp ou Senha incorretos. (${MAX_ATTEMPTS - attempts} tentativas restantes)`);
        }
      }
    }
  };

  const handleDocumentChange = (value: string) => {
    const formatted = formatDocument(value);
    setReg(prev => ({ ...prev, document: formatted }));
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length === 11 || cleaned.length === 14) {
      const result = validateDocument(cleaned);
      setDocStatus(result.valid ? 'valid' : 'invalid');
    } else {
      setDocStatus('idle');
    }
  };

  const handleCepChange = async (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    const formatted = cleaned.length > 5 ? `${cleaned.slice(0, 5)}-${cleaned.slice(5, 8)}` : cleaned;
    setReg(prev => ({ ...prev, cep: formatted }));
    if (cleaned.length === 8) {
      setCepLoading(true);
      setCepStatus('idle');
      try {
        const res = await fetch(`https://viacep.com.br/ws/${cleaned}/json/`);
        const data = await res.json();
        if (!data.erro) {
          setReg(prev => ({
            ...prev,
            address: data.logradouro || '',
            neighborhood: data.bairro || '',
            city: data.localidade || '',
            state: data.uf || '',
          }));
          setCepStatus('found');
        } else {
          setCepStatus('notfound');
        }
      } catch {
        setCepStatus('notfound');
      }
      setCepLoading(false);
    }
  };

  const handleRecoverySubmit = () => {
    setRecoveryError('');
    const normalizePhone = (p: string) => {
      const digits = p.replace(/\D/g, '');
      return digits.startsWith('55') && digits.length > 11 ? digits.slice(2) : digits;
    };
    const phoneNorm = normalizePhone(recoveryPhone);
    const client = clients.find(c => normalizePhone(c.phone) === phoneNorm);

    if (!client) {
      setRecoveryError('Nenhuma conta encontrada com este WhatsApp.');
      return;
    }

    // Check if already has a pending request
    const hasPending = recoveryRequests?.some(r => r.clientId === client.id && r.status === 'pending');
    if (hasPending) {
      setRecoveryError('Já existe uma solicitação pendente para este WhatsApp. Aguarde a aprovação do administrador.');
      return;
    }

    const request: PasswordRecoveryRequest = {
      id: Date.now(),
      clientId: client.id,
      clientPhone: client.phone,
      clientName: client.name,
      requestedAt: new Date().toISOString(),
      status: 'pending',
    };

    onRecoveryRequest?.(request);
    setRecoverySubmitted(true);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!reg.name || !reg.phone || !reg.password) {
      setError('Preencha os campos obrigatórios: Nome, WhatsApp e Senha.');
      return;
    }
    if (reg.password !== reg.confirmPassword) {
      setError('As senhas não coincidem.');
      return;
    }
    if (reg.password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    if (clients.some(c => c.phone === reg.phone)) {
      setError('Já existe uma conta com este WhatsApp.');
      return;
    }
    if (docStatus === 'invalid') {
      setError('O documento informado (CPF/CNPJ) é inválido.');
      return;
    }

    const selectedPlan = plans.find(p => p.id === reg.planId) || plans.find(p => p.active);
    const d = new Date();
    d.setDate(d.getDate() + 30);

    const newClient: Client = {
      id: Date.now(),
      name: reg.name,
      ownerName: reg.ownerName || reg.name,
      phone: reg.phone,
      password: reg.password,
      document: reg.document,
      cep: reg.cep,
      address: reg.address,
      neighborhood: reg.neighborhood,
      city: reg.city,
      state: reg.state,
      website: reg.website,
      birthday: reg.birthday,
      status: 'active',
      paymentStatus: 'pending',
      planId: selectedPlan?.id || 'basic',
      amount: selectedPlan?.price || 0,
      dueDate: d.toISOString().split('T')[0],
      startDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      serviceType: reg.serviceType,
      recurrence: 'monthly',
      referredBy: reg.referralCode || undefined,
      audioUrl: '', videoUrl: '', port: '', logoUrl: '',
      history: [{ date: new Date().toISOString(), action: 'Cliente registrou-se via Portal.', user: 'O Próprio' }],
      schedules: [],
    };

    onRegisterClient(newClient);
    onLoginClient(newClient.id);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/3 rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 w-full max-w-md mx-4 my-8">
        {/* Logo */}
        <div className="text-center mb-6">
          {companySettings?.logoUrl ? (
            <div className="w-20 h-20 rounded-2xl bg-card border border-border flex items-center justify-center mx-auto mb-4 overflow-hidden">
              <img src={companySettings.logoUrl} className="w-full h-full object-cover" alt="" />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4">
              <Radio size={28} className="text-primary" />
            </div>
          )}
          <h1 className="text-2xl font-black text-foreground tracking-tight">{companySettings?.name || 'StreamPRO'}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {isClientRoute ? 'Central do Cliente' : 'Painel de Gestão'}
          </p>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl p-6 max-h-[75vh] overflow-y-auto custom-scrollbar">
          {isClientRoute && (
            <div className="flex gap-1 bg-secondary/50 rounded-lg p-1 mb-5">
              <button onClick={() => { setView('login'); setError(''); }} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${view === 'login' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                <LogIn size={14} /> Entrar
              </button>
              <button onClick={() => { setView('register'); setError(''); }} className={`flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 ${view === 'register' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                <UserPlus size={14} /> Criar Conta
              </button>
            </div>
          )}

          {error && (
            <div className="bg-destructive/10 border border-destructive/20 text-destructive text-sm p-3 rounded-lg font-medium mb-4 flex items-center gap-2">
              <XCircle size={16} /> {error}
            </div>
          )}

          {view === 'login' ? (
            forgotPassword && isClientRoute ? (
              <div className="space-y-4">
                {recoverySubmitted ? (
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto">
                      <ShieldAlert size={28} className="text-primary" />
                    </div>
                    <h3 className="text-base font-bold text-foreground">Solicitação Enviada!</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Sua solicitação de recuperação de senha foi enviada ao administrador. 
                      Você receberá uma confirmação via WhatsApp assim que for aprovada.
                    </p>
                    <div className="bg-warning/10 border border-warning/20 text-warning text-xs p-3 rounded-lg font-medium">
                      ⏳ Aguardando aprovação do administrador...
                    </div>
                    <button type="button" onClick={() => { setForgotPassword(false); setRecoverySubmitted(false); setRecoveryPhone(''); setRecoveryError(''); }} className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors">
                      ← Voltar ao login
                    </button>
                  </div>
                ) : (
                  <>
                    <p className="text-sm text-muted-foreground text-center">Informe seu WhatsApp cadastrado. Uma solicitação será enviada ao administrador para aprovação.</p>
                    <div>
                      <label className={labelClass}>WhatsApp (com DDD)</label>
                      <div className="relative">
                        <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                        <input className={`${inputClass} pl-10`} value={formatPhoneDisplay(recoveryPhone)} onChange={e => handlePhoneInput(e.target.value, setRecoveryPhone)} placeholder="+55 (11) 99999-9999" />
                      </div>
                    </div>
                    {recoveryError && (
                      <div className="bg-destructive/10 border border-destructive/20 text-destructive text-sm p-3 rounded-lg font-medium flex items-center gap-2">
                        <XCircle size={16} /> {recoveryError}
                      </div>
                    )}
                    <button type="button" onClick={handleRecoverySubmit} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                      <Lock size={18} /> Solicitar Recuperação
                    </button>
                    <button type="button" onClick={() => { setForgotPassword(false); setRecoveryPhone(''); setRecoveryError(''); }} className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors">
                      ← Voltar ao login
                    </button>
                  </>
                )}
              </div>
            ) : (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className={labelClass}>{isClientRoute ? 'Seu WhatsApp (com DDD)' : 'Usuário'}</label>
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  {isClientRoute ? (
                    <input className={`${inputClass} pl-10`} value={formatPhoneDisplay(user)} onChange={e => handlePhoneInput(e.target.value, setUser)} placeholder="+55 (11) 99999-9999" />
                  ) : (
                    <input className={`${inputClass} pl-10`} value={user} onChange={e => setUser(e.target.value)} placeholder="Usuário admin" />
                  )}
                </div>
              </div>
              <div>
                <label className={labelClass}>Senha</label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input type="password" className={`${inputClass} pl-10`} value={pass} onChange={e => setPass(e.target.value)} placeholder="••••••••" />
                </div>
              </div>
              <button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2" style={{ boxShadow: 'var(--glow-primary)' }}>
                <LogIn size={18} /> Acessar
              </button>
              {isClientRoute && (
                <button type="button" onClick={() => { setForgotPassword(true); setError(''); }} className="w-full text-sm text-muted-foreground hover:text-primary transition-colors">
                  Esqueci minha senha
                </button>
              )}
            </form>
            )
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-3">
              <p className="text-xs text-muted-foreground text-center mb-2">Campos com <span className="text-destructive">*</span> são obrigatórios</p>

              {/* Name */}
              <div>
                <label className={labelClass}>Nome da Rádio / Empresa <span className="text-destructive">*</span></label>
                <input className={inputClass} value={reg.name} onChange={e => setReg({ ...reg, name: e.target.value })} placeholder="Ex: Rádio Exemplo FM" />
              </div>

              {/* Owner */}
              <div>
                <label className={labelClass}>Nome do Responsável</label>
                <input className={inputClass} value={reg.ownerName} onChange={e => setReg({ ...reg, ownerName: e.target.value })} placeholder="Nome completo" />
              </div>

              {/* Phone + Password */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>WhatsApp <span className="text-destructive">*</span></label>
                  <div className="relative">
                    <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input className={`${inputClass} pl-9`} value={formatPhoneDisplay(reg.phone)} onChange={e => handlePhoneInput(e.target.value, (v) => setReg(prev => ({ ...prev, phone: v })))} placeholder="+55 (11) 99..." />
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Senha <span className="text-destructive">*</span></label>
                  <div className="relative">
                    <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input type="password" className={`${inputClass} pl-9`} value={reg.password} onChange={e => setReg({ ...reg, password: e.target.value })} placeholder="Mín. 6 chars" />
                  </div>
                </div>
              </div>

              <div>
                <label className={labelClass}>Confirmar Senha <span className="text-destructive">*</span></label>
                <input type="password" className={inputClass} value={reg.confirmPassword} onChange={e => setReg({ ...reg, confirmPassword: e.target.value })} placeholder="Repita a senha" />
              </div>

              {/* Document */}
              <div>
                <label className={labelClass}>CPF / CNPJ</label>
                <div className="relative">
                  <FileText size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input className={`${inputClass} pl-9 pr-10`} value={reg.document} onChange={e => handleDocumentChange(e.target.value)} placeholder="000.000.000-00" maxLength={18} />
                  {docStatus === 'valid' && <CheckCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-success" />}
                  {docStatus === 'invalid' && <XCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-destructive" />}
                </div>
                {docStatus === 'valid' && <p className="text-[10px] text-success mt-1">✓ Documento válido</p>}
                {docStatus === 'invalid' && <p className="text-[10px] text-destructive mt-1">✗ Documento inválido</p>}
              </div>

              {/* CEP + Address */}
              <div>
                <label className={labelClass}>CEP</label>
                <div className="relative">
                  <MapPin size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input className={`${inputClass} pl-9 pr-10`} value={reg.cep} onChange={e => handleCepChange(e.target.value)} placeholder="00000-000" maxLength={9} />
                  {cepLoading && <Loader2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-primary animate-spin" />}
                  {cepStatus === 'found' && <CheckCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-success" />}
                  {cepStatus === 'notfound' && <XCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-destructive" />}
                </div>
              </div>

              {cepStatus === 'found' && (
                <div className="bg-success/5 border border-success/20 rounded-lg p-3 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-muted-foreground uppercase block mb-1">Endereço</label>
                      <input className={inputClass} value={reg.address} onChange={e => setReg({ ...reg, address: e.target.value })} />
                    </div>
                    <div>
                      <label className="text-[10px] text-muted-foreground uppercase block mb-1">Bairro</label>
                      <input className={inputClass} value={reg.neighborhood} onChange={e => setReg({ ...reg, neighborhood: e.target.value })} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-muted-foreground uppercase block mb-1">Cidade</label>
                      <input className={inputClass} value={reg.city} readOnly />
                    </div>
                    <div>
                      <label className="text-[10px] text-muted-foreground uppercase block mb-1">UF</label>
                      <input className={inputClass} value={reg.state} readOnly />
                    </div>
                  </div>
                </div>
              )}

              {/* Extra fields */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Site / App</label>
                  <div className="relative">
                    <Globe size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input className={`${inputClass} pl-9`} value={reg.website} onChange={e => setReg({ ...reg, website: e.target.value })} placeholder="https://..." />
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Aniversário</label>
                  <div className="relative">
                    <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input type="date" className={`${inputClass} pl-9`} value={reg.birthday} onChange={e => setReg({ ...reg, birthday: e.target.value })} />
                  </div>
                </div>
              </div>

              {/* Service Type */}
              <div>
                <label className={labelClass}>Tipo de Serviço</label>
                <div className="flex gap-2">
                  {(['radio', 'tv'] as const).map(t => (
                    <button key={t} type="button" onClick={() => setReg({ ...reg, serviceType: t })}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase transition-colors border ${reg.serviceType === t ? 'bg-primary/10 text-primary border-primary/30' : 'bg-secondary/50 text-muted-foreground border-border hover:text-foreground'}`}>
                      {t === 'radio' ? '📻 Rádio' : '📺 TV'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Plan */}
              <div>
                <label className={labelClass}>Escolha seu Plano</label>
                <select className={inputClass} value={reg.planId} onChange={e => setReg({ ...reg, planId: e.target.value })}>
                  <option value="">Selecione um plano...</option>
                  {plans.filter(p => p.active && p.type === 'plan').map(p => (
                    <option key={p.id} value={p.id}>{p.name} - {formatCurrency(p.price)}/mês</option>
                  ))}
                </select>
              </div>

              {/* Referral Code */}
              <div>
                <label className={labelClass}>Código de Indicação</label>
                <div className="relative">
                  <Gift size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input className={`${inputClass} pl-9`} value={reg.referralCode} onChange={e => setReg({ ...reg, referralCode: e.target.value })} placeholder="Cole aqui o código (opcional)" />
                </div>
              </div>

              <button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2" style={{ boxShadow: 'var(--glow-primary)' }}>
                <UserPlus size={18} /> Criar Minha Conta
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          © {new Date().getFullYear()} {companySettings?.name || 'StreamPRO'}
        </p>
      </div>
    </div>
  );
}
