import { CalendarDays, UserPlus, CheckSquare } from 'lucide-react';
import type { Client, Transaction } from '@/lib/types';
import { formatCurrency } from '@/lib/format';

interface ActivityTimelineProps {
  clients: Client[];
  transactions: Transaction[];
}

export function ActivityTimeline({ clients, transactions }: ActivityTimelineProps) {
  const events = [
    ...(clients || []).map((c) => ({
      type: 'new_client' as const,
      date: new Date(c.createdAt || Date.now()),
      title: 'Novo Cliente',
      desc: c.name,
    })),
    ...(transactions || []).map((t) => ({
      type: 'payment' as const,
      date: new Date(t.date),
      title: 'Pagamento',
      desc: `${t.clientName} - ${formatCurrency(t.amount)}`,
    })),
  ]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 5);

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <h3 className="font-bold text-foreground mb-6 flex items-center gap-2">
        <CalendarDays size={20} className="text-warning" /> Atividade Recente
      </h3>
      <div className="relative border-l border-border ml-3 space-y-6">
        {events.length > 0 ? (
          events.map((evt, i) => (
            <div key={i} className="relative pl-6">
              <span
                className={`absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full ring-4 ring-card ${
                  evt.type === 'new_client' ? 'bg-primary' : 'bg-success'
                }`}
              />
              <div>
                <p className="text-sm text-foreground font-medium">{evt.title}</p>
                <p className="text-sm text-muted-foreground">{evt.desc}</p>
                <p className="text-[10px] text-muted-foreground/50 mt-1 uppercase tracking-wider">
                  {evt.date.toLocaleDateString()} às{' '}
                  {evt.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-muted-foreground text-sm pl-6">Sem eventos recentes.</p>
        )}
      </div>
    </div>
  );
}
