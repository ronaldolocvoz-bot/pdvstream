export interface Client {
  id: number;
  name: string;
  ownerName: string;
  document: string;
  cep: string;
  address: string;
  neighborhood: string;
  city: string;
  state: string;
  website: string;
  logoUrl: string;
  audioUrl: string;
  videoUrl: string;
  port: string;
  password: string;
  status: 'active' | 'inactive';
  paymentStatus: 'paid' | 'pending' | 'overdue' | 'cancelled';
  recurrence: 'monthly' | 'quarterly' | 'yearly';
  planId: string;
  amount: number;
  startDate: string;
  dueDate: string;
  phone: string;
  birthday: string;
  serviceType: 'radio' | 'tv';
  serverId?: number;
  schedules: Schedule[];
  affiliateCode?: string;
  referredBy?: string;
  affiliateCredits?: number;
  createdAt: string;
  history: HistoryEntry[];
}

export interface Schedule {
  id: number;
  type: 'once' | 'recurring';
  date: string;
  time: string;
  days: number[];
  status: 'pending' | 'sent';
  createdAt: string;
}

export interface HistoryEntry {
  date: string;
  action: string;
  user: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  cost: number;
  stock: number;
  details: string;
  category: string;
  type: 'plan' | 'service' | 'category';
  active: boolean;
}

export interface Category {
  id: string;
  iconName: string;
  color: string;
}

export interface Transaction {
  id: number;
  date: string;
  amount: number;
  type: 'payment' | 'income' | 'expense' | 'withdrawal';
  status: 'paid' | 'pending' | 'cancelled';
  clientName: string;
  description: string;
  clientId?: number;
  dueDate?: string;
  paymentDate?: string;
}

export interface Ticket {
  id: number;
  clientId: number;
  subject: string;
  description: string;
  status: 'open' | 'accepted' | 'scheduled' | 'in_progress' | 'resolved';
  scheduledDate: string;
  scheduledTime: string;
  createdAt: string;
  history?: TicketMessage[];
  lastAdminReadAt?: string;
  lastClientReadAt?: string;
}

export interface TicketMessage {
  id: number;
  type: 'system' | 'admin' | 'client';
  text: string;
  date: string;
}

export interface Server {
  id: number;
  name: string;
  ip: string;
  port: string;
  type: 'icecast' | 'wowza' | 'cpanel' | 'other';
  capacity: number;
  usage: number;
  status: 'online' | 'offline' | 'warning';
  location: string;
}

export interface CompanySettings {
  name: string;
  website: string;
  logoUrl: string;
  cep: string;
  address: string;
  document: string;
  phone: string;
  supportPhone: string;
  pixKey: string;
  pixQrCodeUrl: string;
  bankInfo: string;
  paymentMethods: string;
  adminUser: string;
  adminPassword: string;
  templateOverdue: string;
  templatePending: string;
  templateThanks: string;
  templateWelcome: string;
  templateSupportAccepted: string;
  templateSupportScheduled: string;
  templateSupportInProgress: string;
  templateSupportResolved: string;
  theme: 'dark' | 'light';
  fontSize: number;
  colorScheme: string;
  customColor?: string;
  autoBackupEnabled: boolean;
  autoBackupDay: number;
  lastAutoBackupDate?: string;
}

export interface DownloadFolder {
  id: string;
  name: string;
  createdAt: string;
  clientIds: number[]; // empty = not released, specific ids = released to those clients
}

export interface DownloadFile {
  id: string;
  folderId: string;
  name: string;
  size: number;
  type: string;
  data: string; // base64
  createdAt: string;
}

export interface PasswordRecoveryRequest {
  id: number;
  clientId: number;
  clientPhone: string;
  clientName: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export type ViewType = 'dashboard' | 'clients' | 'invoices' | 'plans' | 'servers' | 'settings' | 'support' | 'client-central' | 'downloads';
