import { useState } from 'react';
import { Search, MessageCircle, CheckSquare, AlertTriangle, Printer, Radio, Tv, Plus, X, Trash2, Edit, DollarSign, ArrowDownCircle, ArrowUpCircle, Wallet } from 'lucide-react';
import type { Client, Transaction, CompanySettings } from '@/lib/types';
import { formatCurrency, getReceiptHTML } from '@/lib/format';
import { StatusBadge } from '@/components/StatusBadge';
import { CompactStreamPlayer } from '@/components/CompactStreamPlayer';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface InvoicesViewProps {
  clients: Client[];
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  sendWhatsApp: (client: Client, reason?: string) => void;
  handleConfirmPayment: (client: Client) => void;
  companySettings: CompanySettings;
}

export function InvoicesView({ clients, transactions, setTransactions, sendWhatsApp, handleConfirmPayment, companySettings }: InvoicesViewProps) {
  const [activeTab, setActiveTab] = useState<'pending' | 'overdue' | 'paid' | 'expenses' | 'all'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewInvoice, setShowNewInvoice] = useState(false);
  const [showNewExpense, setShowNewExpense] = useState(false);
  const [invoiceForm, setInvoiceForm] = useState({ clientId: '', amount: 0, description: 'Fatura Avulsa' });
  const [expenseForm, setExpenseForm] = useState({ description: '', amount: 0, category: 'Servidor' });

  const inputClass = "w-full bg-background border border-border rounded-lg p-2.5 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground";
  const labelClass = "text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block font-medium";

  const today = new Date().toISOString().split('T')[0];
  const pendingInvoices = (clients || []).filter(c => c.status !== 'inactive' && c.paymentStatus !== 'paid' && c.dueDate >= today);
  const overdueInvoices = (clients || []).filter(c => c.status !== 'inactive' && c.paymentStatus !== 'paid' && c.dueDate < today);
  const paidInvoices = (transactions || []).filter(t => t.status === 'paid' && t.type === 'income').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const expenses = (transactions || []).filter(t => t.type === 'expense').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const allTransactions = (transactions || []).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const filteredPending = pendingInvoices.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredOverdue = overdueInvoices.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredPaid = paidInvoices.filter(t => t.clientName.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredExpenses = expenses.filter(t => t.description.toLowerCase().includes(searchTerm.toLowerCase()) || t.clientName.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredAll = allTransactions.filter(t => t.clientName.toLowerCase().includes(searchTerm.toLowerCase()) || t.description.toLowerCase().includes(searchTerm.toLowerCase()));

  const totalPending = pendingInvoices.reduce((acc, c) => acc + (c.amount || 0), 0);
  const totalOverdue = overdueInvoices.reduce((acc, c) => acc + (c.amount || 0), 0);
  const totalPaidThisMonth = paidInvoices.filter(t => { const d = new Date(t.date); const now = new Date(); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); }).reduce((acc, t) => acc + (t.amount || 0), 0);
  const totalExpensesThisMonth = expenses.filter(t => { const d = new Date(t.date); const now = new Date(); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); }).reduce((acc, t) => acc + (t.amount || 0), 0);

  const handlePrintReceipt = (transaction: Transaction) => {
    const client = clients.find(c => c.name === transaction.clientName);
    const w = window.open('', '', 'width=900,height=800');
    if (w) { w.document.write(getReceiptHTML(transaction.clientName, client?.phone || '', transaction.amount, transaction.date, companySettings, transaction.id)); w.document.close(); }
  };

  const handleAddInvoice = () => {
    if (!invoiceForm.clientId || !invoiceForm.amount) return;
    const client = clients.find(c => c.id === parseInt(invoiceForm.clientId));
    if (!client) return;
    const newTx: Transaction = {
      id: Date.now(), date: new Date().toISOString(), amount: invoiceForm.amount,
      type: 'income', status: 'pending', clientName: client.name, clientId: client.id, description: invoiceForm.description,
    };
    setTransactions(prev => [newTx, ...prev]);
    setShowNewInvoice(false);
    setInvoiceForm({ clientId: '', amount: 0, description: 'Fatura Avulsa' });
  };

  const handleAddExpense = () => {
    if (!expenseForm.description || !expenseForm.amount) return;
    const newTx: Transaction = {
      id: Date.now(), date: new Date().toISOString(), amount: expenseForm.amount,
      type: 'expense', status: 'paid', clientName: expenseForm.category, description: expenseForm.description,
    };
    setTransactions(prev => [newTx, ...prev]);
    setShowNewExpense(false);
    setExpenseForm({ description: '', amount: 0, category: 'Servidor' });
  };

  const handleDeleteTransaction = (id: number) => {
    if (window.confirm('Excluir esta transação?')) setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const tabs = [
    { id: 'pending' as const, label: `A Vencer (${pendingInvoices.length})`, activeClass: 'text-warning border-b-2 border-warning bg-warning/5', icon: <ArrowUpCircle size={14} /> },
    { id: 'overdue' as const, label: `Vencidas (${overdueInvoices.length})`, activeClass: 'text-destructive border-b-2 border-destructive bg-destructive/5', icon: <AlertTriangle size={14} /> },
    { id: 'paid' as const, label: 'Recebidas', activeClass: 'text-success border-b-2 border-success bg-success/5', icon: <CheckSquare size={14} /> },
    { id: 'expenses' as const, label: `Despesas (${expenses.length})`, activeClass: 'text-info border-b-2 border-info bg-info/5', icon: <ArrowDownCircle size={14} /> },
    { id: 'all' as const, label: 'Extrato Geral', activeClass: 'text-primary border-b-2 border-primary bg-primary/5', icon: <Wallet size={14} /> },
  ];

  const ClientIcon = ({ client }: { client: Partial<Client> }) => (
    <div className="w-8 h-8 rounded-lg bg-background border border-border flex items-center justify-center overflow-hidden flex-shrink-0">
      {client.logoUrl ? <img src={client.logoUrl} className="w-full h-full object-cover" alt="" /> :
        client.serviceType === 'tv' ? <Tv size={14} className="text-muted-foreground" /> : <Radio size={14} className="text-muted-foreground" />}
    </div>
  );

  const renderClientRow = (client: Client, variant: 'pending' | 'overdue') => (
    <tr key={client.id} className={`hover:bg-secondary/30 transition-colors ${variant === 'overdue' ? 'bg-destructive/5' : ''}`}>
      <td className="px-6 py-4 font-medium text-foreground">
        <div className="flex items-center gap-3">
          {companySettings.logoUrl && <img src={companySettings.logoUrl} className="w-6 h-6 rounded object-cover flex-shrink-0" alt="" />}
          <ClientIcon client={client} /><span>{client.name}</span>
        </div>
      </td>
      <td className="px-6 py-4"><CompactStreamPlayer url={client.audioUrl} type={client.serviceType} /></td>
      <td className="px-6 py-4"><StatusBadge status={client.paymentStatus} dueDate={client.dueDate} /></td>
      <td className={`px-6 py-4 font-mono font-bold ${variant === 'overdue' ? 'text-destructive' : ''}`}>{formatCurrency(client.amount)}</td>
      <td className={`px-6 py-4 ${variant === 'overdue' ? 'text-destructive font-bold' : 'text-muted-foreground'}`}>{new Date(client.dueDate).toLocaleDateString()}</td>
      <td className="px-6 py-4 text-right">
        <div className="flex justify-end gap-2">
          {variant === 'pending' ? (
            <>
              <Tooltip><TooltipTrigger asChild>
                <button onClick={() => sendWhatsApp(client, 'pending')} className="bg-warning/20 text-warning hover:bg-warning/30 border border-warning/30 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                  <MessageCircle size={14} /> Notificar
                </button>
              </TooltipTrigger><TooltipContent>Enviar lembrete de fatura via WhatsApp</TooltipContent></Tooltip>
              <Tooltip><TooltipTrigger asChild>
                <button onClick={() => handleConfirmPayment(client)} className="bg-success hover:bg-success/80 text-success-foreground px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5" style={{ boxShadow: 'var(--glow-success)' }}>
                  <CheckSquare size={14} /> Baixa
                </button>
              </TooltipTrigger><TooltipContent>Confirmar pagamento e gerar recibo</TooltipContent></Tooltip>
            </>
          ) : (
            <>
              <Tooltip><TooltipTrigger asChild>
                <button onClick={() => sendWhatsApp(client, 'overdue')} className="bg-destructive hover:bg-destructive/80 text-destructive-foreground px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5" style={{ boxShadow: 'var(--glow-destructive)' }}>
                  <AlertTriangle size={14} /> Cobrar
                </button>
              </TooltipTrigger><TooltipContent>Enviar cobrança de atraso via WhatsApp</TooltipContent></Tooltip>
              <Tooltip><TooltipTrigger asChild>
                <button onClick={() => handleConfirmPayment(client)} className="bg-secondary hover:bg-success hover:text-success-foreground border border-border hover:border-success px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                  <CheckSquare size={14} /> Baixa
                </button>
              </TooltipTrigger><TooltipContent>Confirmar pagamento recebido</TooltipContent></Tooltip>
            </>
          )}
        </div>
      </td>
    </tr>
  );

  return (
    <div className="space-y-6 pb-32 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Faturas & Financeiro</h1>
          <p className="text-sm text-muted-foreground">Contas a receber, a pagar, despesas e extrato geral.</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto flex-wrap">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input type="text" placeholder="Buscar..." className={`w-full bg-background border border-border rounded-lg p-2.5 pl-10 text-foreground outline-none focus:border-primary transition-colors placeholder:text-muted-foreground`} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
          <Tooltip>
            <TooltipTrigger asChild>
              <button onClick={() => setShowNewInvoice(true)} className="bg-success/10 hover:bg-success/20 text-success border border-success/20 px-3 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap">
                <Plus size={16} /> Fatura
              </button>
            </TooltipTrigger>
            <TooltipContent>Adicionar fatura avulsa de receita para um cliente</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <button onClick={() => setShowNewExpense(true)} className="bg-destructive/10 hover:bg-destructive/20 text-destructive border border-destructive/20 px-3 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap">
                <ArrowDownCircle size={16} /> Despesa
              </button>
            </TooltipTrigger>
            <TooltipContent>Registrar uma nova despesa ou conta a pagar</TooltipContent>
          </Tooltip>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5 border-l-4 border-l-destructive">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Atrasadas</p>
          <h3 className="text-2xl font-bold text-destructive">{formatCurrency(totalOverdue)}</h3>
          <p className="text-[10px] text-destructive/50 mt-1 font-medium">{overdueInvoices.length} em aberto</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5 border-l-4 border-l-warning">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">A Receber</p>
          <h3 className="text-2xl font-bold text-warning">{formatCurrency(totalPending)}</h3>
          <p className="text-[10px] text-muted-foreground mt-1">{pendingInvoices.length} faturas</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5 border-l-4 border-l-success">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Recebido (Mês)</p>
          <h3 className="text-2xl font-bold text-success">{formatCurrency(totalPaidThisMonth)}</h3>
          <p className="text-[10px] text-muted-foreground mt-1">Receita confirmada</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5 border-l-4 border-l-info">
          <p className="text-xs font-medium text-muted-foreground mb-1 uppercase tracking-wider">Despesas (Mês)</p>
          <h3 className="text-2xl font-bold text-info">{formatCurrency(totalExpensesThisMonth)}</h3>
          <p className="text-[10px] text-muted-foreground mt-1">Lucro: {formatCurrency(totalPaidThisMonth - totalExpensesThisMonth)}</p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="flex border-b border-border overflow-x-auto custom-scrollbar">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex-1 min-w-[120px] p-3 font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 ${activeTab === tab.id ? tab.activeClass : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/50 text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
              <tr>
                <th className="px-6 py-4">{activeTab === 'expenses' || activeTab === 'all' ? 'Descrição' : 'Cliente'}</th>
                {activeTab !== 'expenses' && activeTab !== 'all' && <th className="px-6 py-4">Stream</th>}
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">{activeTab === 'paid' || activeTab === 'expenses' || activeTab === 'all' ? 'Data' : 'Vencimento'}</th>
                {(activeTab === 'all') && <th className="px-6 py-4">Tipo</th>}
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {activeTab === 'pending' && filteredPending.map(c => renderClientRow(c, 'pending'))}
              {activeTab === 'overdue' && filteredOverdue.map(c => renderClientRow(c, 'overdue'))}
              {activeTab === 'paid' && filteredPaid.map(tx => {
                const client = clients.find(c => c.name === tx.clientName) || {} as Partial<Client>;
                return (
                  <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-6 py-4 font-medium text-foreground">
                      <div className="flex items-center gap-3"><ClientIcon client={client} /><span>{tx.clientName}</span></div>
                    </td>
                    <td className="px-6 py-4"><StatusBadge status="paid" /></td>
                    <td className="px-6 py-4"><span className="bg-success/10 text-success border border-success/20 px-2 py-0.5 rounded-full text-[10px] font-bold">Pago</span></td>
                    <td className="px-6 py-4 font-mono font-bold text-success">{formatCurrency(tx.amount)}</td>
                    <td className="px-6 py-4 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1">
                        <Tooltip><TooltipTrigger asChild>
                          <button onClick={() => handlePrintReceipt(tx)} className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors inline-flex items-center gap-1.5">
                            <Printer size={14} /> Recibo
                          </button>
                        </TooltipTrigger><TooltipContent>Gerar recibo em PDF para impressão</TooltipContent></Tooltip>
                        <Tooltip><TooltipTrigger asChild>
                          <button onClick={() => handleDeleteTransaction(tx.id)} className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 p-1.5 rounded-lg transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </TooltipTrigger><TooltipContent>Excluir transação</TooltipContent></Tooltip>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {activeTab === 'expenses' && filteredExpenses.map(tx => (
                <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-foreground">
                    <div><p>{tx.description}</p><p className="text-[10px] text-muted-foreground">{tx.clientName}</p></div>
                  </td>
                  <td className="px-6 py-4"><span className="bg-info/10 text-info border border-info/20 px-2 py-0.5 rounded-full text-[10px] font-bold">{tx.status === 'paid' ? 'Pago' : 'Pendente'}</span></td>
                  <td className="px-6 py-4 font-mono font-bold text-destructive">-{formatCurrency(tx.amount)}</td>
                  <td className="px-6 py-4 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                  <td className="px-6 py-4 text-right">
                    <Tooltip><TooltipTrigger asChild>
                      <button onClick={() => handleDeleteTransaction(tx.id)} className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 p-1.5 rounded-lg transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </TooltipTrigger><TooltipContent>Excluir despesa</TooltipContent></Tooltip>
                  </td>
                </tr>
              ))}
              {activeTab === 'all' && filteredAll.map(tx => (
                <tr key={tx.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-foreground">
                    <div><p>{tx.description}</p><p className="text-[10px] text-muted-foreground">{tx.clientName}</p></div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tx.status === 'paid' ? 'bg-success/10 text-success border-success/20' : 'bg-warning/10 text-warning border-warning/20'}`}>
                      {tx.status === 'paid' ? 'Pago' : 'Pendente'}
                    </span>
                  </td>
                  <td className={`px-6 py-4 font-mono font-bold ${tx.type === 'expense' ? 'text-destructive' : 'text-success'}`}>
                    {tx.type === 'expense' ? '-' : '+'}{formatCurrency(tx.amount)}
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tx.type === 'income' ? 'bg-success/10 text-success border-success/20' : tx.type === 'expense' ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-secondary text-muted-foreground border-border'}`}>
                      {tx.type === 'income' ? 'Receita' : tx.type === 'expense' ? 'Despesa' : tx.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Tooltip><TooltipTrigger asChild>
                      <button onClick={() => handleDeleteTransaction(tx.id)} className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 p-1.5 rounded-lg transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </TooltipTrigger><TooltipContent>Excluir transação</TooltipContent></Tooltip>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {activeTab === 'pending' && filteredPending.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhuma fatura a vencer.</div>}
          {activeTab === 'overdue' && filteredOverdue.length === 0 && <div className="p-12 text-center text-success font-medium">Ninguém está com mensalidade atrasada!</div>}
          {activeTab === 'paid' && filteredPaid.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhum pagamento registrado.</div>}
          {activeTab === 'expenses' && filteredExpenses.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhuma despesa registrada.</div>}
          {activeTab === 'all' && filteredAll.length === 0 && <div className="p-12 text-center text-muted-foreground">Nenhuma transação encontrada.</div>}
        </div>
      </div>

      {/* New Invoice Modal */}
      {showNewInvoice && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-foreground flex items-center gap-2"><ArrowUpCircle size={18} className="text-success" /> Nova Fatura (Receita)</h3>
              <button onClick={() => setShowNewInvoice(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <div>
              <label className={labelClass}>Cliente</label>
              <select className={inputClass} value={invoiceForm.clientId} onChange={e => { const c = clients.find(cl => cl.id === parseInt(e.target.value)); setInvoiceForm({ ...invoiceForm, clientId: e.target.value, amount: c?.amount || 0 }); }}>
                <option value="">Selecionar...</option>
                {clients.filter(c => c.status === 'active').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className={labelClass}>Valor (R$)</label>
              <input type="number" step="0.01" className={inputClass} value={invoiceForm.amount} onChange={e => setInvoiceForm({ ...invoiceForm, amount: parseFloat(e.target.value) })} />
            </div>
            <div>
              <label className={labelClass}>Descrição</label>
              <input className={inputClass} value={invoiceForm.description} onChange={e => setInvoiceForm({ ...invoiceForm, description: e.target.value })} />
            </div>
            <button onClick={handleAddInvoice} className="w-full bg-success hover:bg-success/90 text-success-foreground py-2.5 rounded-xl font-bold transition-colors">
              Gerar Fatura
            </button>
          </div>
        </div>
      )}

      {/* New Expense Modal */}
      {showNewExpense && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-foreground flex items-center gap-2"><ArrowDownCircle size={18} className="text-destructive" /> Nova Despesa</h3>
              <button onClick={() => setShowNewExpense(false)} className="text-muted-foreground hover:text-foreground"><X size={20} /></button>
            </div>
            <div>
              <label className={labelClass}>Categoria</label>
              <select className={inputClass} value={expenseForm.category} onChange={e => setExpenseForm({ ...expenseForm, category: e.target.value })}>
                <option value="Servidor">Servidor / Infraestrutura</option>
                <option value="Software">Software / Licenças</option>
                <option value="Marketing">Marketing / Publicidade</option>
                <option value="Pessoal">Pessoal / Salários</option>
                <option value="Impostos">Impostos / Taxas</option>
                <option value="Outros">Outros</option>
              </select>
            </div>
            <div>
              <label className={labelClass}>Descrição</label>
              <input className={inputClass} value={expenseForm.description} onChange={e => setExpenseForm({ ...expenseForm, description: e.target.value })} placeholder="Ex: Pagamento servidor VPS" />
            </div>
            <div>
              <label className={labelClass}>Valor (R$)</label>
              <input type="number" step="0.01" className={inputClass} value={expenseForm.amount} onChange={e => setExpenseForm({ ...expenseForm, amount: parseFloat(e.target.value) })} />
            </div>
            <button onClick={handleAddExpense} className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground py-2.5 rounded-xl font-bold transition-colors">
              Registrar Despesa
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
