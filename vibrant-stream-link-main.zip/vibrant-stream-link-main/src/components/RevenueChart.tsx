import { BarChart3, TrendingUp, TrendingDown } from 'lucide-react';
import type { Transaction } from '@/lib/types';

interface RevenueChartProps {
  transactions: Transaction[];
}

export function RevenueChart({ transactions }: RevenueChartProps) {
  const getLast6Months = () => {
    const months: { name: string; key: string; value: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      months.push({
        name: d.toLocaleString('default', { month: 'short' }),
        key: `${d.getFullYear()}-${d.getMonth()}`,
        value: 0,
      });
    }
    return months;
  };

  const chartData = getLast6Months().map((m) => {
    const total = transactions
      .filter((t) => {
        const d = new Date(t.date);
        return `${d.getFullYear()}-${d.getMonth()}` === m.key;
      })
      .reduce((acc, curr) => acc + (curr.amount || 0), 0);
    return { ...m, value: total };
  });

  const maxVal = Math.max(...chartData.map((d) => d.value), 100);
  const isGrowing = chartData[5].value >= chartData[4].value;

  return (
    <div className="bg-card border border-border rounded-2xl p-6 w-full">
      <div className="flex justify-between items-center mb-8">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <BarChart3 size={20} className="text-primary" /> Evolução da Receita
        </h3>
        {isGrowing ? (
          <span className="text-[10px] bg-success/10 text-success border border-success/20 px-2.5 py-1 rounded-full font-bold flex items-center gap-1 uppercase tracking-wider">
            <TrendingUp size={12} /> Crescimento
          </span>
        ) : (
          <span className="text-[10px] bg-destructive/10 text-destructive border border-destructive/20 px-2.5 py-1 rounded-full font-bold flex items-center gap-1 uppercase tracking-wider">
            <TrendingDown size={12} /> Queda
          </span>
        )}
      </div>
      <div className="flex items-end justify-between h-48 gap-4 px-2 relative">
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-5">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="w-full h-px bg-foreground" />
          ))}
        </div>
        {chartData.map((data, index) => (
          <div key={index} className="flex flex-col items-center flex-1 group z-10 h-full justify-end">
            <div
              className="w-full bg-secondary rounded-t-lg relative flex items-end justify-center transition-all duration-500 hover:bg-muted"
              style={{ height: '80%' }}
            >
              <div
                className={`w-full rounded-t-lg transition-all duration-1000 ${
                  index === 5
                    ? 'bg-gradient-to-t from-primary/20 to-primary/80'
                    : 'bg-gradient-to-t from-secondary to-muted-foreground/20'
                }`}
                style={{ height: `${(data.value / maxVal) * 100}%` }}
              >
                <div className="opacity-0 group-hover:opacity-100 absolute -top-10 left-1/2 -translate-x-1/2 bg-foreground text-background text-xs font-bold py-1 px-2 rounded pointer-events-none transition-opacity whitespace-nowrap">
                  R$ {data.value.toFixed(2)}
                </div>
              </div>
            </div>
            <span className="text-[10px] text-muted-foreground mt-3 font-medium uppercase tracking-wider">
              {data.name}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
