import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, Wifi, WifiOff } from 'lucide-react';

export function StreamStatusIndicator({ url, type = 'radio' }: { url: string; type?: 'radio' | 'tv' }) {
  const [status, setStatus] = useState<'checking' | 'online' | 'offline'>('checking');

  useEffect(() => {
    if (!url) { setStatus('offline'); return; }
    setStatus('checking');
    const media = type === 'tv' ? document.createElement('video') : new Audio();
    const handleSuccess = () => setStatus('online');
    const handleError = () => setStatus('offline');
    media.addEventListener('loadedmetadata', handleSuccess);
    media.addEventListener('canplay', handleSuccess);
    media.addEventListener('error', handleError);
    media.src = url;
    media.preload = 'metadata';
    media.load();
    const timeout = setTimeout(() => setStatus(prev => prev === 'checking' ? 'offline' : prev), 8000);
    return () => {
      clearTimeout(timeout);
      media.removeEventListener('loadedmetadata', handleSuccess);
      media.removeEventListener('canplay', handleSuccess);
      media.removeEventListener('error', handleError);
      media.src = '';
    };
  }, [url, type]);

  if (status === 'checking') return <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><span className="w-2 h-2 rounded-full bg-muted-foreground animate-pulse" /> Verificando...</span>;
  if (status === 'online') return <span className="flex items-center gap-1.5 text-xs text-success font-medium"><Wifi size={12} /> Online</span>;
  return <span className="flex items-center gap-1.5 text-xs text-destructive font-medium"><WifiOff size={12} /> Offline</span>;
}

export function MiniAudioPlayer({ url }: { url: string }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) { audioRef.current.pause(); } else { audioRef.current.play().catch(() => {}); }
    setPlaying(!playing);
  };

  useEffect(() => { return () => { audioRef.current?.pause(); }; }, []);

  if (!url) return null;
  return (
    <div className="flex items-center gap-2 p-2 bg-secondary/50 border border-border rounded-lg">
      <audio ref={audioRef} src={url} preload="none" onEnded={() => setPlaying(false)} />
      <button onClick={toggle} className="w-7 h-7 rounded-full bg-primary/20 text-primary flex items-center justify-center hover:bg-primary/30 transition-colors flex-shrink-0">
        {playing ? <Pause size={12} /> : <Play size={12} />}
      </button>
      <div className="flex-1 flex items-center gap-2">
        <Volume2 size={14} className="text-muted-foreground" />
        <div className="flex-1 h-1 bg-border rounded-full overflow-hidden">
          {playing && <div className="h-full bg-primary rounded-full animate-pulse w-full" />}
        </div>
      </div>
      <StreamStatusIndicator url={url} />
    </div>
  );
}
