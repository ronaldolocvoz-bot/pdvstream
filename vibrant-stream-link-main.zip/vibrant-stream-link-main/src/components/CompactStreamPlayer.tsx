import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Wifi, WifiOff } from 'lucide-react';

export function CompactStreamPlayer({ url, type = 'radio' }: { url: string; type?: 'radio' | 'tv' }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [status, setStatus] = useState<'checking' | 'online' | 'offline'>('checking');

  useEffect(() => {
    if (!url) { setStatus('offline'); return; }
    setStatus('checking');
    const media = type === 'tv' ? document.createElement('video') : new Audio();
    const ok = () => setStatus('online');
    const fail = () => setStatus('offline');
    media.addEventListener('loadedmetadata', ok);
    media.addEventListener('canplay', ok);
    media.addEventListener('error', fail);
    media.src = url;
    media.preload = 'metadata';
    media.load();
    const t = setTimeout(() => setStatus(prev => prev === 'checking' ? 'offline' : prev), 8000);
    return () => { clearTimeout(t); media.src = ''; };
  }, [url, type]);

  useEffect(() => { return () => { audioRef.current?.pause(); }; }, []);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) audioRef.current.pause();
    else audioRef.current.play().catch(() => {});
    setPlaying(!playing);
  };

  if (!url) return <span className="text-xs text-muted-foreground">—</span>;

  const statusColor = status === 'online' ? 'text-success' : status === 'offline' ? 'text-destructive' : 'text-muted-foreground';
  const statusIcon = status === 'online' ? <Wifi size={10} /> : status === 'offline' ? <WifiOff size={10} /> : null;
  const statusLabel = status === 'checking' ? '...' : status === 'online' ? 'ON' : 'OFF';

  return (
    <div className="flex items-center gap-1.5">
      <audio ref={audioRef} src={url} preload="none" onEnded={() => setPlaying(false)} />
      <button
        type="button"
        onClick={toggle}
        className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
          playing ? 'bg-primary text-primary-foreground' : 'bg-primary/15 text-primary hover:bg-primary/25'
        }`}
      >
        {playing ? <Pause size={10} /> : <Play size={10} />}
      </button>
      <span className={`flex items-center gap-1 text-[10px] font-bold uppercase ${statusColor}`}>
        {statusIcon}
        {statusLabel}
      </span>
    </div>
  );
}
